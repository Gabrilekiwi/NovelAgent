from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
from time import perf_counter
from typing import Any

from core.autonomy.cli import (
    add_autonomy_arguments as _add_autonomy_arguments,
    autonomy_command_requested as _autonomy_command_requested,
    run_autonomy_command as _run_autonomy_command,
)
from core.autonomy.common import AutonomyContractError
from core.config import clear_proxy_env, proxy_disabled_by_env
from core.delivery import DeliveryError
from core.cli.arguments import (
    apply_notion_shortcuts,
    parse_arguments,
    positive_int as _positive_int,
    review_repair_attempts as _review_repair_attempts,
)
from core.cli.commands import (
    delivery_adapters_from_args as _delivery_adapters_from_args,
    delivery_command_requested as _delivery_command_requested,
    run_delivery_command as _run_delivery_command,
)
from core.cli.root_registry import (
    root_remap_command_requested as _root_remap_command_requested,
    run_root_remap_command as _run_root_remap_command,
)
from core.cli.config import (
    apply_story_project_runtime_defaults as _apply_story_project_runtime_defaults,
    review_repair_config_from_args as _review_repair_config_from_args,
    runtime_review_config_from_args as _runtime_review_config_from_args,
    story_project_writeback_config_from_args as _story_project_writeback_config_from_args,
    validate_story_project_multistep_args as _validate_story_project_multistep_args,
)
from core.cli.output import (
    format_delivery_command_summary,
    format_locked_chapter_recovery_summary,
    format_loop_progress_event,
    format_persistence_reconcile_summary,
)
from core.cli.progress import ProgressJSONLError, ProgressJSONLWriter
from core.director import ModelDirector
from core.engine.artifacts import chapter_artifact_metadata, save_chapter_artifact
from core.engine.executor import AgentExecutor, LoopExecutionError
from core.engine.persistence import (
    PersistenceError,
    atomic_create_json,
    atomic_write_json,
    complete_persistence_transaction,
    load_persistence_candidate,
    persistence_run_lock,
    reconcile_persistence,
)
from core.engine.persistence_v2 import reconcile_pending_persistence_v2
from core.engine.preflight import run_preflight
from core.engine.locked_chapter import LockedChapterRecoveryError, recover_locked_chapter
from core.engine.recovery import RecoveryError, recover_latest_chapter_draft
from core.engine.root_registry import RootRegistryError
from core.engine.safe_paths import SafePathError
from core.engine.report import build_run_report
from core.engine.run_record import validate_run_result
from core.project_profile import project_language
from core.runtime_paths import (
    DEFAULT_CHAPTER_DIR,
    DEFAULT_RUN_DIR,
    DEFAULT_SNAPSHOT_PATH,
    RuntimePaths,
    init_runtime_state,
)
from core.review.dashboard import build_review_dashboard_from_index
from core.review.index import get_latest_review, list_recent_reviews
from core.state.memory_writer import build_memory_writer, write_memory_updates
from core.state.snapshot import load_snapshot
from core.story_project.oh_story_detection import (
    detect_oh_story_compatibility,
    failed_oh_story_compatibility_report,
)
from core.story_project.paths import resolve_story_project_root
from core.story_project.format_compatibility import assert_project_execution_compatible
from core.story_project.identity import (
    ensure_project_identity_for_runtime,
    load_project_identity,
    project_identity_for_operation,
)
from core.story_project.migration import (
    StoryProjectRuntimeMigrationError,
    inspect_story_project_runtime_migration,
    migrate_story_project_runtime,
)
from core.story_project.migration_v2 import MigrationV2Error, build_migration_preview
from core.story_project.runtime import build_generation_story_project_context_loader
from core.story_project.activation import StoryStateActivationError, activate_story_state
from core.story_project.semantic_parser import (
    build_story_project_shadow_report,
    parse_story_project_semantic_state,
)
from core.story_project.validator import validate_story_project


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="NovelAgent v1.0 agent loop", allow_abbrev=False
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Run with deterministic local output instead of API calls.",
    )
    parser.add_argument(
        "--persist-dry-run",
        action="store_true",
        help="Persist snapshot and run records even when --dry-run is enabled.",
    )
    parser.add_argument(
        "--runtime-mode",
        choices=("legacy", "shadow"),
        default=None,
        help=(
            "Runtime boundary mode. Defaults to NOVELAGENT_RUNTIME_MODE or legacy; "
            "shadow records node evidence without taking over execution."
        ),
    )
    parser.add_argument(
        "--snapshot",
        default=str(DEFAULT_SNAPSHOT_PATH),
        help="Snapshot file path.",
    )
    parser.add_argument(
        "--memory",
        default=None,
        help="Memory context file path. Defaults to NOVELAGENT_MEMORY_PATH or .tmp/runtime/notion_memory.json.",
    )
    parser.add_argument(
        "--story-project",
        default=None,
        help="StoryProject root path, or auto to use .active-book / directory discovery.",
    )
    parser.add_argument(
        "--chapter",
        default="auto",
        help="StoryProject chapter number, or auto to infer the next chapter from 正文/.",
    )
    parser.add_argument(
        "--story-project-writeback",
        action="store_true",
        help="After a committed StoryProject run, write generated prose and tracking updates back to StoryProject.",
    )
    parser.add_argument(
        "--story-project-writeback-dry-run",
        action="store_true",
        help="Build StoryProject writeback plan and artifacts without modifying StoryProject files.",
    )
    parser.add_argument(
        "--story-project-overwrite",
        action="store_true",
        help="Allow StoryProject writeback to overwrite a uniquely resolved existing prose file.",
    )
    parser.add_argument(
        "--story-project-compat-report",
        action="store_true",
        help="Print a read-only oh-story compatibility report for the StoryProject root and exit.",
    )
    parser.add_argument(
        "--story-state-shadow-report",
        action="store_true",
        help="Parse StoryProject semantic state, print a read-only shadow diff, and exit without generation.",
    )
    parser.add_argument(
        "--preview-event-authority-migration",
        action="store_true",
        help="Freeze legacy StoryProject inputs and print a read-only event-authority migration preview; never approve, execute, or activate.",
    )
    parser.add_argument(
        "--migration-preview-created-at",
        default=None,
        metavar="TIMESTAMP",
        help="Optional explicit timestamp for a reproducible event-authority migration preview plan.",
    )
    parser.add_argument(
        "--activate-story-state",
        action="store_true",
        help="Explicitly activate calibrated strict StoryProject semantic state for this book.",
    )
    parser.add_argument(
        "--story-state-calibration-report",
        default=None,
        metavar="PATH",
        help="Tamper-evident calibration report required by --activate-story-state.",
    )
    parser.add_argument(
        "--allow-story-state-shadow-downgrade",
        action="store_true",
        help="On a pinned strict profile mismatch, explicitly run in non-authoritative shadow mode; next-step readiness remains false.",
    )
    parser.add_argument(
        "--inspect-story-project-runtime-from",
        default=None,
        metavar="PATH",
        help="Inspect an old runtime for safe StoryProject migration without writing files.",
    )
    parser.add_argument(
        "--migrate-story-project-runtime-from",
        default=None,
        metavar="PATH",
        help="Copy a proven matching old runtime into <StoryProject>/.novelagent/runtime and write a manifest.",
    )
    parser.add_argument(
        "--memory-source",
        choices=["auto", "file", "notion"],
        default="auto",
        help="Select memory input mode. auto uses Notion API when configured and no --memory path is provided.",
    )
    parser.add_argument(
        "--notion-memory",
        action="store_true",
        help="Shortcut for --memory-source notion.",
    )
    parser.add_argument(
        "--chapter-dir",
        default=str(DEFAULT_CHAPTER_DIR),
        help="Directory for persisted chapter markdown artifacts.",
    )
    parser.add_argument(
        "--run-dir",
        default=str(DEFAULT_RUN_DIR),
        help="Directory for persisted run JSON records.",
    )
    parser.add_argument(
        "--persistence-dir",
        default=None,
        help="Directory for local persistence journals. Defaults to <run-dir>/transactions or StoryProject runtime/persistence.",
    )
    parser.add_argument(
        "--remap-roots",
        action="store_true",
        help=(
            "Explicitly rebind roots after an identity-preserving same-volume directory "
            "rename; the command validates and journals the rebind but never moves files."
        ),
    )
    parser.add_argument(
        "--remap-root",
        action="append",
        nargs=3,
        default=None,
        metavar=("ROOT_ID", "ROOT_UUID", "NEW_PATH"),
        help=(
            "With --remap-roots, bind one existing logical root UUID to an existing "
            "new physical directory. A story_project entry selects the crash-recoverable "
            "whole-project path, which discovers and rebinds every embedded registry."
        ),
    )
    parser.add_argument(
        "--expected-root-registry-revision",
        type=_positive_int,
        default=None,
        metavar="REVISION",
        help="CAS revision required by --remap-roots.",
    )
    parser.add_argument(
        "--expected-root-registry-digest",
        default=None,
        metavar="SHA256",
        help="CAS digest required by --remap-roots.",
    )
    parser.add_argument(
        "--delivery-dir",
        default=str(RuntimePaths.legacy_default().delivery_dir),
        help="Directory for durable delivery jobs and attempt receipts.",
    )
    parser.add_argument(
        "--init-runtime",
        action="store_true",
        help="Initialize .tmp/runtime from committed example state and exit.",
    )
    parser.add_argument(
        "--force-init-runtime",
        action="store_true",
        help="With --init-runtime, overwrite existing .tmp/runtime snapshot and memory files.",
    )
    parser.add_argument(
        "--memory-outbox",
        default=None,
        help="Append committed memory updates to this JSONL file.",
    )
    parser.add_argument(
        "--memory-writeback",
        choices=["none", "file", "notion"],
        default="none",
        help="Persist committed memory updates to no target, a JSONL file, or Notion.",
    )
    parser.add_argument(
        "--notion-readback",
        action="store_true",
        help="After Notion memory writeback, query the database and verify written Memory IDs.",
    )
    parser.add_argument(
        "--notion-sync",
        action="store_true",
        help="Shortcut for live Notion memory input plus Notion writeback and readback.",
    )
    parser.add_argument(
        "--director-model",
        default=None,
        help="Use an OpenAI-backed Director with this model name instead of the offline rule Director.",
    )
    parser.add_argument(
        "--llm-validator",
        action="store_true",
        help="Run the optional OpenAI-backed story-level validator after rule validation.",
    )
    parser.add_argument(
        "--quality-policy",
        choices=["auto", "minimal", "standard", "strict"],
        default="auto",
        help="Quality policy. auto uses standard for real StoryProject writeback and minimal otherwise.",
    )
    parser.add_argument(
        "--enable-review-pipeline",
        action="store_true",
        help="After chapter generation, run the optional deterministic Review Pipeline.",
    )
    parser.add_argument(
        "--review-output-dir",
        default=".tmp/runtime/reviews",
        help="Root directory for optional runtime review artifacts.",
    )
    parser.add_argument(
        "--review-rules",
        default=None,
        help="Optional custom Narrative Rule Pack JSON path for runtime review.",
    )
    parser.add_argument(
        "--review-no-default-rules",
        action="store_true",
        help="Disable default review rules. Requires --review-rules.",
    )
    parser.add_argument(
        "--review-no-repair-prompt",
        action="store_true",
        help="Run runtime review without generating a repair prompt artifact.",
    )
    parser.add_argument(
        "--review-no-human-report",
        action="store_true",
        help="Run runtime review without generating a human-readable review report.",
    )
    parser.add_argument(
        "--review-gate",
        choices=["off", "blocked", "needs_revision", "warning"],
        default="off",
        help="Optional review status threshold that can make the CLI exit non-zero.",
    )
    parser.add_argument(
        "--review-auto-repair",
        action="store_true",
        help="Enable explicit review-driven repair when runtime review requests revision.",
    )
    parser.add_argument(
        "--review-repair-max-attempts",
        type=_review_repair_attempts,
        default=1,
        help="Maximum review repair attempts, from 1 to 3.",
    )
    parser.add_argument(
        "--review-repair-dry-run",
        action="store_true",
        help="Build review repair plan artifacts without changing runtime chapter text.",
    )
    parser.add_argument(
        "--review-latest",
        action="store_true",
        help="Print the latest runtime review entry from review_index.json and exit.",
    )
    parser.add_argument(
        "--review-list",
        action="store_true",
        help="Print recent runtime review entries from review_index.json and exit.",
    )
    parser.add_argument(
        "--review-list-limit",
        type=_positive_int,
        default=10,
        help="Maximum recent review entries to print with --review-list.",
    )
    parser.add_argument(
        "--review-status",
        choices=["pass", "warning", "needs_revision", "blocked", "error", "unknown"],
        default=None,
        help="Filter --review-list by review status.",
    )
    parser.add_argument(
        "--review-gate-status",
        choices=["disabled", "pass", "fail", "error"],
        default=None,
        help="Filter --review-list by review gate status.",
    )
    parser.add_argument(
        "--review-dashboard",
        action="store_true",
        help="Build a static HTML dashboard from review_index.json and exit.",
    )
    parser.add_argument(
        "--review-dashboard-out",
        default=None,
        help="Optional output path for --review-dashboard. Defaults to <review-output-dir>/dashboard.html.",
    )
    parser.add_argument(
        "--scene-limit",
        type=_positive_int,
        default=None,
        help="Limit generated chapter scenes for bounded provider runs. Defaults to the full model plan.",
    )
    parser.add_argument(
        "--steps",
        type=_positive_int,
        default=1,
        help=(
            "Deprecated low-level agent-loop compatibility bound. It is not a "
            "StoryProject autonomy chapter count; autonomy uses its immutable "
            "InstructionPlan range."
        ),
    )
    parser.add_argument(
        "--continue-on-rejection",
        action="store_true",
        help="Continue loop after a rejected run so the next step can use recovery context.",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="Run preflight checks and exit without generating a chapter.",
    )
    parser.add_argument(
        "--check-json",
        action="store_true",
        help="With --check, print the full preflight JSON instead of the concise summary.",
    )
    parser.add_argument(
        "--check-memory-v2",
        action="store_true",
        help="With --check, validate the Memory V2 compile chain in dry-run mode.",
    )
    parser.add_argument(
        "--memory-v2-out",
        default="data/memory_v2/default",
        help="Output directory path used for --check-memory-v2 dry-run diagnostics.",
    )
    parser.add_argument(
        "--report-runs",
        action="store_true",
        help="Print a JSON report for persisted run records and exit.",
    )
    parser.add_argument(
        "--recover-latest",
        action="store_true",
        help="Recover the latest failed or rejected pre-polish chapter draft into chapter-dir and exit.",
    )
    parser.add_argument(
        "--recover-locked-chapter",
        action="store_true",
        help=(
            "Handle the current locked chapter without model calls: reuse a complete draft, "
            "resume a trustworthy scene prefix, or reset when no output is safe to reuse."
        ),
    )
    parser.add_argument(
        "--locked-chapter-draft",
        help=(
            "With --recover-locked-chapter, stage a UTF-8 complete chapter draft "
            "inside the StoryProject for validation without regenerating or polishing it."
        ),
    )
    parser.add_argument(
        "--locked-chapter-reset",
        action="store_true",
        help=(
            "With --recover-locked-chapter, explicitly discard all uncommitted output "
            "for the current chapter and restart it from the committed snapshot."
        ),
    )
    parser.add_argument(
        "--reconcile-persistence",
        action="store_true",
        help="Reconcile incomplete local persistence transactions and publish durable candidates without generating.",
    )
    parser.add_argument(
        "--reconcile-deliveries",
        action="store_true",
        help="Attempt pending durable deliveries once and exit without generation.",
    )
    parser.add_argument(
        "--run-id",
        default=None,
        help="Limit --reconcile-deliveries to one run id.",
    )
    parser.add_argument(
        "--inspect-delivery",
        default=None,
        metavar="JOB_ID",
        help="Print one durable delivery job and its attempt receipts, then exit.",
    )
    parser.add_argument(
        "--resolve-delivery",
        default=None,
        metavar="JOB_ID",
        help="Resolve one uncertain durable delivery after explicit operator confirmation.",
    )
    parser.add_argument(
        "--confirmed-absent",
        action="store_true",
        help="With --resolve-delivery, confirm the quarantine window elapsed and request a query-only absence check.",
    )
    parser.add_argument(
        "--delivery-policy",
        choices=["required", "best-effort"],
        default="required",
        help="Policy for a configured external writer; required is the default.",
    )
    parser.add_argument(
        "--delivery-worker-id",
        default="cli",
        help="Stable worker id recorded in durable delivery leases.",
    )
    parser.add_argument(
        "--notion-delivery-schema",
        default=None,
        metavar="PATH",
        help="Notion database schema JSON captured during required-delivery preflight.",
    )
    parser.add_argument(
        "--output-json",
        action="store_true",
        help="After generation, print the full result JSON instead of the concise summary.",
    )
    parser.add_argument(
        "--output-run-json",
        action="store_true",
        help="After generation, print only the full run record JSON instead of the concise summary.",
    )
    parser.add_argument(
        "--report-limit",
        type=int,
        default=5,
        help="Maximum number of recent runs to include in --report-runs output. Use 0 for counts only.",
    )
    parser.add_argument(
        "--require-claude",
        action="store_true",
        help="During --check, require Claude polish environment variables.",
    )
    parser.add_argument(
        "--no-proxy",
        action="store_true",
        help="Clear HTTP(S)/ALL proxy environment variables before provider calls.",
    )
    parser.add_argument(
        "--no-progress",
        action="store_true",
        help="Disable multi-step progress lines printed to stderr.",
    )
    parser.add_argument(
        "--progress-jsonl",
        default=None,
        metavar="ABSOLUTE_PATH",
        help=(
            "Append and flush stable UTF-8 NDJSON progress events for chapter generation. "
            "The absolute path's parent directory must already exist."
        ),
    )
    _add_autonomy_arguments(parser)
    return parser


def parse_args() -> argparse.Namespace:
    parser = build_parser()
    argv = list(sys.argv[1:])
    return parse_arguments(parser, argv)


class _LoopProgressObserver:
    def __init__(self, *, print_human: bool, jsonl_writer: ProgressJSONLWriter | None) -> None:
        self._print_human = print_human
        self._jsonl_writer = jsonl_writer

    def __call__(self, event: dict[str, Any]) -> None:
        if self._print_human:
            line = format_loop_progress_event(event)
            if line:
                print(line, file=sys.stderr, flush=True)
        if self._jsonl_writer is not None:
            self._jsonl_writer(event)

    def close(self) -> None:
        if self._jsonl_writer is not None:
            self._jsonl_writer.close()


def _loop_progress_observer(args: argparse.Namespace) -> _LoopProgressObserver | None:
    print_human = not (
        args.no_progress or args.output_json or args.output_run_json or args.steps <= 1
    )
    jsonl_writer = (
        ProgressJSONLWriter(args.progress_jsonl)
        if getattr(args, "progress_jsonl", None)
        else None
    )
    if not print_human and jsonl_writer is None:
        return None
    return _LoopProgressObserver(print_human=print_human, jsonl_writer=jsonl_writer)


def _run_once_with_progress(
    executor: AgentExecutor,
    *,
    persist: bool,
    observer: _LoopProgressObserver | None,
) -> dict[str, Any]:
    if observer is None:
        return executor.run_once(persist=persist)

    requested_steps = 1
    observer({"event": "loop_start", "requested_steps": requested_steps})
    observer({"event": "step_start", "step": 1, "requested_steps": requested_steps})
    started_at = perf_counter()
    try:
        result = executor.run_once(persist=persist)
    except Exception as exc:
        observer(
            {
                "event": "step_failed",
                "step": 1,
                "requested_steps": requested_steps,
                "duration_ms": max(0, round((perf_counter() - started_at) * 1000)),
                "error_type": type(exc).__name__,
                "message": str(exc),
            }
        )
        raise

    observer(
        {
            "event": "step_end",
            "step": 1,
            "requested_steps": requested_steps,
            "duration_ms": max(0, round((perf_counter() - started_at) * 1000)),
            "run_id": result["run"]["id"],
            "chapter_index": result["run"]["chapter_index"],
            "committed": result["committed"],
            "status": result["run"]["status"],
            **_runtime_progress_fields(result),
        }
    )
    run_status = str(result["run"].get("status") or "")
    if (
        run_status == "failed"
        or _story_project_writeback_exit_code(result)
        or _memory_writeback_exit_code(result)
    ):
        stopped_reason = "failed"
    elif run_status == "rejected":
        stopped_reason = "rejected"
    else:
        stopped_reason = "max_steps"
    observer(
        {
            "event": "loop_end",
            "requested_steps": requested_steps,
            "completed_steps": 1,
            "stopped_reason": stopped_reason,
        }
    )
    return result


def _runtime_progress_fields(result: dict[str, Any]) -> dict[str, Any]:
    run = result.get("run") if isinstance(result, dict) else None
    runtime = run.get("runtime") if isinstance(run, dict) else None
    if not isinstance(runtime, dict):
        return {}
    attempts = runtime.get("attempts")
    return {
        "runtime_mode": str(runtime.get("mode") or "shadow"),
        "node_attempt_count": len(attempts) if isinstance(attempts, list) else 0,
    }


def _load_story_project_identity_for_read_command(args: argparse.Namespace):
    if getattr(args, "story_project", None) is None:
        return None
    identity = load_project_identity(args._resolved_story_project_root)
    if identity is None:
        raise ValueError(
            "StoryProject read command requires an existing .novelagent/project.json; "
            "run --init-runtime or a persistent StoryProject operation first"
        )
    return identity


def _validate_story_project_read_command_identity(args: argparse.Namespace) -> None:
    if getattr(args, "locked_chapter_draft", None) and not bool(
        getattr(args, "recover_locked_chapter", False)
    ):
        raise ValueError("--locked-chapter-draft requires --recover-locked-chapter")
    if getattr(args, "locked_chapter_reset", False) and not bool(
        getattr(args, "recover_locked_chapter", False)
    ):
        raise ValueError("--locked-chapter-reset requires --recover-locked-chapter")
    if getattr(args, "locked_chapter_reset", False) and getattr(
        args, "locked_chapter_draft", None
    ):
        raise ValueError("--locked-chapter-reset cannot be combined with --locked-chapter-draft")
    if (
        bool(getattr(args, "report_runs", False))
        or bool(getattr(args, "recover_latest", False))
        or bool(getattr(args, "recover_locked_chapter", False))
    ):
        if bool(getattr(args, "recover_locked_chapter", False)) and getattr(args, "story_project", None) is None:
            raise ValueError("--recover-locked-chapter requires --story-project")
        _load_story_project_identity_for_read_command(args)


def main() -> None:
    args = parse_args()
    apply_notion_shortcuts(args)
    if args.no_proxy or proxy_disabled_by_env():
        clear_proxy_env()
    try:
        story_runtime_paths = _apply_story_project_runtime_defaults(args)
        if getattr(args, "_resolved_story_project_root", None) is not None:
            assert_project_execution_compatible(args._resolved_story_project_root)
        delivery_command_requested = _delivery_command_requested(args)
        autonomy_command_requested = _autonomy_command_requested(args)
        root_remap_command_requested = _root_remap_command_requested(
            args,
            delivery_command_requested=delivery_command_requested,
            autonomy_command_requested=autonomy_command_requested,
        )
        _validate_event_authority_migration_preview_args(args)
        if args.preview_event_authority_migration and (
            delivery_command_requested
            or autonomy_command_requested
            or root_remap_command_requested
        ):
            raise ValueError(
                "--preview-event-authority-migration cannot be combined with delivery, "
                "autonomy, or root-remap commands"
            )
    except ValueError as exc:
        print(f"Configuration failed: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc

    if root_remap_command_requested:
        try:
            result = _run_root_remap_command(args)
        except (RootRegistryError, SafePathError, OSError, ValueError) as exc:
            payload = {
                "ok": False,
                "error": {"type": type(exc).__name__, "message": str(exc)},
            }
            if args.output_json:
                print(json.dumps(payload, ensure_ascii=False, indent=2))
            else:
                print(f"Root remap failed: {exc}", file=sys.stderr)
            raise SystemExit(1) from exc
        print(json.dumps(result, ensure_ascii=False, indent=2))
        raise SystemExit(0)

    if args.preview_event_authority_migration:
        created_at = args.migration_preview_created_at or datetime.now(timezone.utc).isoformat()
        try:
            preview = build_migration_preview(
                args._resolved_story_project_root,
                created_at=created_at,
            )
        except (MigrationV2Error, OSError, ValueError) as exc:
            print(f"StoryProject event-authority migration preview failed: {exc}", file=sys.stderr)
            raise SystemExit(1) from exc
        print(json.dumps(preview, ensure_ascii=False, indent=2))
        raise SystemExit(0)

    if autonomy_command_requested:
        try:
            result = _run_autonomy_command(
                args, story_runtime_paths=story_runtime_paths
            )
        except (AutonomyContractError, OSError, ValueError, json.JSONDecodeError) as exc:
            payload = {
                "ok": False,
                "error": {"type": type(exc).__name__, "message": str(exc)},
            }
            if args.output_json:
                print(json.dumps(payload, ensure_ascii=False, indent=2))
            else:
                print(f"Autonomy command failed: {exc}", file=sys.stderr)
            raise SystemExit(1) from exc
        print(json.dumps(result, ensure_ascii=False, indent=2))
        raise SystemExit(0 if result.get("ok") else 1)

    if delivery_command_requested:
        try:
            result = _run_delivery_command(args, story_runtime_paths=story_runtime_paths)
        except (DeliveryError, OSError, ValueError, json.JSONDecodeError) as exc:
            payload = {"ok": False, "error": {"type": type(exc).__name__, "message": str(exc)}}
            if args.output_json or args.inspect_delivery:
                print(json.dumps(payload, ensure_ascii=False, indent=2))
            else:
                print(f"Delivery command failed: {exc}", file=sys.stderr)
            raise SystemExit(1) from exc
        if args.output_json or args.inspect_delivery:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(format_delivery_command_summary(result))
        raise SystemExit(0 if result.get("ok") else 1)

    if args.review_latest:
        latest = get_latest_review(review_output_dir=args.review_output_dir)
        payload = {"ok": True, "latest": latest}
        if args.output_json:
            print(json.dumps(payload, ensure_ascii=False, indent=2))
        else:
            print(format_review_latest_summary(latest))
        raise SystemExit(0)

    if args.review_list:
        entries = list_recent_reviews(
            review_output_dir=args.review_output_dir,
            limit=args.review_list_limit,
            status=args.review_status,
            gate_status=args.review_gate_status,
        )
        payload = {"ok": True, "count": len(entries), "entries": entries}
        if args.output_json:
            print(json.dumps(payload, ensure_ascii=False, indent=2))
        else:
            print(format_review_list_summary(entries))
        raise SystemExit(0)

    if args.review_dashboard:
        result = build_review_dashboard_from_index(
            review_output_dir=args.review_output_dir,
            output_path=args.review_dashboard_out,
        )
        payload = {"ok": True, "dashboard": result["metadata"]}
        if args.output_json:
            print(json.dumps(payload, ensure_ascii=False, indent=2))
        else:
            print(format_review_dashboard_summary(result["metadata"]))
        raise SystemExit(0)

    try:
        review_config = _runtime_review_config_from_args(args)
        review_repair_config = _review_repair_config_from_args(args)
        story_project_writeback = _story_project_writeback_config_from_args(args)
        _validate_story_project_multistep_args(args, story_project_writeback)
        _validate_story_project_compat_report_args(args)
        _validate_story_project_shadow_report_args(args)
        _validate_event_authority_migration_preview_args(args)
        _validate_story_state_activation_args(args)
        _validate_story_project_runtime_migration_args(args)
        _validate_story_project_read_command_identity(args)
    except ValueError as exc:
        print(f"Configuration failed: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc

    if args.activate_story_state:
        try:
            identity = activate_story_state(
                args._resolved_story_project_root,
                args.story_state_calibration_report,
            )
        except (StoryStateActivationError, OSError, ValueError) as exc:
            print(f"StoryProject strict activation failed: {exc}", file=sys.stderr)
            raise SystemExit(1) from exc
        payload = {"ok": True, "project_identity": identity.to_dict()}
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        raise SystemExit(0)

    if args.init_runtime:
        if story_runtime_paths is not None:
            ensure_project_identity_for_runtime(
                args._resolved_story_project_root,
                persistence_dir=args.persistence_dir,
            )
            result = init_runtime_state(
                snapshot_target=args.snapshot,
                memory_target=story_runtime_paths.memory_dir / "notion_memory.json",
                overwrite=args.force_init_runtime,
            )
        else:
            result = init_runtime_state(overwrite=args.force_init_runtime)
        print(format_init_runtime_summary(result))
        raise SystemExit(0)

    if args.reconcile_persistence:
        reconcile_identity = (
            ensure_project_identity_for_runtime(
                args._resolved_story_project_root,
                persistence_dir=args.persistence_dir,
            )
            if args.story_project is not None
            else None
        )
        reconcile_kwargs = {
            "chapter_dir": args.chapter_dir,
            "state_paths": _persistence_state_paths_from_args(args),
        }
        if args.persistence_dir is not None:
            reconcile_kwargs["persistence_dir"] = args.persistence_dir
        if reconcile_identity is not None:
            reconcile_kwargs["expected_book_id"] = reconcile_identity.book_id
        result = _reconcile_authority_persistence(
            args.run_dir,
            project_identity=reconcile_identity,
            story_project_root=args._resolved_story_project_root,
            **reconcile_kwargs,
        )
        if args.output_json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(format_persistence_reconcile_summary(result))
        raise SystemExit(0 if result.get("ok") else 1)

    if args.report_runs:
        report_identity = _load_story_project_identity_for_read_command(args)
        report = build_run_report(
            run_dir=args.run_dir,
            limit=args.report_limit,
            expected_book_id=report_identity.book_id if report_identity is not None else None,
        )
        print(json.dumps(report, ensure_ascii=False, indent=2))
        raise SystemExit(0)

    if args.recover_latest:
        recovery_identity = _load_story_project_identity_for_read_command(args)
        try:
            result = recover_latest_chapter_draft(
                run_dir=args.run_dir,
                chapter_dir=args.chapter_dir,
                expected_book_id=recovery_identity.book_id if recovery_identity is not None else None,
            )
        except RecoveryError as exc:
            payload = {"ok": False, "error": {"type": type(exc).__name__, "message": str(exc)}}
            if args.output_json:
                print(json.dumps(payload, ensure_ascii=False, indent=2))
            else:
                print(format_recovery_summary(payload))
            raise SystemExit(1) from exc
        if args.output_json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(format_recovery_summary(result))
        raise SystemExit(0)

    if args.story_project_compat_report:
        report = _build_story_project_compat_report(args)
        if args.output_json:
            print(json.dumps(report, ensure_ascii=False, indent=2))
        else:
            print(format_story_project_compat_report(report))
        raise SystemExit(0)

    if args.recover_locked_chapter:
        recovery_identity = _load_story_project_identity_for_read_command(args)
        try:
            result = recover_locked_chapter(
                story_project_root=args._resolved_story_project_root,
                run_dir=args.run_dir,
                snapshot_path=args.snapshot,
                expected_book_id=recovery_identity.book_id,
                language=project_language(load_snapshot(args.snapshot)),
                manual_draft_path=args.locked_chapter_draft,
                force_reset=args.locked_chapter_reset,
            )
        except (LockedChapterRecoveryError, OSError, ValueError) as exc:
            payload = {"ok": False, "error": {"type": type(exc).__name__, "message": str(exc)}}
            if args.output_json:
                print(json.dumps(payload, ensure_ascii=False, indent=2))
            else:
                print(format_locked_chapter_recovery_summary(payload), file=sys.stderr)
            raise SystemExit(1) from exc
        if args.output_json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(format_locked_chapter_recovery_summary(result))
        raise SystemExit(0)

    if args.story_state_shadow_report:
        try:
            report = _build_story_state_shadow_report(args)
        except ValueError as exc:
            print(f"StoryProject semantic shadow report failed: {exc}", file=sys.stderr)
            raise SystemExit(1) from exc
        print(json.dumps(report, ensure_ascii=False, indent=2))
        raise SystemExit(0)

    if args.inspect_story_project_runtime_from:
        inspection = inspect_story_project_runtime_migration(
            source_runtime=args.inspect_story_project_runtime_from,
            story_project_root=args._resolved_story_project_root,
        )
        if args.output_json:
            print(json.dumps(inspection, ensure_ascii=False, indent=2))
        else:
            print(format_story_project_runtime_migration_summary(inspection))
        raise SystemExit(0 if inspection["ok"] else 1)

    if args.migrate_story_project_runtime_from:
        try:
            migration = migrate_story_project_runtime(
                source_runtime=args.migrate_story_project_runtime_from,
                story_project_root=args._resolved_story_project_root,
            )
        except StoryProjectRuntimeMigrationError as exc:
            print(f"StoryProject runtime migration failed: {exc}", file=sys.stderr)
            raise SystemExit(1) from exc
        if args.output_json:
            print(json.dumps(migration, ensure_ascii=False, indent=2))
        else:
            print(format_story_project_runtime_migration_summary(migration["inspection"], migrated=migration))
        raise SystemExit(0)

    if args.check:
        result = run_preflight(
            snapshot_path=args.snapshot,
            memory_path=args.memory,
            memory_source=args.memory_source,
            run_dir=args.run_dir,
            chapter_dir=args.chapter_dir,
            dry_run=args.dry_run,
            require_claude=args.require_claude,
            director_model=args.director_model,
            enable_llm_validator=args.llm_validator,
            memory_writeback=args.memory_writeback,
            memory_outbox=args.memory_outbox,
            notion_readback=args.notion_readback,
            persist=not args.dry_run or args.persist_dry_run,
            steps=args.steps,
            continue_on_rejection=args.continue_on_rejection,
            check_memory_v2=args.check_memory_v2,
            memory_v2_output_dir=args.memory_v2_out,
            story_project=args.story_project,
            chapter=args.chapter,
            allow_story_state_shadow_downgrade=args.allow_story_state_shadow_downgrade,
        )
        if args.check_json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(format_preflight_summary(result))
        raise SystemExit(0 if result["ok"] else 1)

    will_commit_state = (not args.dry_run or args.persist_dry_run) and not args.story_project_writeback_dry_run
    project_identity = (
        project_identity_for_operation(
            args._resolved_story_project_root,
            persist=True,
            persistence_dir=args.persistence_dir,
        )
        if will_commit_state and args.story_project is not None
        else None
    )
    if will_commit_state:
        reconcile_kwargs = {
            "chapter_dir": args.chapter_dir,
            "state_paths": _persistence_state_paths_from_args(args),
        }
        if args.persistence_dir is not None:
            reconcile_kwargs["persistence_dir"] = args.persistence_dir
        if project_identity is not None:
            reconcile_kwargs["expected_book_id"] = project_identity.book_id
        persistence_health = _reconcile_authority_persistence(
            args.run_dir,
            project_identity=project_identity,
            story_project_root=args._resolved_story_project_root,
            **reconcile_kwargs,
        )
        if not persistence_health.get("ok"):
            if args.output_json:
                print(json.dumps(persistence_health, ensure_ascii=False, indent=2))
            else:
                print(format_persistence_reconcile_summary(persistence_health), file=sys.stderr)
            raise SystemExit(1)

    story_project_context_loader = None
    story_project_oh_story_report = None
    if args.story_project is not None:
        project_identity = project_identity or project_identity_for_operation(
            args._resolved_story_project_root, persist=False
        )
        story_project_context_loader = build_generation_story_project_context_loader(
            story_project=args._resolved_story_project_root,
            chapter=args.chapter,
            overwrite=args.story_project_overwrite,
            project_identity=project_identity,
            allow_story_state_shadow_downgrade=args.allow_story_state_shadow_downgrade,
        )
        story_project_oh_story_report = _detect_story_project_context_compatibility(story_project_context_loader)

    executor = AgentExecutor(
        snapshot_path=args.snapshot,
        memory_path=args.memory,
        memory_source=args.memory_source,
        run_dir=args.run_dir,
        chapter_dir=args.chapter_dir,
        persistence_dir=args.persistence_dir,
        dry_run=args.dry_run,
        scene_limit=args.scene_limit,
        director=ModelDirector(model=args.director_model) if args.director_model else None,
        enable_llm_validator=args.llm_validator,
        runtime_mode=args.runtime_mode,
        memory_writer=build_memory_writer(
            mode=args.memory_writeback,
            outbox_path=args.memory_outbox,
            notion_readback=args.notion_readback,
        ),
        review_config=review_config,
        review_repair_config=review_repair_config,
        story_project_context_loader=story_project_context_loader,
        story_project_oh_story_report=story_project_oh_story_report,
        story_project_writeback=story_project_writeback,
        quality_policy=None if args.quality_policy == "auto" else args.quality_policy,
    )
    persist = (
        not args.dry_run
        or args.persist_dry_run
        or args.story_project_writeback_dry_run
        or args.review_repair_dry_run
    )
    try:
        progress_observer = _loop_progress_observer(args)
    except (OSError, ProgressJSONLError) as exc:
        print(f"Configuration failed: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc

    loop_exit_code = 0
    if args.steps == 1:
        try:
            result = _run_once_with_progress(
                executor,
                persist=persist,
                observer=progress_observer,
            )
        finally:
            if progress_observer is not None:
                progress_observer.close()
    else:
        try:
            try:
                loop_result = executor.run_loop(
                    steps=args.steps,
                    persist=persist,
                    stop_on_rejection=not args.continue_on_rejection,
                    observer=progress_observer,
                )
            except LoopExecutionError as exc:
                payload = {
                    "session": exc.session,
                    "runs": exc.runs,
                    "error": {
                        "type": type(exc.original).__name__,
                        "message": str(exc.original),
                    },
                }
                if args.output_json:
                    print(json.dumps(payload, ensure_ascii=False, indent=2))
                elif args.output_run_json and exc.runs:
                    print(json.dumps(exc.runs[-1]["run"], ensure_ascii=False, indent=2))
                else:
                    print(format_loop_failure_summary(payload))
                raise SystemExit(1) from exc
        finally:
            if progress_observer is not None:
                progress_observer.close()
        if args.output_json:
            print(json.dumps(loop_result, ensure_ascii=False, indent=2))
            loop_exit_code = int(loop_result.get("exit_code") or 0)
            if loop_exit_code:
                raise SystemExit(loop_exit_code)
            return
        result = loop_result["last_result"]
        loop_exit_code = int(loop_result.get("exit_code") or 0)
        result["loop"] = {
            "session_id": loop_result["session"]["id"],
            "completed_steps": loop_result["completed_steps"],
            "stopped_reason": loop_result["stopped_reason"],
            "run_ids": [item["run"]["id"] for item in loop_result["runs"]],
            "committed": [item["committed"] for item in loop_result["runs"]],
            "succeeded": bool(loop_result.get("succeeded")),
            "exit_code": loop_exit_code,
            "failure_reasons": list(loop_result.get("failure_reasons") or []),
        }
        if loop_result["session"].get("artifact"):
            result["loop"]["artifact"] = loop_result["session"]["artifact"]

    if args.output_json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    elif args.output_run_json:
        print(json.dumps(result["run"], ensure_ascii=False, indent=2))
    else:
        print(format_run_summary(result))
    if loop_exit_code:
        raise SystemExit(loop_exit_code)
    gate_exit_code = _review_gate_exit_code(result)
    if gate_exit_code:
        raise SystemExit(gate_exit_code)
    writeback_exit_code = _story_project_writeback_exit_code(result)
    if writeback_exit_code:
        raise SystemExit(writeback_exit_code)
    memory_exit_code = _memory_writeback_exit_code(result)
    if memory_exit_code:
        raise SystemExit(memory_exit_code)


def _reconcile_and_publish_persistence(
    run_dir: str | Path,
    *,
    chapter_dir: str | Path = DEFAULT_CHAPTER_DIR,
    state_paths: tuple[Path, ...] = (),
    expected_book_id: str | None = None,
    persistence_dir: str | Path | None = None,
) -> dict:
    runtime_fence = Path(run_dir).parent / ".root-remap-fence"
    with persistence_run_lock(runtime_fence):
        with persistence_run_lock(run_dir, state_paths=state_paths):
            return _reconcile_and_publish_persistence_locked(
                run_dir,
                chapter_dir=chapter_dir,
                expected_book_id=expected_book_id,
                persistence_dir=persistence_dir,
            )


def _reconcile_authority_persistence(
    run_dir: str | Path,
    *,
    project_identity: Any | None,
    story_project_root: str | Path | None = None,
    chapter_dir: str | Path = DEFAULT_CHAPTER_DIR,
    state_paths: tuple[Path, ...] = (),
    expected_book_id: str | None = None,
    persistence_dir: str | Path | None = None,
) -> dict:
    authority = getattr(project_identity, "authority", None)
    if isinstance(authority, dict) and authority.get("mode") == "event_v1":
        transaction_root = (
            Path(persistence_dir)
            if persistence_dir is not None
            else Path(run_dir) / "transactions"
        )
        report = dict(
            reconcile_pending_persistence_v2(
                transaction_root,
                expected_book_id=expected_book_id,
            )
        )
        report.setdefault("published_run_ids", [])
        report.setdefault("existing_run_ids", [])
        report.setdefault("publish_errors", [])
        report["pending_publication"] = [
            item.get("run_id")
            for item in report.get("transactions") or []
            if isinstance(item, dict)
            and item.get("state") in {"commit_marked", "publishing", "recovery_required"}
        ]
        report["ok"] = bool(report.get("ok")) and not report["pending_publication"]
        return report
    if _historical_event_authority_exists(
        story_project_root=story_project_root,
        persistence_dir=persistence_dir,
    ):
        raise PersistenceError(
            "event-authority downgrade detected; v1 reconcile/publisher is disabled"
        )
    legacy_kwargs: dict[str, Any] = {
        "chapter_dir": chapter_dir,
        "state_paths": state_paths,
    }
    if expected_book_id is not None:
        legacy_kwargs["expected_book_id"] = expected_book_id
    if persistence_dir is not None:
        legacy_kwargs["persistence_dir"] = persistence_dir
    return _reconcile_and_publish_persistence(run_dir, **legacy_kwargs)


def _historical_event_authority_exists(
    *,
    story_project_root: str | Path | None,
    persistence_dir: str | Path | None,
) -> bool:
    if story_project_root is not None:
        receipts = Path(story_project_root) / ".novelagent" / "authority" / "receipts"
        if receipts.is_dir():
            for path in receipts.glob("*.json"):
                try:
                    payload = json.loads(path.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError):
                    return True
                if isinstance(payload, dict) and payload.get("receipt_type") == "authority_activation":
                    return True
    if persistence_dir is not None:
        root = Path(persistence_dir)
        if (root / "root_registry.json").exists():
            return True
        if any((root / "registry" / "completed").glob("*.json")):
            return True
    return False


def _reconcile_and_publish_persistence_locked(
    run_dir: str | Path,
    *,
    chapter_dir: str | Path,
    expected_book_id: str | None = None,
    persistence_dir: str | Path | None = None,
) -> dict:
    report = reconcile_persistence(
        run_dir=run_dir,
        expected_book_id=expected_book_id,
        transactions_dir=persistence_dir,
    )
    published: list[str] = []
    skipped: list[str] = []
    errors: list[dict[str, str]] = []
    root = Path(run_dir)
    reconciled_transactions: list[dict] = []
    for transaction in report.get("transactions") or []:
        reconciled_transactions.append(transaction)
        if not isinstance(transaction, dict) or not transaction.get("committed"):
            continue
        if transaction.get("state") not in {"commit_marked", "completed"}:
            continue
        run_id = str(transaction.get("run_id") or "")
        journal = transaction.get("journal_path")
        if not run_id or not journal:
            continue
        destination = root / f"{run_id}.json"
        try:
            candidate = load_persistence_candidate(journal)
            if not isinstance(candidate, dict):
                raise ValueError("committed transaction has no candidate result")
            validate_run_result(candidate)
            _validate_persistence_publication_identity(candidate, transaction)
            if destination.exists():
                existing = json.loads(destination.read_text(encoding="utf-8"))
                validate_run_result(existing)
                _validate_persistence_publication_identity(existing, transaction)
                _validate_existing_publication(existing, candidate)
                if transaction.get("state") == "commit_marked":
                    planned = ((candidate.get("run") or {}).get("chapter") or {}).get("artifact") or {}
                    if not planned.get("path") or not Path(str(planned["path"])).exists():
                        _ensure_candidate_chapter_artifact(candidate, fallback_chapter_dir=chapter_dir)
                skipped.append(run_id)
            else:
                _deliver_candidate_postcommit_outbox(candidate)
                _ensure_candidate_chapter_artifact(candidate, fallback_chapter_dir=chapter_dir)
                atomic_create_json(destination, candidate)
                published.append(run_id)
            if transaction.get("state") == "commit_marked":
                completed = complete_persistence_transaction(journal).to_dict()
                reconciled_transactions[-1] = completed
        except Exception as exc:  # noqa: BLE001 - reconciliation reports ambiguity without overwriting.
            errors.append({"run_id": run_id, "error": f"{type(exc).__name__}: {exc}"})
    result = dict(report)
    result["transactions"] = reconciled_transactions
    result["published_run_ids"] = published
    result["existing_run_ids"] = skipped
    result["publish_errors"] = errors
    pending = [
        item.get("run_id")
        for item in reconciled_transactions
        if isinstance(item, dict) and item.get("state") == "commit_marked"
    ]
    result["pending_publication"] = pending
    result["ok"] = bool(report.get("ok")) and not errors and not pending
    return result


def _validate_persistence_publication_identity(candidate: dict, transaction: dict) -> None:
    run = candidate.get("run") if isinstance(candidate.get("run"), dict) else None
    if not isinstance(run, dict) or run.get("id") != transaction.get("run_id"):
        raise ValueError("published run id does not match persistence transaction")
    persistence = run.get("persistence") if isinstance(run.get("persistence"), dict) else None
    if not isinstance(persistence, dict) or persistence.get("run_id") != transaction.get("run_id"):
        raise ValueError("published persistence identity does not match transaction")
    expected_journal = Path(str(transaction.get("journal_path") or "")).resolve()
    actual_journal = Path(str(persistence.get("journal_path") or "")).resolve()
    if expected_journal != actual_journal:
        raise ValueError("published persistence journal does not match transaction")
    if not persistence.get("committed"):
        raise ValueError("published persistence candidate is not committed")


def _ensure_candidate_chapter_artifact(candidate: dict, *, fallback_chapter_dir: str | Path) -> None:
    run = candidate.get("run") if isinstance(candidate.get("run"), dict) else None
    chapter = candidate.get("chapter")
    if not isinstance(run, dict) or not isinstance(chapter, str):
        raise ValueError("committed candidate is missing run or chapter content")
    run_chapter = run.get("chapter") if isinstance(run.get("chapter"), dict) else None
    if not isinstance(run_chapter, dict):
        raise ValueError("committed candidate is missing run chapter metadata")
    planned = run_chapter.get("artifact") if isinstance(run_chapter.get("artifact"), dict) else None
    output_dir = Path(str(planned.get("path"))).parent if planned and planned.get("path") else Path(fallback_chapter_dir)
    expected = chapter_artifact_metadata(chapter_text=chapter, run=run, output_dir=output_dir)
    if planned and Path(str(planned.get("path"))).resolve() != Path(expected["path"]).resolve():
        raise ValueError("candidate chapter artifact path does not match run identity")
    run_chapter["artifact"] = save_chapter_artifact(chapter_text=chapter, run=run, output_dir=output_dir)


def _validate_existing_publication(existing: dict, candidate: dict) -> None:
    existing_run = existing["run"]
    candidate_run = candidate["run"]
    if existing.get("chapter") != candidate.get("chapter"):
        raise ValueError("existing run chapter does not match hash-bound candidate")
    for key in ("id", "chapter_index", "status", "accepted", "committed"):
        if existing_run.get(key) != candidate_run.get(key):
            raise ValueError(f"existing run {key} does not match hash-bound candidate")
    existing_chapter = existing_run.get("chapter") if isinstance(existing_run.get("chapter"), dict) else {}
    candidate_chapter = candidate_run.get("chapter") if isinstance(candidate_run.get("chapter"), dict) else {}
    existing_artifact = existing_chapter.get("artifact") if isinstance(existing_chapter.get("artifact"), dict) else {}
    candidate_artifact = candidate_chapter.get("artifact") if isinstance(candidate_chapter.get("artifact"), dict) else {}
    if existing_artifact.get("path") != candidate_artifact.get("path"):
        raise ValueError("existing chapter artifact path does not match hash-bound candidate")


def _deliver_candidate_postcommit_outbox(candidate: dict) -> None:
    run = candidate["run"]
    persistence = run.get("persistence") if isinstance(run.get("persistence"), dict) else {}
    publication = persistence.get("publication") if isinstance(persistence.get("publication"), dict) else {}
    memory = publication.get("memory_outbox") if isinstance(publication.get("memory_outbox"), dict) else {}
    status = str(memory.get("status") or "not_applicable")
    if status == "external_pending":
        raise RuntimeError("pending external memory delivery cannot be reconciled deterministically")
    if status not in {"pending", "failed"}:
        return
    if memory.get("target") != "file" or not memory.get("path"):
        raise ValueError("pending memory outbox is missing a deterministic file target")
    updates = memory.get("updates")
    if not isinstance(updates, list):
        raise ValueError("pending memory outbox is missing updates")
    writer = build_memory_writer(mode="file", outbox_path=str(memory["path"]))
    writeback = write_memory_updates(updates, writer)
    gate = memory.get("gate")
    if isinstance(gate, dict):
        writeback["gate"] = gate
    verification = writeback.get("verification") if isinstance(writeback.get("verification"), dict) else {}
    if verification.get("status") in {"failed", "error", "readback_failed"}:
        raise RuntimeError("pending memory outbox verification failed")
    candidate["memory_write"] = writeback
    run.setdefault("memory", {})["writeback"] = writeback
    updated_memory = dict(memory)
    updated_memory["status"] = "delivered"
    updated_publication = dict(publication)
    updated_publication["memory_outbox"] = updated_memory
    persistence["publication"] = updated_publication
    if isinstance(candidate.get("persistence"), dict):
        candidate["persistence"]["publication"] = updated_publication


def _persistence_state_paths_from_args(args: argparse.Namespace) -> tuple[Path, ...]:
    paths = [Path(str(args.snapshot))]
    story_project = getattr(args, "story_project", None)
    if story_project is not None:
        resolution = resolve_story_project_root(story_project)
        if resolution.root is not None:
            paths.append(Path(resolution.root))
    writer = build_memory_writer(
        mode=str(getattr(args, "memory_writeback", "none")),
        outbox_path=getattr(args, "memory_outbox", None),
        notion_readback=bool(getattr(args, "notion_readback", False)),
    )
    if hasattr(writer, "path"):
        paths.append(Path(getattr(writer, "path")))
    return tuple(paths)


def format_preflight_summary(result: dict) -> str:
    checks = result.get("checks", [])
    failed = [check for check in checks if not check.get("ok")]
    passed_count = len(checks) - len(failed)
    lines = [
        f"Preflight: {'OK' if result.get('ok') else 'FAILED'}",
        f"Checks: {passed_count} passed, {len(failed)} failed",
    ]

    for name, label in (
        ("runtime_state_summary", "Runtime state"),
        ("execution_mode", "Execution"),
        ("memory_input", "Memory input"),
        ("memory", "Memory"),
        ("memory_v2_compile", "Memory V2 compile"),
        ("story_project_structure", "StoryProject"),
        ("story_project_runtime_context", "StoryProject runtime"),
        ("oh_story_detection", "oh-story"),
        ("state_builder_audit", "State builder"),
        ("run_history", "Run history"),
        ("planned_workflow", "Workflow"),
        ("v1_structure", "V1 structure"),
        ("schema_assets", "Schemas"),
        ("schema_consistency", "Schema consistency"),
        ("prompt_assets", "Prompts"),
        ("memory_writeback", "Memory writeback"),
        ("artifact_targets", "Artifacts"),
        ("llm_validator", "LLM validator"),
        ("director", "Director"),
    ):
        check = _check_by_name(checks, name)
        if check is not None and check.get("ok"):
            lines.append(f"{label}: {_summarize_check(name, check.get('details'))}")

    if failed:
        lines.append("Failures:")
        for check in failed:
            message = check.get("error") or "failed"
            lines.append(f"- {check.get('name')}: {message}")
        lines.append("Use --check-json for full diagnostics.")

    return "\n".join(lines)


def format_init_runtime_summary(result: dict) -> str:
    lines = [
        "Runtime initialized:",
        f"- runtime_dir: {result.get('runtime_dir')}",
        f"- snapshot: {result.get('snapshot_path')}",
        f"- memory: {result.get('memory_path')}",
        f"- run_dir: {result.get('run_dir')}",
        f"- chapter_dir: {result.get('chapter_dir')}",
    ]
    copied = result.get("copied") if isinstance(result.get("copied"), list) else []
    skipped = result.get("skipped") if isinstance(result.get("skipped"), list) else []
    if copied:
        lines.append(f"- copied: {', '.join(str(item.get('name')) for item in copied if isinstance(item, dict))}")
    if skipped:
        lines.append(f"- skipped_existing: {', '.join(str(item.get('name')) for item in skipped if isinstance(item, dict))}")
    return "\n".join(lines)


def format_recovery_summary(result: dict) -> str:
    if not result.get("ok"):
        error = result.get("error") if isinstance(result.get("error"), dict) else {}
        return f"Recovery failed: {error.get('type')}: {error.get('message')}"
    artifact = result.get("artifact") if isinstance(result.get("artifact"), dict) else {}
    return "\n".join(
        [
            "Recovered chapter draft:",
            f"- source_run: {result.get('source_run_id')} ({result.get('source_status')})",
            f"- chapter_index: {result.get('chapter_index')}",
            f"- chars: {result.get('chars')}",
            f"- artifact: {artifact.get('path')}",
            "- snapshot_updated: False",
        ]
    )


def format_run_summary(result: dict) -> str:
    run = result.get("run") or {}
    validation = result.get("validation") or {}
    analysis = result.get("analysis") or {}
    loop = result.get("loop")
    lines = [
        "Chapter:",
        str(result.get("chapter") or "").strip(),
        "",
        "Run:",
        f"- id: {run.get('id')}",
        f"- status: {run.get('status')}",
        f"- committed: {run.get('committed')}",
        f"- chapter_index: {run.get('chapter_index')}",
        f"- workflow: {' -> '.join(str(action) for action in run.get('workflow', []))}",
        f"- repair_attempts: {run.get('repair_attempts', 0)}",
    ]
    runtime = run.get("runtime") if isinstance(run.get("runtime"), dict) else None
    if runtime is not None:
        lines.append(
            "- runtime: "
            f"{runtime.get('mode')} (authority={runtime.get('authority')}, "
            f"attempts={len(runtime.get('attempts') or [])}, cutover=False)"
        )
    if isinstance(loop, dict):
        lines.extend(
            [
                f"- loop_completed_steps: {loop.get('completed_steps')}",
                f"- loop_stopped_reason: {loop.get('stopped_reason')}",
            ]
        )
        if loop.get("session_id"):
            lines.append(f"- loop_session: {loop.get('session_id')}")
        if isinstance(loop.get("artifact"), dict) and loop["artifact"].get("path"):
            lines.append(f"- loop_artifact: {loop['artifact']['path']}")

    polish_failure = _recoverable_polish_failure(run)
    if polish_failure:
        lines.extend(
            [
                "",
                "Polish:",
                "- status: failed",
                "- result: using unpolished generated chapter",
                "- diagnostics: recorded in run trace",
            ]
        )

    error = run.get("error") if isinstance(run.get("error"), dict) else None
    if error:
        lines.extend(
            [
                "",
                "Error:",
                f"- type: {error.get('type')}",
                f"- message: {error.get('message')}",
            ]
        )

    model_calls = _run_model_calls(run)
    if model_calls:
        lines.extend(["", "Model Calls:"])
        for label, model_call in model_calls:
            lines.append(f"- {label}: {_format_model_call(model_call)}")

    artifacts = _run_artifacts(run)
    if artifacts:
        lines.append("- artifacts:")
        for label, path in artifacts:
            lines.append(f"  - {label}: {path}")

    review = run.get("review_pipeline") if isinstance(run.get("review_pipeline"), dict) else None
    if review and review.get("enabled"):
        lines.extend(
            [
                "",
                "Review pipeline:",
                f"- status: {review.get('status')}",
                f"- decision: {review.get('decision')}",
                f"- quality_score: {review.get('quality_score')}",
                f"- rule_score: {review.get('rule_score')}",
                f"- repair_tasks: {review.get('repair_task_count')} total, {review.get('blocking_task_count')} blocking",
            ]
        )
        if review.get("artifacts_dir"):
            lines.append(f"- artifacts: {review.get('artifacts_dir')}")
        if review.get("summary_path"):
            lines.append(f"- summary: {review.get('summary_path')}")
        if review.get("error"):
            lines.append(f"- error: {review.get('error')}")

    gate = run.get("review_gate") if isinstance(run.get("review_gate"), dict) else None
    if gate and gate.get("enabled"):
        lines.extend(
            [
                "",
                "Review gate:",
                f"- threshold: {gate.get('threshold')}",
                f"- status: {gate.get('status')}",
                f"- matched: {gate.get('matched')}",
                f"- exit_code: {gate.get('exit_code')}",
                f"- reason: {gate.get('reason')}",
            ]
        )

    review_index = run.get("review_index") if isinstance(run.get("review_index"), dict) else None
    if review_index and review_index.get("enabled"):
        lines.extend(
            [
                "",
                "Review index:",
                f"- status: {review_index.get('status')}",
                f"- index: {review_index.get('index_path')}",
                f"- latest_run_id: {review_index.get('latest_run_id')}",
                f"- entry_count: {review_index.get('entry_count')}",
            ]
        )
        if review_index.get("error"):
            lines.append(f"- error: {review_index.get('error')}")

    lines.extend(
        [
            "",
            "Validation:",
            f"- ok: {validation.get('ok')}",
            f"- problems: {len(validation.get('problems') or [])}",
        ]
    )
    lines.extend(_validation_coverage_summary(run.get("validation"), validation))
    problem_codes = (run.get("validation") or {}).get("problem_codes")
    if problem_codes:
        lines.append(f"- problem_codes: {', '.join(str(code) for code in problem_codes)}")

    if analysis:
        lines.extend(
            [
                "",
                "Analysis:",
                f"- summary: {analysis.get('summary', '')}",
                f"- events: {len(analysis.get('events') or [])}",
                f"- conflicts: {len(analysis.get('conflicts') or [])}",
                f"- world_changes: {len(analysis.get('world_changes') or [])}",
            ]
        )

    lines.append("")
    lines.append("Use --output-json for the full result or --output-run-json for the run record.")
    return "\n".join(lines)


def format_loop_failure_summary(payload: dict) -> str:
    session = payload.get("session") or {}
    error = payload.get("error") or session.get("error") or {}
    runs = payload.get("runs") if isinstance(payload.get("runs"), list) else []
    last_run = runs[-1].get("run") if runs and isinstance(runs[-1], dict) else None
    lines = [
        "Loop failed:",
        f"- session: {session.get('id')}",
        f"- completed_steps: {session.get('completed_steps')}",
        f"- stopped_reason: {session.get('stopped_reason')}",
        f"- committed: {session.get('committed_count')}",
        f"- rejected: {session.get('rejected_count')}",
        f"- failed: {session.get('failed_count')}",
        f"- error: {error.get('type')}: {error.get('message')}",
    ]
    artifact = session.get("artifact") if isinstance(session, dict) else None
    if isinstance(artifact, dict) and artifact.get("path"):
        lines.append(f"- loop_artifact: {artifact['path']}")
    if isinstance(last_run, dict):
        lines.append(f"- last_run: {last_run.get('id')} ({last_run.get('status')})")
        run_error = last_run.get("error") if isinstance(last_run.get("error"), dict) else None
        if run_error:
            lines.append(f"- last_run_error: {run_error.get('type')}: {run_error.get('message')}")
        for label, model_call in _run_model_calls(last_run):
            lines.append(f"- model_call_{label}: {_format_model_call(model_call)}")
    return "\n".join(lines)


def _run_artifacts(run: dict) -> list[tuple[str, str]]:
    artifacts: list[tuple[str, str]] = []
    for label, section in (
        ("chapter", run.get("chapter")),
        ("input_pack", run.get("input_pack")),
        ("snapshot_pack", run.get("snapshot_builder")),
    ):
        if isinstance(section, dict):
            artifact = section.get("artifact")
            if isinstance(artifact, dict) and artifact.get("path"):
                artifacts.append((label, str(artifact["path"])))
    chapter = run.get("chapter")
    pipeline = chapter.get("pipeline") if isinstance(chapter, dict) else None
    pipeline_artifacts = pipeline.get("artifacts") if isinstance(pipeline, dict) else None
    if isinstance(pipeline_artifacts, dict):
        for label in ("plan", "merged_chapter", "validation_report", "repair_deltas"):
            artifact = pipeline_artifacts.get(label)
            if isinstance(artifact, dict) and artifact.get("path"):
                artifacts.append((f"pipeline_{label}", str(artifact["path"])))
    return artifacts


def format_review_latest_summary(entry: dict | None) -> str:
    if not entry:
        return "No review entries found."
    lines = [
        "Latest review:",
        f"- run_id: {entry.get('run_id')}",
        f"- chapter_index: {entry.get('chapter_index')}",
        f"- review_status: {entry.get('review_status')}",
        f"- decision: {entry.get('review_decision')}",
        f"- quality_score: {entry.get('quality_score')}",
        f"- rule_score: {entry.get('rule_score')}",
        f"- repair_tasks: {entry.get('repair_task_count')} total, {entry.get('blocking_task_count')} blocking",
        (
            f"- gate: {entry.get('gate_status')} threshold={entry.get('gate_threshold')} "
            f"exit_code={entry.get('gate_exit_code')}"
        ),
    ]
    if entry.get("human_report_path"):
        lines.append(f"- human_report: {entry.get('human_report_path')}")
    if entry.get("repair_prompt_path"):
        lines.append(f"- repair_prompt: {entry.get('repair_prompt_path')}")
    if entry.get("summary_path"):
        lines.append(f"- summary: {entry.get('summary_path')}")
    return "\n".join(lines)


def format_story_project_compat_report(report: dict) -> str:
    summary = report.get("summary") if isinstance(report.get("summary"), dict) else {}
    lines = [
        "oh-story compatibility:",
        f"- root: {report.get('root')}",
        f"- detected: {report.get('detected')}",
        f"- confidence: {report.get('confidence')}",
        f"- markers: {summary.get('present_count', 0)} present, {summary.get('optional_missing_count', 0)} missing optional",
        f"- unsupported: {summary.get('unsupported_count', 0)}",
    ]
    warnings = report.get("warnings") if isinstance(report.get("warnings"), list) else []
    if warnings:
        lines.append(f"- warnings: {len(warnings)}")
    return "\n".join(lines)


def format_story_project_runtime_migration_summary(
    inspection: dict,
    *,
    migrated: dict | None = None,
) -> str:
    lines = [
        "StoryProject runtime migration:",
        f"- source: {inspection.get('source_runtime')}",
        f"- target: {inspection.get('target_runtime')}",
        f"- copy_allowed: {inspection.get('copy_allowed')}",
        f"- records: {len(inspection.get('records') or [])}",
        f"- problems: {len(inspection.get('problems') or [])}",
    ]
    if migrated is not None:
        lines.append(f"- migrated: {migrated.get('ok')}")
        lines.append(f"- manifest: {migrated.get('manifest_path')}")
    return "\n".join(lines)


def format_review_list_summary(entries: list[dict]) -> str:
    if not entries:
        return "No review entries found."
    lines = ["Recent reviews:"]
    for index, entry in enumerate(entries, start=1):
        lines.append(
            f"{index}. {entry.get('run_id')} - {entry.get('review_status')} - "
            f"gate={entry.get('gate_status')} - quality={entry.get('quality_score')} - rule={entry.get('rule_score')}"
        )
    return "\n".join(lines)


def format_review_dashboard_summary(metadata: dict) -> str:
    return "\n".join(
        [
            "Review dashboard generated:",
            f"- output: {metadata.get('output_path')}",
            f"- entries: {metadata.get('entry_count')}",
            f"- latest_run_id: {metadata.get('latest_run_id')}",
        ]
    )


def _validate_story_project_compat_report_args(args: argparse.Namespace) -> None:
    if bool(getattr(args, "story_project_compat_report", False)) and getattr(args, "story_project", None) is None:
        raise ValueError("--story-project-compat-report requires --story-project")


def _validate_story_project_shadow_report_args(args: argparse.Namespace) -> None:
    enabled = bool(getattr(args, "story_state_shadow_report", False))
    if enabled and getattr(args, "story_project", None) is None:
        raise ValueError("--story-state-shadow-report requires --story-project")
    if enabled and bool(getattr(args, "story_project_compat_report", False)):
        raise ValueError("--story-state-shadow-report cannot be combined with --story-project-compat-report")
    if enabled and (
        getattr(args, "inspect_story_project_runtime_from", None)
        or getattr(args, "migrate_story_project_runtime_from", None)
    ):
        raise ValueError("--story-state-shadow-report cannot be combined with StoryProject runtime migration")


def _validate_event_authority_migration_preview_args(args: argparse.Namespace) -> None:
    enabled = bool(getattr(args, "preview_event_authority_migration", False))
    created_at = getattr(args, "migration_preview_created_at", None)
    if created_at and not enabled:
        raise ValueError(
            "--migration-preview-created-at requires --preview-event-authority-migration"
        )
    if not enabled:
        return
    if getattr(args, "story_project", None) is None:
        raise ValueError("--preview-event-authority-migration requires --story-project")
    incompatible = {
        "activate_story_state": "--activate-story-state",
        "check": "--check",
        "init_runtime": "--init-runtime",
        "inspect_story_project_runtime_from": "--inspect-story-project-runtime-from",
        "migrate_story_project_runtime_from": "--migrate-story-project-runtime-from",
        "reconcile_persistence": "--reconcile-persistence",
        "recover_latest": "--recover-latest",
        "recover_locked_chapter": "--recover-locked-chapter",
        "report_runs": "--report-runs",
        "review_dashboard": "--review-dashboard",
        "review_latest": "--review-latest",
        "review_list": "--review-list",
        "story_project_compat_report": "--story-project-compat-report",
        "story_project_writeback": "--story-project-writeback",
        "story_project_writeback_dry_run": "--story-project-writeback-dry-run",
        "story_state_shadow_report": "--story-state-shadow-report",
    }
    combined = [label for field, label in incompatible.items() if getattr(args, field, False)]
    if combined:
        raise ValueError(
            "--preview-event-authority-migration cannot be combined with " + ", ".join(combined)
        )


def _validate_story_state_activation_args(args: argparse.Namespace) -> None:
    enabled = bool(getattr(args, "activate_story_state", False))
    report = getattr(args, "story_state_calibration_report", None)
    if enabled and getattr(args, "story_project", None) is None:
        raise ValueError("--activate-story-state requires --story-project")
    if enabled and not report:
        raise ValueError("--activate-story-state requires --story-state-calibration-report")
    if report and not enabled:
        raise ValueError("--story-state-calibration-report requires --activate-story-state")
    if enabled and (
        bool(getattr(args, "story_state_shadow_report", False))
        or bool(getattr(args, "story_project_compat_report", False))
        or bool(getattr(args, "preview_event_authority_migration", False))
        or getattr(args, "inspect_story_project_runtime_from", None)
        or getattr(args, "migrate_story_project_runtime_from", None)
    ):
        raise ValueError("--activate-story-state cannot be combined with report or migration commands")


def _build_story_state_shadow_report(args: argparse.Namespace) -> dict:
    root = Path(args._resolved_story_project_root)
    validation = validate_story_project(
        story_project=root,
        chapter=args.chapter,
        workspace_root=Path.cwd(),
        allow_existing_prose=True,
    )
    if validation.problems:
        details = "; ".join(f"{problem.code}: {problem.message}" for problem in validation.problems)
        raise ValueError(details)
    chapter_resolution = validation.chapter_resolution
    if chapter_resolution is None or chapter_resolution.resolved_chapter is None:
        raise ValueError("StoryProject chapter could not be resolved")
    identity = project_identity_for_operation(root, persist=False)
    state = parse_story_project_semantic_state(
        root,
        chapter_resolution.resolved_chapter,
        project_identity=identity,
    )
    snapshot_path = Path(args.snapshot)
    snapshot = load_snapshot(snapshot_path) if snapshot_path.is_file() else None
    return build_story_project_shadow_report(state, snapshot=snapshot)


def _validate_story_project_runtime_migration_args(args: argparse.Namespace) -> None:
    inspect_source = getattr(args, "inspect_story_project_runtime_from", None)
    migrate_source = getattr(args, "migrate_story_project_runtime_from", None)
    if inspect_source and migrate_source:
        raise ValueError(
            "--inspect-story-project-runtime-from and --migrate-story-project-runtime-from are mutually exclusive"
        )
    if (inspect_source or migrate_source) and getattr(args, "story_project", None) is None:
        raise ValueError("StoryProject runtime migration requires --story-project")
    if (inspect_source or migrate_source) and bool(getattr(args, "init_runtime", False)):
        raise ValueError("StoryProject runtime migration cannot be combined with --init-runtime")
    if (inspect_source or migrate_source) and bool(getattr(args, "story_project_compat_report", False)):
        raise ValueError("StoryProject runtime migration cannot be combined with --story-project-compat-report")


def _build_story_project_compat_report(args: argparse.Namespace) -> dict:
    resolution = resolve_story_project_root(args.story_project)
    root = resolution.root if resolution.root is not None else None
    try:
        report = detect_oh_story_compatibility(root, workspace_root=Path.cwd())
    except Exception as exc:  # noqa: BLE001 - report mode is read-only and diagnostic.
        report = failed_oh_story_compatibility_report(root, exc, workspace_root=Path.cwd())
    if resolution.error:
        report = _report_with_warning(report, resolution.error)
    return report


def _detect_story_project_context_compatibility(story_project_context) -> dict | None:
    root = getattr(story_project_context, "story_project_root", None)
    try:
        return detect_oh_story_compatibility(root, workspace_root=Path.cwd())
    except Exception as exc:  # noqa: BLE001 - oh-story detection never blocks generation.
        return failed_oh_story_compatibility_report(root, exc, workspace_root=Path.cwd())


def _report_with_warning(report: dict, warning: str) -> dict:
    updated = dict(report)
    warnings = list(updated.get("warnings") or [])
    warnings.append(str(warning))
    updated["warnings"] = list(dict.fromkeys(warnings))
    return updated


def _review_gate_exit_code(result: dict | None) -> int:
    if not isinstance(result, dict):
        return 0
    run = result.get("run") if isinstance(result.get("run"), dict) else {}
    gate = run.get("review_gate") if isinstance(run.get("review_gate"), dict) else result.get("review_gate")
    if not isinstance(gate, dict):
        return 0
    return 1 if gate.get("exit_code") == 1 else 0


def _story_project_writeback_exit_code(result: dict | None) -> int:
    if not isinstance(result, dict):
        return 0
    run = result.get("run") if isinstance(result.get("run"), dict) else {}
    story_project = run.get("story_project") if isinstance(run.get("story_project"), dict) else {}
    writeback = story_project.get("writeback") if isinstance(story_project.get("writeback"), dict) else {}
    if not writeback.get("attempted") or writeback.get("dry_run"):
        return 0
    return 0 if writeback.get("applied") else 1


def _memory_writeback_exit_code(result: dict | None) -> int:
    if not isinstance(result, dict):
        return 0
    run = result.get("run") if isinstance(result.get("run"), dict) else {}
    memory = run.get("memory") if isinstance(run.get("memory"), dict) else {}
    writeback = memory.get("writeback") if isinstance(memory.get("writeback"), dict) else {}
    verification = writeback.get("verification") if isinstance(writeback.get("verification"), dict) else {}
    return 1 if verification.get("status") in {"failed", "error"} else 0


def _run_model_calls(run: dict) -> list[tuple[str, dict]]:
    model_calls: list[tuple[str, dict]] = []
    director = run.get("director") if isinstance(run.get("director"), dict) else {}
    director_call = director.get("model_call") if isinstance(director, dict) else None
    if isinstance(director_call, dict):
        model_calls.append(("director", director_call))

    trace = run.get("trace")
    if isinstance(trace, list):
        for event in trace:
            if not isinstance(event, dict):
                continue
            if _is_recoverable_polish_failure_event(event):
                continue
            model_call = event.get("model_call")
            if isinstance(model_call, dict):
                label = str(event.get("action") or "workflow")
                model_calls.append((label, model_call))
    return model_calls


def _recoverable_polish_failure(run: dict) -> dict | None:
    trace = run.get("trace")
    if not isinstance(trace, list):
        return None
    for event in trace:
        if isinstance(event, dict) and _is_recoverable_polish_failure_event(event):
            return event
    return None


def _is_recoverable_polish_failure_event(event: dict) -> bool:
    return (
        event.get("action") == "polish"
        and event.get("status") == "failed"
        and event.get("plan_failure_policy") == "continue_unpolished"
    )


def _format_model_call(model_call: dict) -> str:
    parts = [
        str(model_call.get("provider") or "unknown"),
        str(model_call.get("stage") or "unknown"),
    ]
    if model_call.get("model"):
        parts.append(f"model={model_call.get('model')}")
    if model_call.get("cause_type"):
        parts.append(f"cause={model_call.get('cause_type')}")
    if model_call.get("failure_category"):
        parts.append(f"category={model_call.get('failure_category')}")
    if model_call.get("retryable") is not None:
        parts.append(f"retryable={str(bool(model_call.get('retryable'))).lower()}")
    if model_call.get("attempts"):
        parts.append(f"attempts={model_call.get('attempts')}")
    if model_call.get("elapsed_ms") is not None:
        parts.append(f"elapsed_ms={model_call.get('elapsed_ms')}")
    if model_call.get("message"):
        parts.append(f"message={model_call.get('message')}")
    return " ".join(parts)


def _validation_coverage_summary(run_validation, full_validation) -> list[str]:
    compact = run_validation if isinstance(run_validation, dict) else {}
    full = full_validation if isinstance(full_validation, dict) else {}
    requested = _list_value(compact.get("requested_focus") or full.get("requested_focus"))
    executed = _list_value(compact.get("executed_checks") or full.get("executed_checks"))
    skipped = _list_value(compact.get("skipped_checks") or full.get("skipped_checks"))
    lines: list[str] = []
    if requested:
        lines.append(f"- requested_focus: {', '.join(requested)}")
    if executed:
        lines.append(f"- executed_checks: {', '.join(executed)}")
    if skipped:
        lines.append(f"- skipped_checks: {', '.join(skipped)}")
    return lines


def _list_value(value) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(item) for item in value if item]


def _check_by_name(checks: list[dict], name: str) -> dict | None:
    for check in checks:
        if check.get("name") == name:
            return check
    return None


def _summarize_check(name: str, details) -> str:
    if name == "runtime_state_summary" and isinstance(details, dict):
        return (
            f"chapter={details.get('chapter_index')}, "
            f"memory_items={details.get('memory_items')}, "
            f"constraints={details.get('constraints')}"
        )
    if name == "planned_workflow":
        if isinstance(details, list):
            return " -> ".join(str(action) for action in details)
        if isinstance(details, dict):
            return str(details.get("note") or details.get("source") or details)
    if name in {"schema_assets", "prompt_assets", "v1_structure"} and isinstance(details, dict):
        return f"{details.get('count')} files"
    if name == "execution_mode" and isinstance(details, dict):
        calls = details.get("model_calls") or []
        call_text = ",".join(str(call) for call in calls) if calls else "none"
        return (
            f"dry_run={details.get('dry_run')}, persist={details.get('persist')}, "
            f"steps={details.get('steps')}, model_calls={call_text}"
        )
    if name == "memory" and isinstance(details, dict):
        summary = (
            f"{details.get('source')} status={details.get('status')} "
            f"items={details.get('item_count')}"
        )
        if "source_mapping_count" in details:
            summary += f" mappings={details.get('source_mapping_count')}"
        return summary
    if name == "memory_v2_compile" and isinstance(details, dict):
        return (
            f"dry_run={details.get('dry_run')} reset={details.get('reset')} "
            f"ops={details.get('operation_count')} events={details.get('event_count')} "
            f"revision={details.get('canonical_revision')}"
        )
    if name == "story_project_structure" and isinstance(details, dict):
        root = details.get("root") if isinstance(details.get("root"), dict) else {}
        chapter = details.get("chapter_resolution") if isinstance(details.get("chapter_resolution"), dict) else {}
        problems = details.get("problems") if isinstance(details.get("problems"), list) else []
        return (
            f"root={root.get('root')} source={root.get('source')} "
            f"chapter={chapter.get('resolved_chapter')} problems={len(problems)}"
        )
    if name == "story_project_runtime_context" and isinstance(details, dict):
        source_paths = details.get("source_paths") if isinstance(details.get("source_paths"), dict) else {}
        memory_overlay = details.get("memory_context_overlay") if isinstance(details.get("memory_context_overlay"), dict) else {}
        return (
            f"chapter={details.get('chapter_index')} "
            f"outline={source_paths.get('outline_path')} "
            f"items={len(memory_overlay.get('items') or [])} "
            f"warnings={len(details.get('warnings') or [])} "
            f"missing={len(details.get('missing_fields') or [])}"
        )
    if name == "oh_story_detection" and isinstance(details, dict):
        summary = details.get("summary") if isinstance(details.get("summary"), dict) else {}
        return (
            f"detected={details.get('detected')} "
            f"confidence={details.get('confidence')} "
            f"markers={summary.get('present_count', 0)} "
            f"unsupported={summary.get('unsupported_count', 0)}"
        )
    if name == "state_builder_audit" and isinstance(details, dict):
        return (
            f"items={details.get('item_count')} "
            f"applied={details.get('applied_count')} "
            f"skipped={details.get('skipped_count')} "
            f"deduplicated={details.get('deduplicated_count')} "
            f"applied_types={_format_count_entries(details.get('applied_type_counts'), 'type')} "
            f"skipped_types={_format_count_entries(details.get('skipped_type_counts'), 'type')} "
            f"skipped_blocking={details.get('skipped_blocking_count', 0)} "
            f"reasons={_format_count_entries(details.get('skipped_reason_counts'), 'reason_code')} "
            f"severity={_format_count_entries(details.get('skipped_severity_counts'), 'severity')}"
        )
    if name == "memory_input" and isinstance(details, dict):
        resolved = details.get("resolved_source")
        reason = details.get("resolution_reason")
        path = details.get("resolved_path")
        if path:
            return f"{resolved} ({path}) reason={reason}"
        return f"{resolved} reason={reason}"
    if name == "run_history" and isinstance(details, dict):
        latest = details.get("latest_run_id")
        if latest:
            summary = (
                f"runs={details.get('loaded')}/{details.get('total')} "
                f"latest={latest} status={details.get('latest_run_status')}"
            )
            executed_checks = details.get("latest_run_executed_checks")
            if isinstance(executed_checks, list) and executed_checks:
                summary += f" checks={','.join(str(item) for item in executed_checks)}"
            skipped_checks = details.get("latest_run_skipped_checks")
            if isinstance(skipped_checks, list) and skipped_checks:
                summary += f" skipped={','.join(str(item) for item in skipped_checks)}"
            return summary
        return f"runs={details.get('loaded')}/{details.get('total')} latest=none"
    if name == "schema_consistency" and isinstance(details, dict):
        return f"{details.get('count')} contracts"
    if name == "memory_writeback" and isinstance(details, dict):
        mode = details.get("mode")
        path = details.get("path")
        suffix = ""
        if mode == "notion" and details.get("notion_readback"):
            suffix = " readback=True"
        return f"{mode} ({path}){suffix}" if path else f"{mode}{suffix}"
    if name == "artifact_targets" and isinstance(details, dict):
        return f"run_dir={details.get('run_dir')}, chapter_dir={details.get('chapter_dir')}"
    if name == "director" and isinstance(details, dict):
        model = details.get("model")
        return f"{details.get('mode')} ({model})" if model else str(details.get("mode"))
    if name == "llm_validator" and isinstance(details, dict):
        return f"enabled={details.get('enabled')}"
    return str(details)


def _format_count_entries(entries, key: str) -> str:
    if not isinstance(entries, list) or not entries:
        return "none"
    parts: list[str] = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        name = entry.get(key)
        count = entry.get("count")
        if name is None or count is None:
            continue
        parts.append(f"{name}={count}")
    return ",".join(parts) if parts else "none"


if __name__ == "__main__":
    main()
