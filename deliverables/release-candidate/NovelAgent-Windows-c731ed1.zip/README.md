# NovelAgent · Windows 本地自用候选版

首次使用，请打开[作者使用指南](docs/windows-author.md)。

[自用上线标准](docs/product-validation.md) · [包内文件校验清单](candidate-manifest.json)
