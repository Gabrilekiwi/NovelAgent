from __future__ import annotations

import json
import re
import warnings
from typing import Any

from api.contracts import (
    CHAPTER_CONTRACT,
    ModelOutputError,
    validate_language_output,
    validate_text_output,
)
from api.openai_client import chat_completion
from core.context_budget import ContextBudgetError, default_context_budget
from core.model_calls import build_scene_generation_call_id
from core.prompt_compiler import PROMPT_CONTEXT_SELECTION_KEYS, compile_prompt_contexts
from core.quality.final_artifact_integrity import (
    FinalArtifactIntegrityGate,
    build_integrity_stage_record,
)
from core.scene_continuity import (
    empty_scene_state,
    normalize_scene_state,
    require_scene_transition,
    scene_delta_response_schema,
    scene_state_generation_projection,
    scene_state_summary,
    validate_scene_transition,
)
from core.schema import validate_schema
from core.state.authoritative_context import (
    AUTHORITATIVE_SCENE_SECTION_MAX_CHARS,
    authoritative_event_is_open,
    authoritative_state_from_markdown,
    compact_authoritative_state_in_markdown,
)
from core.state.generation_state_view import (
    SCENE_GENERATION_STATE_REFERENCE_HEADING,
    build_scene_generation_state_reference,
    filter_scene_state_for_generation,
    generation_state_view_from_markdown,
    project_bookkeeping_for_generation,
    scene_generation_state_reference_from_markdown,
)
from core.state.story_state_context import STORY_STATE_CONTEXT_KEYS, STORY_STATE_SECTION_MAX_CHARS
from core.structured_context import (
    StructuredContextError,
    compact_markdown_context,
    select_text_blocks,
)
from core.story_project.coverage import (
    blueprint_to_dict,
    build_blueprint_coverage,
    build_blueprint_plan,
    ending_requirement,
    validate_generation_blueprint_contract,
)
from modules.chapter_generator.generator import _DRY_RUN_CHAPTER, _load_scene_prompt


PIPELINE_STAGE_NAMES = (
    "plan_chapter",
    "generate_scenes",
    "merge_scenes",
    "validate",
    "repair",
    "commit",
)
_STORY_PROJECT_BLUEPRINT_SECTION_MAX_CHARS = 4_096
_SCENE_INPUT_HEADROOM_TOKENS = 2_000
_CHAPTER_PLAN_PROMPT = (
    "Create a compact chapter plan as JSON only. "
    "Schema: {\"goal\": string, \"scenes\": [{\"index\": int, \"type\": string, "
    "\"goal\": string, \"required_beats\": [string], \"planned_events\": "
    "[{\"event_id\": string, \"type\": string, \"subjects\": [string], "
    "\"objects\": [string], \"location\": string, \"status\": \"completed\"}]}]}. "
    "Give every beat a stable event_id scoped to exactly one scene. Keep it to "
    "2-4 scenes. Scene 1 must be type opening_bridge and continue directly from "
    "the last chapter ending."
)
_SCENE_BOUNDARY_REGENERATION_LIMIT = 2
_SCENE_BOUNDARY_FEEDBACK_FINDING_LIMIT = 4
_SCENE_BOUNDARY_FEEDBACK_EVIDENCE_MAX_CHARS = 480
_LEGACY_SCENE_COMPLETED_EVENT_RECORD_LIMITS = (None, 12, 6, 0)
_SCENE_ADMISSION_COMPLETED_EVENT_ID_LIMIT = 8
_SCENE_PROMPT_AUDIT_RECORD_FIELDS = frozenset(
    {
        "after",
        "before",
        "field",
        "reason",
        "scene_index",
        "source_event_id",
        "source_tier",
        "last_seen_chapter",
    }
)
_EVENT_LOCATION_CONTRACT = (
    "Use one exact, non-compound location for each event.location. Every known entity "
    "listed in event.subjects or event.objects is asserted to be physically present "
    "there. Omit remote or differently located entities from that event, and make each "
    "matching deltas.locations delta.after exactly equal event.location. A "
    "deltas.characters location field does not establish physical presence for an event. "
    "For example, if 赵铁 remains downstairs on radio while 陆沉 and 顾岚 are on the roof, "
    "the roof event must omit 赵铁 from subjects and objects; prose may still describe "
    "his remote coordination."
)
_SCENE_CONTEXT_PAYLOAD_POLICIES = (
    {
        "context_section_chars": 1_500,
        "previous_tail_chars": 600,
        "summary_limit": 8,
        "summary_tail_chars": 280,
        "include_summary_goal": True,
    },
    {
        "context_section_chars": 1_500,
        "previous_tail_chars": 500,
        "summary_limit": 8,
        "summary_tail_chars": 200,
        "include_summary_goal": False,
    },
    {
        "context_section_chars": 1_500,
        "previous_tail_chars": 400,
        "summary_limit": 8,
        "summary_tail_chars": 120,
        "include_summary_goal": False,
    },
    {
        "context_section_chars": 1_500,
        "previous_tail_chars": 360,
        "summary_limit": 6,
        "summary_tail_chars": 120,
        "include_summary_goal": False,
    },
    {
        "context_section_chars": 1_500,
        "previous_tail_chars": 300,
        "summary_limit": 4,
        "summary_tail_chars": 80,
        "include_summary_goal": False,
    },
    {
        "context_section_chars": 1_500,
        "previous_tail_chars": 240,
        "summary_limit": 4,
        "summary_tail_chars": 40,
        "include_summary_goal": False,
    },
    {
        "context_section_chars": 1_500,
        "previous_tail_chars": 200,
        "summary_limit": 4,
        "summary_tail_chars": 0,
        "include_summary_goal": False,
    },
    {
        "context_section_chars": 1_450,
        "previous_tail_chars": 160,
        "summary_limit": 4,
        "summary_tail_chars": 0,
        "include_summary_goal": False,
    },
    {
        "context_section_chars": 1_400,
        "previous_tail_chars": 120,
        "summary_limit": 4,
        "summary_tail_chars": 0,
        "include_summary_goal": False,
    },
    {
        "context_section_chars": 1_000,
        "previous_tail_chars": 80,
        "summary_limit": 3,
        "summary_tail_chars": 0,
        "include_summary_goal": False,
    },
    {
        "context_section_chars": 800,
        "previous_tail_chars": 0,
        "summary_limit": 2,
        "summary_tail_chars": 0,
        "include_summary_goal": False,
    },
)


def run_chapter_pipeline(
    input_pack: str,
    *,
    chapter_index: int,
    dry_run: bool = False,
    scene_limit: int | None = None,
    language: str | None = None,
    chapter_blueprint: dict[str, Any] | None = None,
    recovered_scene_drafts: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    blueprint = blueprint_to_dict(chapter_blueprint)
    initial_scene_state = _initial_scene_state(input_pack)
    authoritative_state_source = authoritative_state_from_markdown(input_pack)
    generation_state_view_source = generation_state_view_from_markdown(
        input_pack
    )
    prompt_contexts = compile_prompt_contexts(
        input_pack,
        budget=default_context_budget(enable_model_tokenizer=not dry_run),
        stage_protocol_texts=(
            {"plan": (_CHAPTER_PLAN_PROMPT,)}
            if blueprint is None
            else None
        ),
    )
    plan_input = prompt_contexts.plan.text
    scene_input = prompt_contexts.scene.text
    if blueprint is None:
        plan = plan_scenes(plan_input, chapter_index=chapter_index, dry_run=dry_run)
        plan = _limit_plan_scenes(plan, scene_limit)
    else:
        validate_generation_blueprint_contract(blueprint)
        plan = plan_scenes(
            plan_input,
            chapter_index=chapter_index,
            dry_run=dry_run,
            chapter_blueprint=blueprint,
            scene_limit=scene_limit,
        )
    scenes = generate_scenes(
        scene_input,
        plan,
        dry_run=dry_run,
        language=language,
        chapter_blueprint=blueprint,
        recovered_scene_drafts=recovered_scene_drafts,
        initial_scene_state=initial_scene_state,
        authoritative_state_source=authoritative_state_source,
        generation_state_view_source=generation_state_view_source,
    )
    merged, scene_spans = _merge_scene_texts(scenes)
    merged = validate_language_output(merged, CHAPTER_CONTRACT, language=language)
    scene_events = [
        event
        for scene in scenes
        for event in (scene.get("events") or [])
        if isinstance(event, dict)
    ]
    merge_integrity = FinalArtifactIntegrityGate().evaluate(
        artifact_text=merged,
        stage="merge",
        scene_events=scene_events,
        scene_drafts=scenes,
        scene_spans=scene_spans,
    )
    blueprint_coverage = build_blueprint_coverage(blueprint, scenes, merged) if blueprint is not None else None
    boundary_validations = [
        dict(scene["boundary_validation"])
        for scene in scenes
        if isinstance(scene.get("boundary_validation"), dict)
    ]
    final_scene_state = (
        dict(scenes[-1]["scene_state_after"])
        if scenes and isinstance(scenes[-1].get("scene_state_after"), dict)
        else empty_scene_state()
    )
    return validate_schema(
        {
            "chapter_index": int(chapter_index),
            "story_project": {"enabled": True} if blueprint is not None else None,
            "chapter_blueprint": blueprint,
            "plan": plan,
            "scene_drafts": scenes,
            "merged_chapter": merged,
            "scene_spans": scene_spans,
            "scene_boundary_validations": boundary_validations,
            "scene_state_final": final_scene_state,
            "integrity": {"merge": merge_integrity},
            "integrity_records": [
                build_integrity_stage_record(
                    stage="merge",
                    input_text=None,
                    output_text=merged,
                    report=merge_integrity,
                )
            ],
            "blueprint_coverage": blueprint_coverage,
            "context_budget": {
                "context_digest": prompt_contexts.context_digest,
                "plan": prompt_contexts.plan.report,
                "scene": prompt_contexts.scene.report,
                "repair": prompt_contexts.repair.report,
                "plan_sections": list(prompt_contexts.plan.selected_sections),
                "scene_sections": list(prompt_contexts.scene.selected_sections),
                "repair_sections": list(prompt_contexts.repair.selected_sections),
                "plan_selection": dict(prompt_contexts.plan.selection_manifest),
                "scene_selection": dict(prompt_contexts.scene.selection_manifest),
                "repair_selection": dict(prompt_contexts.repair.selection_manifest),
            },
            "stages": _pipeline_stages(
                {
                    "plan_chapter": {
                        "status": "completed",
                        "artifact_key": "plan",
                        "summary": {"scene_count": len(plan.get("scenes", []))},
                    },
                    "generate_scenes": {
                        "status": "completed",
                        "artifact_key": "scene_drafts",
                        "summary": {"scene_count": len(scenes)},
                    },
                    "merge_scenes": {
                        "status": "completed",
                        "artifact_key": "merged_chapter",
                        "summary": {"chars": len(merged)},
                    },
                    **(
                        {
                            "validate": {
                                "status": "pending",
                                "artifact_key": "blueprint_coverage",
                                "summary": blueprint_coverage,
                            }
                        }
                        if blueprint_coverage is not None
                        else {}
                    ),
                }
            ),
        },
        "chapter_pipeline.schema.json",
    )


def plan_scenes(
    input_pack: str,
    *,
    chapter_index: int,
    dry_run: bool = False,
    chapter_blueprint: dict[str, Any] | None = None,
    scene_limit: int | None = None,
) -> dict[str, Any]:
    blueprint = blueprint_to_dict(chapter_blueprint)
    if blueprint is not None:
        return _validate_plan(
            build_blueprint_plan(blueprint, scene_limit=scene_limit),
            chapter_index=chapter_index, blueprint_plan=True,
        )

    if dry_run:
        return _validate_plan(_dry_run_plan(chapter_index), chapter_index=chapter_index)

    payload = _request_chapter_plan(input_pack, _CHAPTER_PLAN_PROMPT)
    try:
        plan = _load_plan_json(payload)
    except json.JSONDecodeError as first_exc:
        repair_payload = _request_chapter_plan_json_repair(input_pack, chapter_index, payload, first_exc)
        try:
            plan = _load_plan_json(repair_payload)
        except json.JSONDecodeError as exc:
            raise ValueError("Chapter plan response was not valid JSON") from exc
    if not isinstance(plan, dict):
        raise ValueError("Chapter plan response must be a JSON object")
    return _validate_plan(plan, chapter_index=chapter_index)


def plan_chapter(
    input_pack: str,
    *,
    chapter_index: int,
    dry_run: bool = False,
    chapter_blueprint: dict[str, Any] | None = None,
    scene_limit: int | None = None,
) -> dict[str, Any]:
    """Deprecated compatibility alias for :func:`plan_scenes`."""

    warnings.warn(
        "plan_chapter() is deprecated; use plan_scenes() instead",
        FutureWarning,
        stacklevel=2,
    )
    return plan_scenes(
        input_pack,
        chapter_index=chapter_index,
        dry_run=dry_run,
        chapter_blueprint=chapter_blueprint,
        scene_limit=scene_limit,
    )


def _request_chapter_plan(input_pack: str, prompt: str) -> str:
    default_context_budget().require_input(
        input_pack,
        stage="plan",
        protocol_texts=(prompt,),
    )
    return chat_completion(
        [
            {"role": "system", "content": prompt},
            {"role": "user", "content": input_pack},
        ],
        temperature=0.2,
        stage="chapter_generation",
    )


def _request_chapter_plan_json_repair(
    input_pack: str,
    chapter_index: int,
    invalid_payload: str,
    error: json.JSONDecodeError,
) -> str:
    query = f"chapter plan JSON repair\n{error}"
    input_selection = compact_markdown_context(
        input_pack,
        max_chars=6_000,
        per_section_max_chars=1_200,
        query=query,
        required_sections={
            "Context Digest",
            "Prompt Context Selection",
            "Director Decision",
            "Story State",
            "StoryProject Chapter Blueprint",
            "Requirements",
        },
        excluded_sections={"Memory Index", "Structured Context Manifest"},
        required_json_keys={
            "Prompt Context Selection": PROMPT_CONTEXT_SELECTION_KEYS,
            "Story State": STORY_STATE_CONTEXT_KEYS,
            "StoryProject Chapter Blueprint": {"chapter_blueprint", "read_set_context_digest"},
        },
        allowed_json_keys={
            "Prompt Context Selection": PROMPT_CONTEXT_SELECTION_KEYS,
            "Story State": STORY_STATE_CONTEXT_KEYS,
        },
        section_max_chars={
            "Story State": STORY_STATE_SECTION_MAX_CHARS,
            "StoryProject Chapter Blueprint": _STORY_PROJECT_BLUEPRINT_SECTION_MAX_CHARS,
        },
        policy="plan_json_repair_input_v1",
    )
    invalid_selection = select_text_blocks(
        invalid_payload,
        max_chars=4_000,
        query=str(error),
        required="edges",
        prefer_recent=False,
        policy="invalid_plan_response_blocks_v1",
    )
    request_payload = json.dumps(
        {
            "chapter_index": chapter_index,
            "json_error": str(error),
            "invalid_response": invalid_selection.text,
            "invalid_response_selection": invalid_selection.manifest(),
            "input_pack_excerpt": input_selection.text,
            "input_pack_selection": input_selection.manifest(),
        },
        ensure_ascii=False,
        indent=2,
    )
    default_context_budget().require_input(request_payload, stage="plan_json_repair")
    return chat_completion(
        [
            {
                "role": "system",
                "content": (
                    "Repair the chapter plan response into JSON only. "
                    "Return exactly one object with shape "
                    "{\"goal\": string, \"scenes\": [{\"index\": int, \"type\": string, "
                    "\"goal\": string, \"required_beats\": [string], \"planned_events\": "
                    "[{\"event_id\": string, \"type\": string, \"subjects\": [string], "
                    "\"objects\": [string], \"location\": string, \"status\": \"completed\"}]}]}. "
                    "No prose, no Markdown, no explanation."
                ),
            },
            {
                "role": "user",
                "content": request_payload,
            },
        ],
        temperature=0.0,
        stage="chapter_generation",
    )


def _load_plan_json(payload: str) -> Any:
    text = _structured_json_text(payload)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start < 0 or end <= start:
            raise
        return json.loads(text[start : end + 1])


def _structured_json_text(payload: str) -> str:
    text = str(payload or "").strip()
    fenced = re.search(r"```(?:json)?\s*(.*?)```", text, flags=re.IGNORECASE | re.DOTALL)
    if fenced:
        text = fenced.group(1).strip()
    return text


def _repair_premature_scene_object_close(payload: str) -> dict[str, Any] | None:
    """Repair one extra top-level brace at an unambiguous scene-field boundary."""

    text = _structured_json_text(payload)
    try:
        prefix, prefix_end = json.JSONDecoder().raw_decode(text)
    except json.JSONDecodeError:
        return None
    if not isinstance(prefix, dict):
        return None
    remainder = text[prefix_end:]
    boundary = (set(prefix), remainder.lstrip())
    valid_boundaries = (
        ({"prose"}, ',"events"'),
        ({"prose", "events", "deltas"}, ',"continuity_note"'),
    )
    if not any(
        prefix_keys == boundary[0] and boundary[1].startswith(next_field)
        for prefix_keys, next_field in valid_boundaries
    ):
        return None
    if prefix_end <= 0 or text[prefix_end - 1] != "}":
        return None
    repaired_text = text[: prefix_end - 1] + remainder
    try:
        repaired = json.loads(repaired_text)
    except json.JSONDecodeError:
        return None
    return repaired if isinstance(repaired, dict) else None


def _repair_unescaped_scene_string_quotes(payload: str) -> dict[str, Any] | None:
    """Escape only quotes that cannot terminate a JSON string.

    Some otherwise complete scene responses put dialogue quotes directly into
    ``prose``.  A quote can end a JSON string only before a structural
    delimiter.  Quotes followed by ordinary prose are therefore unambiguous
    string content and can be escaped without accepting malformed structure.
    """
    text = _structured_json_text(payload)
    start = text.find("{")
    end = text.rfind("}")
    if start < 0 or end <= start:
        return None
    candidate = text[start : end + 1]
    repaired_text = _escape_nonterminating_json_string_quotes(candidate)
    if repaired_text is None:
        return None
    try:
        repaired = json.loads(repaired_text)
    except json.JSONDecodeError:
        return None
    return repaired if isinstance(repaired, dict) else None


def _escape_nonterminating_json_string_quotes(value: str) -> str | None:
    repaired: list[str] = []
    in_string = False
    escaped = False
    changed = False
    for index, char in enumerate(value):
        if not in_string:
            if char == '"':
                in_string = True
            repaired.append(char)
            continue
        if escaped:
            repaired.append(char)
            escaped = False
            continue
        if char == "\\":
            repaired.append(char)
            escaped = True
            continue
        if char != '"':
            repaired.append(char)
            continue
        if _json_string_can_end_at(value, index):
            repaired.append(char)
            in_string = False
            continue
        repaired.append('\\"')
        changed = True
    return "".join(repaired) if changed and not in_string else None


def _json_string_can_end_at(value: str, quote_index: int) -> bool:
    cursor = quote_index + 1
    while cursor < len(value) and value[cursor].isspace():
        cursor += 1
    return cursor == len(value) or value[cursor] in ",}]:"


def _repair_trailing_extra_closing_braces(payload: str) -> dict[str, Any] | None:
    """Accept one complete scene object followed only by extra closing braces.

    Some provider responses emit a valid scene JSON object and then one or more
    stray `}` characters.  When the remainder is braces-only, the leading
    object is unambiguous and can be kept.
    """

    text = _structured_json_text(payload)
    try:
        value, end = json.JSONDecoder().raw_decode(text)
    except json.JSONDecodeError:
        return None
    if not isinstance(value, dict) or "prose" not in value:
        return None
    remainder = text[end:].strip()
    if not remainder or set(remainder) != {"}"}:
        return None
    return value


def _load_scene_response(payload: str) -> dict[str, Any]:
    try:
        value = _load_plan_json(payload)
    except json.JSONDecodeError as exc:
        value = (
            _repair_premature_scene_object_close(payload)
            or _repair_trailing_extra_closing_braces(payload)
            or _repair_unescaped_scene_string_quotes(payload)
        )
        if value is None:
            raise ValueError("Scene response was not valid structured JSON") from exc
    if not isinstance(value, dict):
        raise ValueError("Scene response must be a JSON object")
    prose = validate_text_output(value.get("prose"), CHAPTER_CONTRACT)
    raw_events = value.get("events")
    if not isinstance(raw_events, list):
        raise ValueError("Scene response events must be an array")
    if any(not isinstance(item, dict) for item in raw_events):
        raise ValueError("Scene response events must contain objects only")
    raw_deltas = value.get("deltas")
    if not isinstance(raw_deltas, dict):
        raise ValueError("Scene response deltas must be an object")
    delta_keys = (
        "characters",
        "relationships",
        "rosters",
        "locations",
        "inventory",
        "counters",
    )
    for key in delta_keys:
        items = raw_deltas.get(key)
        if not isinstance(items, list):
            raise ValueError(f"Scene response deltas.{key} must be an array")
        if any(not isinstance(item, dict) for item in items):
            raise ValueError(
                f"Scene response deltas.{key} must contain objects only"
            )
    return {
        "prose": prose,
        "events": [_normalize_scene_event(item) for item in raw_events],
        "deltas": {
            key: [dict(item) for item in raw_deltas[key]]
            for key in delta_keys
        },
        "continuity_note": str(value.get("continuity_note") or ""),
    }


def generate_scenes(
    input_pack: str,
    plan: dict[str, Any],
    *,
    dry_run: bool = False,
    language: str | None = None,
    chapter_blueprint: dict[str, Any] | None = None,
    recovered_scene_drafts: list[dict[str, Any]] | None = None,
    initial_scene_state: dict[str, Any] | None = None,
    authoritative_state_source: dict[str, Any] | None = None,
    generation_state_view_source: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    blueprint = blueprint_to_dict(chapter_blueprint)
    plan = _validate_plan(plan, blueprint_plan=blueprint is not None)
    recovered = _recovered_scene_prefix(recovered_scene_drafts, plan)
    scene_drafts: list[dict[str, Any]] = []
    scene_state = (
        normalize_scene_state(initial_scene_state)
        if initial_scene_state is not None
        else _initial_scene_state(input_pack)
    )
    prior_scene_summaries: list[dict[str, Any]] = []
    for scene in plan.get("scenes", []):
        required_beat_indexes = _scene_beat_indexes(scene)
        scene_required_beats = [
            beat
            for beat in (blueprint or {}).get("required_beats", [])
            if isinstance(beat, dict) and int(beat.get("index") or 0) in required_beat_indexes
        ]
        scene_index = int(scene["index"])
        state_before = normalize_scene_state(scene_state)
        previous_scene_tail = (
            str(scene_drafts[-1]["text"])[-600:]
            if scene_drafts
            else ""
        )
        if scene_index in recovered:
            scene_result = _recovered_scene_result(
                recovered[scene_index],
                scene=scene,
            )
        elif dry_run:
            scene_result = _dry_run_scene_result(
                plan,
                scene,
                chapter_blueprint=blueprint,
            )
        else:
            scene_result = _request_scene_candidate(
                input_pack=input_pack,
                plan=plan,
                scene=scene,
                scene_required_beats=scene_required_beats,
                blueprint=blueprint,
                previous_scene_tail=previous_scene_tail,
                prior_scene_summaries=prior_scene_summaries,
                state_before=state_before,
                language=language,
                authoritative_state_source=authoritative_state_source,
                generation_state_view_source=generation_state_view_source,
            )
        local_regeneration_attempts = 0
        rejected_boundaries: list[dict[str, Any]] = []
        while True:
            scene_text = validate_language_output(
                scene_result["prose"],
                CHAPTER_CONTRACT,
                language=language,
            )
            boundary, state_after = validate_scene_transition(
                scene_index=scene_index,
                state_before=state_before,
                events=scene_result["events"],
                deltas=scene_result["deltas"],
                prose=scene_text,
                required_event_ids=scene.get("required_event_ids") or [],
                forbidden_event_ids=scene.get("forbidden_event_ids") or [],
                planned_events=scene.get("planned_events") or [],
            )
            if boundary["accepted"]:
                break
            if _recovered_opening_has_stale_state(
                scene_index=scene_index,
                recovered_scene=scene_index in recovered,
                boundary=boundary,
            ):
                # A receipt-backed Scene can still have been generated against
                # an earlier committed chapter state.  Its evidence remains
                # useful for audit, but retry feedback would be misleading:
                # this is a fresh opening against a different story boundary,
                # not a repair of the current candidate.  Drop the recovered
                # sequence and restart the chapter from the current state.
                recovered = {}
                scene_result = _request_scene_candidate(
                    input_pack=input_pack,
                    plan=plan,
                    scene=scene,
                    scene_required_beats=scene_required_beats,
                    blueprint=blueprint,
                    previous_scene_tail=previous_scene_tail,
                    prior_scene_summaries=prior_scene_summaries,
                    state_before=state_before,
                    language=language,
                    authoritative_state_source=authoritative_state_source,
                    generation_state_view_source=generation_state_view_source,
                )
                continue
            feedback = _scene_boundary_retry_feedback(
                boundary,
                attempt=local_regeneration_attempts + 1,
                state_before=state_before,
                planned_events=scene.get("planned_events") or [],
            )
            rejected_boundaries.append(feedback)
            if (
                dry_run
                or local_regeneration_attempts >= _SCENE_BOUNDARY_REGENERATION_LIMIT
            ):
                boundary = {
                    **boundary,
                    "local_regeneration_attempts": local_regeneration_attempts,
                    "local_regeneration_rejections": rejected_boundaries,
                }
                require_scene_transition(boundary)
            local_regeneration_attempts += 1
            scene_result = _request_scene_candidate(
                input_pack=input_pack,
                plan=plan,
                scene=scene,
                scene_required_beats=scene_required_beats,
                blueprint=blueprint,
                previous_scene_tail=previous_scene_tail,
                prior_scene_summaries=prior_scene_summaries,
                state_before=state_before,
                language=language,
                boundary_retry=feedback,
                boundary_retry_attempt=local_regeneration_attempts,
                authoritative_state_source=authoritative_state_source,
                generation_state_view_source=generation_state_view_source,
            )
        if local_regeneration_attempts:
            boundary = {
                **boundary,
                "local_regeneration_attempts": local_regeneration_attempts,
                "local_regeneration_rejections": rejected_boundaries,
            }
        draft = {
            "index": scene_index,
            "goal": str(scene["goal"]),
            **({"covered_beat_indexes": required_beat_indexes} if required_beat_indexes else {}),
            **(
                {"ending_pressure_covered": True}
                if ending_requirement(blueprint) and int(scene["index"]) == _last_scene_index(plan)
                else {}
            ),
            "text": scene_text,
            "events": scene_result["events"],
            "deltas": scene_result["deltas"],
            "continuity_note": str(scene_result.get("continuity_note") or ""),
            **(
                {"source_call_id": str(scene_result["source_call_id"])}
                if scene_result.get("source_call_id")
                else {}
            ),
            **(
                {"source_attempt_id": str(scene_result["source_attempt_id"])}
                if scene_result.get("source_attempt_id")
                else {}
            ),
            **(
                {"source_provenance": dict(scene_result["source_provenance"])}
                if isinstance(scene_result.get("source_provenance"), dict)
                else {}
            ),
            "scene_state_before": scene_state_summary(state_before),
            "scene_state_after": scene_state_summary(state_after),
            "boundary_validation": boundary,
        }
        require_scene_transition(boundary)
        scene_drafts.append(draft)
        scene_state = state_after
        prior_scene_summaries.append(
            {
                "index": scene_index,
                "goal": str(scene["goal"]),
                "tail": scene_text[-280:],
                "event_ids": [str(event["event_id"]) for event in scene_result["events"]],
            }
        )
    return _validate_scene_drafts(scene_drafts)


def _recovered_opening_has_stale_state(
    *,
    scene_index: int,
    recovered_scene: bool,
    boundary: dict[str, Any],
) -> bool:
    """Return whether a recovered opening predates the current story state."""
    if not recovered_scene or scene_index != 1:
        return False
    findings = boundary.get("findings")
    if not isinstance(findings, list):
        return False
    return any(
        isinstance(finding, dict)
        and str(finding.get("code") or "").endswith("_state_rollback")
        for finding in findings
    )


def _request_scene_candidate(
    *,
    input_pack: str,
    plan: dict[str, Any],
    scene: dict[str, Any],
    scene_required_beats: list[dict[str, Any]],
    blueprint: dict[str, Any] | None,
    previous_scene_tail: str,
    prior_scene_summaries: list[dict[str, Any]],
    state_before: dict[str, Any],
    language: str | None,
    boundary_retry: dict[str, Any] | None = None,
    boundary_retry_attempt: int = 0,
    authoritative_state_source: dict[str, Any] | None = None,
    generation_state_view_source: dict[str, Any] | None = None,
) -> dict[str, Any]:
    scene_index = int(scene["index"])
    call_kwargs: dict[str, Any] = {
        "stage": "chapter_generation",
        "call_id": build_scene_generation_call_id(
            scene_index,
            boundary_retry=boundary_retry_attempt,
        ),
        # Scene metadata drives deterministic safety gates. Favor repeatable
        # adherence to the structured contract over stylistic variance.
        "temperature": 0.2,
    }
    if boundary_retry is not None:
        call_kwargs["temperature"] = 0.0
    payload = chat_completion(
        [
            {"role": "system", "content": _load_scene_prompt()},
            {
                "role": "user",
                "content": _scene_request_payload(
                    input_pack=input_pack,
                    plan=plan,
                    scene=scene,
                    scene_required_beats=scene_required_beats,
                    blueprint=blueprint,
                    previous_scene_tail=previous_scene_tail,
                    prior_scene_summaries=prior_scene_summaries,
                    scene_state=state_before,
                    boundary_retry=boundary_retry,
                    authoritative_state_source=authoritative_state_source,
                    generation_state_view_source=(
                        generation_state_view_source
                    ),
                ),
            },
        ],
        **call_kwargs,
    )
    result = _load_scene_response(payload)
    result["source_call_id"] = str(call_kwargs["call_id"])
    return result


def _scene_boundary_retry_feedback(
    report: dict[str, Any],
    *,
    attempt: int,
    state_before: dict[str, Any] | None = None,
    planned_events: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    raw_findings = [
        item
        for item in report.get("findings") or []
        if isinstance(item, dict)
    ]
    findings: list[dict[str, Any]] = []
    for item in raw_findings[:_SCENE_BOUNDARY_FEEDBACK_FINDING_LIMIT]:
        findings.append(
            {
                "code": str(item.get("code") or "unknown"),
                "message": str(item.get("message") or "")[:320],
                "evidence": _bounded_boundary_evidence(item.get("evidence")),
            }
        )
    canonical_locations = {
        str(entity_id): str(location_id)
        for entity_id, location_id in sorted(
            ((state_before or {}).get("locations") or {}).items(),
            key=lambda item: str(item[0]),
        )
        if str(entity_id).strip() and str(location_id).strip()
    }
    canonical_events = [
        {
            key: item.get(key)
            for key in ("event_id", "type", "subjects", "objects", "location", "status")
        }
        for item in (planned_events or [])
        if isinstance(item, dict) and str(item.get("event_id") or "").strip()
    ]
    return {
        "attempt": int(attempt),
        "scene_index": int(report.get("scene_index") or 0),
        "state_before_sha256": str(report.get("state_before_sha256") or ""),
        "finding_count": len(raw_findings),
        "omitted_finding_count": max(0, len(raw_findings) - len(findings)),
        "findings": findings,
        **(
            {"canonical_location_state": canonical_locations}
            if canonical_locations
            else {}
        ),
        **({"canonical_planned_events": canonical_events} if canonical_events else {}),
        "instruction": (
            "Regenerate this same scene only. Treat current_scene_state and "
            "canonical_location_state as the exclusive authoritative state. "
            "Shared context describes earlier chapter context and must never override them. "
            "Copy every canonical_planned_events descriptor exactly; do not rewrite its type, "
            "subjects, objects, location, or status. "
            "Correct or remove every rejected delta; each before value must exactly equal "
            "the current value. Do not repeat any earlier scene or event. "
            + _EVENT_LOCATION_CONTRACT
        ),
    }


def _bounded_boundary_evidence(value: Any) -> Any:
    if value is None:
        return {}
    try:
        serialized = json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
    except (TypeError, ValueError):
        serialized = str(value)
    if len(serialized) <= _SCENE_BOUNDARY_FEEDBACK_EVIDENCE_MAX_CHARS:
        try:
            return json.loads(serialized)
        except json.JSONDecodeError:
            return serialized
    return {
        "truncated_json": (
            serialized[: _SCENE_BOUNDARY_FEEDBACK_EVIDENCE_MAX_CHARS - 3]
            + "..."
        )
    }


def _recovered_scene_prefix(
    scene_drafts: list[dict[str, Any]] | None,
    plan: dict[str, Any],
) -> dict[int, dict[str, Any]]:
    if not scene_drafts:
        return {}
    plan_indexes = [
        int(scene["index"])
        for scene in plan.get("scenes", [])
        if isinstance(scene, dict) and isinstance(scene.get("index"), int)
    ]
    recovered: dict[int, dict[str, Any]] = {}
    plan_by_index = {
        int(scene.get("index") or 0): scene
        for scene in plan.get("scenes", [])
        if isinstance(scene, dict) and int(scene.get("index") or 0) > 0
    }
    for position, draft in enumerate(scene_drafts, start=1):
        if not isinstance(draft, dict) or int(draft.get("index") or 0) != position:
            raise ValueError("recovered scenes must form a contiguous prefix starting at scene 1")
        if position not in plan_indexes:
            # A newer plan may contain fewer Scenes than the persisted run.
            # Recovery is only a reusable prefix of the current plan; old
            # suffix Scenes are evidence, not a reason to fail generation.
            break
        if not _has_complete_structured_scene_payload(draft):
            # Legacy prose remains immutable evidence, but it cannot be reused
            # as an accepted Scene because it has no model-declared boundary
            # facts. Regenerate this scene and the remaining suffix instead of
            # synthesizing completed events from the plan.
            break
        planned_scene = plan_by_index.get(position) or {}
        required_event_ids = [
            str(event_id)
            for event_id in planned_scene.get("required_event_ids") or []
        ]
        recovered_event_ids = [
            str(event.get("event_id") or "")
            for event in draft.get("events") or []
            if isinstance(event, dict)
        ]
        if recovered_event_ids != required_event_ids:
            # Scene indexes alone are not a stable identity when StoryProject
            # beats are regrouped. Drop this Scene and the remaining prefix so
            # generation restarts at the first changed event scope.
            break
        recovered[position] = {
            **dict(draft),
            "text": validate_text_output(draft.get("text"), CHAPTER_CONTRACT),
        }
    return recovered


def _scene_request_payload(
    *,
    input_pack: str,
    plan: dict[str, Any],
    scene: dict[str, Any],
    scene_required_beats: list[dict[str, Any]],
    blueprint: dict[str, Any] | None,
    previous_scene_tail: str = "",
    prior_scene_summaries: list[dict[str, Any]] | None = None,
    scene_state: dict[str, Any] | None = None,
    boundary_retry: dict[str, Any] | None = None,
    authoritative_state_source: dict[str, Any] | None = None,
    generation_state_view_source: dict[str, Any] | None = None,
) -> str:
    target_min_chars, target_max_chars = _scene_target_char_range(plan)
    chapter_plan_context = _compact_chapter_plan_context(plan)
    generation_state_view = (
        generation_state_view_source
        if generation_state_view_source is not None
        else generation_state_view_from_markdown(input_pack)
    )
    prompt_scene_state = scene_state or empty_scene_state()
    if generation_state_view is not None:
        prompt_scene_state = filter_scene_state_for_generation(
            prompt_scene_state,
            generation_state_view,
            active_event_ids=_active_plan_event_ids(plan),
        )
    context_query = json.dumps(
        {
            "chapter_plan": chapter_plan_context,
            "scene": scene,
            "required_beats": scene_required_beats,
            "ending_pressure": ending_requirement(blueprint) or None,
        },
        ensure_ascii=False,
        sort_keys=True,
    )
    scene_state_projections = _scene_state_projection_candidates(
        prompt_scene_state,
        has_generation_state_view=generation_state_view is not None,
    )
    payload_body = {
        "chapter_plan": chapter_plan_context,
        "scene": scene,
        "story_project_required_beats": scene_required_beats,
        "story_project_ending_pressure": ending_requirement(blueprint) or None,
        "story_project_chapter_contract": _scene_blueprint_contract(
            blueprint
        ),
        "current_scene_state": scene_state_projections[0],
        **(
            {
                "expected_new_entities": list(
                    generation_state_view["expected_new_entities"]
                ),
                "generation_state_projection_sha256": generation_state_view[
                    "projection_sha256"
                ],
                "generation_state_read_set_digest": generation_state_view[
                    "read_set_digest"
                ],
            }
            if generation_state_view is not None
            else {}
        ),
        "required_event_ids": list(scene.get("required_event_ids") or []),
        "forbidden_event_ids": list(scene.get("forbidden_event_ids") or []),
        "response_schema": {
            "prose": "string",
            "events": [
                {
                    "event_id": "one required_event_id",
                    "type": "string",
                    "subjects": ["stable character ids"],
                    "objects": ["stable entity ids"],
                    "location": "stable location id",
                    "status": "completed|started|ongoing",
                }
            ],
            "deltas": scene_delta_response_schema(),
            "continuity_note": "string",
        },
        "delta_rules": [
            "Use an empty list for every state kind that does not actually change in this scene.",
            "Do not encode confirmations, observations, scene presence, role descriptions, rules, thresholds, "
            "or prose facts as deltas.",
            "Use exactly the type-specific id fields shown in response_schema.deltas; never use "
            "stable_entity_id as a generic substitute.",
            "A genuinely new character uses separate character deltas for canonical_name and aliases. Never "
            "put a nested character record in one after value or re-introduce a character already present in "
            "the project context.",
            "Every before value must exactly match current_scene_state. Inventory and counter before, delta, "
            "and after values must be numbers with after equal to before plus delta.",
            "The numeric values shown in response_schema are type examples, not values to copy.",
            "Roster count equals stable members plus unresolved_count; never invent member_ids. Join uses "
            "non-negative unresolved_delta; leave, dead, or missing use non-positive values. Resolve identifies "
            "new stable members already included in unresolved_count: unresolved_delta must equal minus the "
            "number of new members, total delta must be 0, and declared_count must stay unchanged. Replace uses "
            "unresolved_count; aggregate changes require exact unresolved_before. Every roster mutation needs "
            "this Scene's reason_event_id. Existing-roster identity and audit metadata may only be omitted or "
            "echoed exactly. Existing-roster replace must be an exact echo; use another operation for changes. "
            "Never emit migration audit metadata.",
            "Every relationship delta must include source_event_id and it must reference an event declared "
            "by this Scene; never reuse an earlier Scene event to justify a new relationship state.",
            "Use deltas.locations exclusively for physical location changes. Never emit a deltas.characters "
            "delta whose field is location or current_location.",
        ],
        **({"boundary_retry": boundary_retry} if boundary_retry is not None else {}),
        "instruction": (
            "Return JSON only and exactly one object matching response_schema. "
            "prose must draft only this scene as continuous prose with no heading. "
            "If story_project_required_beats are provided, cover each listed beat in the prose and preserve "
            "its essential factual phrases closely enough for deterministic coverage checks. "
            f"Target {target_min_chars}-{target_max_chars} Chinese characters for this scene when the project "
            "language is zh-CN, so the merged chapter remains 3000-4500 Chinese characters; treat the upper "
            "bound as a hard limit and stop the scene before exceeding it. "
            "Every required_event_id must appear exactly once in events. Do not restart, duplicate, or retell "
            "a completed event; never use a forbidden_event_id or roll state back. "
            "For every event in scene.planned_events, copy event_id, type, subjects, objects, location, and "
            "status exactly; these are an immutable bookkeeping contract, not prose to rewrite. "
            f"{_EVENT_LOCATION_CONTRACT} "
            "Deltas must follow the exact type-specific fields and delta_rules in this request. Do not emit a "
            "delta merely to restate an unchanged fact. Continue directly from previous_scene_tail and "
            "current_scene_state."
        ),
    }
    budget = default_context_budget()
    safe_input_limit = _scene_safe_input_limit(budget)
    protocol_texts = (_load_scene_prompt(),)
    compact_scene_contexts: dict[int, str] = {}
    payload = ""
    for scene_state_projection in scene_state_projections:
        candidate_payload_body = dict(payload_body)
        candidate_payload_body["current_scene_state"] = scene_state_projection
        for policy in _SCENE_CONTEXT_PAYLOAD_POLICIES:
            context_section_chars = int(policy["context_section_chars"])
            compact_scene_context = compact_scene_contexts.get(context_section_chars)
            if compact_scene_context is None:
                try:
                    compact_scene_context = _compact_scene_context(
                        input_pack,
                        max_section_chars=context_section_chars,
                        query=context_query,
                        authoritative_state_source=authoritative_state_source,
                        generation_state_view_source=generation_state_view,
                        exclude_authoritative_state=boundary_retry is not None,
                    )
                except StructuredContextError as exc:
                    if context_section_chars >= 1_500 or exc.code not in {
                        "required_json_item_exceeds_budget",
                        "required_markdown_context_exceeds_budget",
                    }:
                        raise
                    continue
                compact_scene_contexts[context_section_chars] = compact_scene_context
            compact_summaries = _compact_prior_scene_summaries(
                prior_scene_summaries,
                limit=int(policy["summary_limit"]),
                tail_chars=int(policy["summary_tail_chars"]),
                include_goal=bool(policy["include_summary_goal"]),
            )
            # This payload is machine-readable transport JSON. Compact only
            # its formatting so admission headroom is not consumed by
            # indentation. Legacy completed-event details are reduced only
            # after the otherwise-compatible payload candidates do not fit;
            # the full state remains local for deterministic validation.
            payload = json.dumps(
                {
                    "shared_context": compact_scene_context,
                    **candidate_payload_body,
                    "previous_scene_tail": str(previous_scene_tail)[
                        -int(policy["previous_tail_chars"]) :
                    ],
                    "prior_scene_summaries": compact_summaries,
                },
                ensure_ascii=False,
                separators=(",", ":"),
            )
            report = budget.measure(
                payload,
                stage="scene",
                protocol_texts=protocol_texts,
            )
            if report["within_budget"] and _scene_report_within_safe_limit(
                report,
                safe_input_limit=safe_input_limit,
            ):
                return payload
    report = budget.require_input(payload, stage="scene", protocol_texts=protocol_texts)
    if not _scene_report_within_safe_limit(
        report,
        safe_input_limit=safe_input_limit,
    ):
        raise ContextBudgetError(
            "story_project_context_headroom_exceeded",
            "scene input requires "
            f"{report['budgeted_input_tokens']} tokens; safe target is "
            f"{safe_input_limit}; hard limit is {report['hard_input_limit']}",
        )
    return payload


def _compact_chapter_plan_context(plan: dict[str, Any]) -> dict[str, Any]:
    """Keep the chapter arc while avoiding per-scene duplication of full beat records."""

    scenes: list[dict[str, Any]] = []
    for raw in plan.get("scenes") or []:
        if not isinstance(raw, dict):
            continue
        scene = {
            key: raw.get(key)
            for key in ("index", "type", "goal")
            if raw.get(key) is not None
        }
        for key in ("required_beat_indexes", "required_event_ids"):
            values = raw.get(key)
            if isinstance(values, list):
                scene[key] = list(values)
        scenes.append(scene)
    return {
        "goal": str(plan.get("goal") or ""),
        "scenes": scenes,
    }


def _scene_state_projection_candidates(
    scene_state: dict[str, Any],
    *,
    has_generation_state_view: bool,
) -> list[dict[str, Any]]:
    """Build prompt-only state candidates without weakening local validation."""

    limits = (
        (0,)
        if has_generation_state_view
        else _LEGACY_SCENE_COMPLETED_EVENT_RECORD_LIMITS
    )
    candidates: list[dict[str, Any]] = []
    previous_completed_events: list[dict[str, Any]] | None = None
    for limit in limits:
        projection = scene_state_generation_projection(
            scene_state,
            include_completed_event_records=(limit != 0),
            completed_event_record_limit=limit,
        )
        completed_events = projection["completed_events"]
        if (
            previous_completed_events is not None
            and completed_events == previous_completed_events
        ):
            continue
        candidates.append(projection)
        previous_completed_events = completed_events
    # Keep a final, prompt-only admission candidate for legacy packs that do
    # not yet carry a Generation State View.  The complete normalized state is
    # still used for transition validation; this only removes provenance and
    # historical audit fields the model must not treat as current story facts.
    for projection in tuple(candidates):
        admission_projection = _scene_state_admission_projection(projection)
        if admission_projection != projection:
            candidates.append(admission_projection)
    return candidates


def _scene_state_admission_projection(
    projection: dict[str, Any],
) -> dict[str, Any]:
    """Reduce legacy prompt state only after normal scene candidates fail.

    Character and relationship records carry local provenance for receipts and
    deterministic validation.  They are not dynamic story facts and can
    consume enough Chinese-token budget to prevent a safe retry.  Preserve all
    remaining current-state fields plus hashes/counts that bind this prompt to
    the complete local history.
    """

    compact = dict(projection)
    for collection_name in ("characters", "relationships"):
        records = projection.get(collection_name)
        if not isinstance(records, dict):
            continue
        compact[collection_name] = {
            str(record_id): {
                str(key): value
                for key, value in record.items()
                if str(key) not in _SCENE_PROMPT_AUDIT_RECORD_FIELDS
            }
            if isinstance(record, dict)
            else record
            for record_id, record in records.items()
        }
    completed_event_ids = list(projection.get("completed_event_ids") or [])
    compact["completed_event_ids"] = completed_event_ids[
        -_SCENE_ADMISSION_COMPLETED_EVENT_ID_LIMIT:
    ]
    compact["completed_event_ids_truncated"] = (
        bool(projection.get("completed_event_ids_truncated"))
        or len(completed_event_ids) > _SCENE_ADMISSION_COMPLETED_EVENT_ID_LIMIT
    )
    context_projection = projection.get("context_projection")
    if isinstance(context_projection, dict):
        compact["context_projection"] = {
            **context_projection,
            "admission_projection_policy": "scene_prompt_audit_compaction_v1",
            "admission_completed_event_id_limit": (
                _SCENE_ADMISSION_COMPLETED_EVENT_ID_LIMIT
            ),
        }
    return compact


def _scene_blueprint_contract(
    blueprint: dict[str, Any] | None,
) -> dict[str, Any]:
    """Project non-duplicated narrative fields for a single Scene request."""

    if not isinstance(blueprint, dict):
        return {}
    duplicated_or_local_only = {
        "chapter_context_read_set",
        "ending_pressure",
        "missing_fields",
        "outline_path",
        "required_beats",
        "source_path",
    }
    return {
        str(key): value
        for key, value in sorted(blueprint.items())
        if str(key) not in duplicated_or_local_only
    }


def _active_plan_event_ids(plan: dict[str, Any]) -> list[str]:
    event_ids: list[str] = []
    seen: set[str] = set()
    for scene in plan.get("scenes") or []:
        if not isinstance(scene, dict):
            continue
        candidates = [
            *list(scene.get("required_event_ids") or []),
            *[
                event.get("event_id")
                for event in scene.get("planned_events") or []
                if isinstance(event, dict)
            ],
        ]
        for raw_event_id in candidates:
            event_id = str(raw_event_id or "").strip()
            if event_id and event_id not in seen:
                seen.add(event_id)
                event_ids.append(event_id)
    return event_ids


def _scene_safe_input_limit(budget: Any) -> int | None:
    hard_limit = getattr(budget, "hard_input_limit", None)
    if isinstance(hard_limit, bool) or not isinstance(hard_limit, int) or hard_limit < 1:
        return None
    headroom = min(
        _SCENE_INPUT_HEADROOM_TOKENS,
        max(256, hard_limit // 16),
    )
    return max(1, hard_limit - headroom)


def _scene_report_within_safe_limit(
    report: dict[str, Any],
    *,
    safe_input_limit: int | None,
) -> bool:
    if safe_input_limit is None:
        return True
    tokens = report.get("budgeted_input_tokens")
    if isinstance(tokens, bool) or not isinstance(tokens, int):
        return True
    return tokens <= safe_input_limit


def _compact_prior_scene_summaries(
    summaries: list[dict[str, Any]] | None,
    *,
    limit: int,
    tail_chars: int,
    include_goal: bool,
) -> list[dict[str, Any]]:
    """Bound accumulated scene evidence without discarding completed event ids."""

    bounded_limit = max(0, limit)
    if bounded_limit == 0:
        return []
    compacted: list[dict[str, Any]] = []
    for raw in list(summaries or [])[-bounded_limit:]:
        if not isinstance(raw, dict):
            continue
        raw_tail = str(raw.get("tail") or "")
        item = {
            "index": int(raw.get("index") or 0),
            "tail": raw_tail[-tail_chars:] if tail_chars > 0 else "",
            "event_ids": [str(value) for value in raw.get("event_ids") or [] if str(value)],
        }
        if include_goal:
            item["goal"] = str(raw.get("goal") or "")
        compacted.append(item)
    return compacted


def _scene_target_char_range(plan: dict[str, Any]) -> tuple[int, int]:
    scene_count = max(
        1,
        len([item for item in plan.get("scenes", []) if isinstance(item, dict)]),
    )
    target_min_chars = max(600, 3_000 // scene_count)
    return target_min_chars, max(target_min_chars, 4_500 // scene_count)


def _compact_scene_context(
    text: str,
    *,
    max_section_chars: int = 1_500,
    query: str = "",
    authoritative_state_source: dict[str, Any] | None = None,
    generation_state_view_source: dict[str, Any] | None = None,
    exclude_authoritative_state: bool = False,
) -> str:
    """Retrieve complete sections/JSON items relevant to the current scene."""
    generation_state_view = (
        generation_state_view_source
        if generation_state_view_source is not None
        else generation_state_view_from_markdown(text)
    )
    if generation_state_view is not None:
        scene_state_reference = build_scene_generation_state_reference(
            generation_state_view
        )
        text = _project_scene_bookkeeping_sections(text, generation_state_view)
        selection = compact_markdown_context(
            text,
            max_chars=max_section_chars * 8,
            per_section_max_chars=max_section_chars,
            query=query,
            required_sections={
                "Project Profile",
                "Spatial State",
                "小说生成规则契约",
            },
            excluded_sections={
                "Authoritative State",
                "Characters",
                "Constraints",
                "Context Digest",
                "Director Decision",
                "Generation State View",
                "Generation State View Reference",
                "Generation State View Projection",
                "StoryProject Chapter Blueprint",
                "Timeline",
                "World State",
                "Memory Index",
                "Prompt Context Selection",
                "Recovery Context",
                "Requirements",
                "Runtime Memory Metadata",
                "Story State",
                "Structured Context Manifest",
            },
            prefer_recent=True,
            policy="scene_generation_state_reference_retrieval_v1",
        )
        reference_text = (
            f"# {SCENE_GENERATION_STATE_REFERENCE_HEADING}\n"
            + json.dumps(
                scene_state_reference,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            )
        )
        compact_context = f"{reference_text}\n\n{selection.text}"
        parsed_reference = scene_generation_state_reference_from_markdown(
            compact_context
        )
        if parsed_reference != scene_state_reference:
            raise ContextBudgetError(
                "story_project_context_reference_mismatch",
                "Scene generation state reference changed during compaction",
            )
        return compact_context

    authority_section_limit = min(
        AUTHORITATIVE_SCENE_SECTION_MAX_CHARS,
        max(1, max_section_chars * 7),
    )
    projected_text = (
        text
        if exclude_authoritative_state
        else compact_authoritative_state_in_markdown(
            text,
            max_section_chars=authority_section_limit,
            query=query,
            require_query_references=False,
            require_open_events=False,
            authoritative_state_source=authoritative_state_source,
            externalized_collections={"roster": "current_scene_state.rosters"},
        )
    )
    required_sections = {
        "Context Digest",
        "Prompt Context Selection",
        "Project Profile",
        "Director Decision",
        "Story State",
        "Spatial State",
        "Authoritative State",
        "StoryProject Chapter Blueprint",
        "Requirements",
        "灏忚鐢熸垚瑙勫垯濂戠害",
    }
    if exclude_authoritative_state:
        required_sections.discard("Authoritative State")
    selection = compact_markdown_context(
        projected_text,
        max_chars=max_section_chars * 7,
        per_section_max_chars=max_section_chars,
        query=query,
        required_sections=required_sections,
        excluded_sections=(
            {"Memory Index", "Structured Context Manifest", "Authoritative State"}
            if exclude_authoritative_state
            else {"Memory Index", "Structured Context Manifest"}
        ),
        required_json_keys={
            "Prompt Context Selection": PROMPT_CONTEXT_SELECTION_KEYS,
            "Story State": STORY_STATE_CONTEXT_KEYS,
            "StoryProject Chapter Blueprint": {"chapter_blueprint", "read_set_context_digest"},
        },
        allowed_json_keys={
            "Prompt Context Selection": PROMPT_CONTEXT_SELECTION_KEYS,
            "Story State": STORY_STATE_CONTEXT_KEYS,
        },
        section_max_chars={
            "Story State": STORY_STATE_SECTION_MAX_CHARS,
            "Authoritative State": authority_section_limit,
            "StoryProject Chapter Blueprint": _STORY_PROJECT_BLUEPRINT_SECTION_MAX_CHARS,
        },
        prefer_recent=True,
        policy=(
            "scene_boundary_retry_retrieval_v1"
            if exclude_authoritative_state
            else "scene_markdown_json_retrieval_v1"
        ),
    )
    return selection.text


def _initial_scene_state(input_pack: str) -> dict[str, Any]:
    state = empty_scene_state()
    authority = authoritative_state_from_markdown(input_pack)
    generation_state_view = generation_state_view_from_markdown(input_pack)
    if isinstance(authority, dict):
        for character_id, record in (authority.get("characters") or {}).items():
            if isinstance(record, dict):
                state["characters"][str(character_id)] = dict(record)
        for relationship_id, record in (authority.get("relationships") or {}).items():
            if isinstance(record, dict):
                source_id = str(record.get("source_character_id") or "")
                target_id = str(record.get("target_character_id") or "")
                key = f"{source_id}->{target_id}" if source_id and target_id else str(relationship_id)
                state["relationships"][key] = dict(record)
        for roster_id, record in (authority.get("roster") or {}).items():
            if isinstance(record, dict):
                state["rosters"][str(roster_id)] = dict(record)
        for counter_id, record in (authority.get("numeric_counters") or {}).items():
            if isinstance(record, dict) and isinstance(record.get("current_value"), (int, float)):
                state["counters"][str(counter_id)] = record["current_value"]
        for inventory_id, record in (authority.get("inventory") or {}).items():
            if isinstance(record, dict) and isinstance(record.get("quantity"), (int, float)):
                state["inventories"][str(inventory_id)] = record["quantity"]
        for entity_id, record in (authority.get("locations") or {}).items():
            if isinstance(record, dict) and record.get("location_id") not in (None, ""):
                state["locations"][str(entity_id)] = record["location_id"]
        for event_id, record in (authority.get("events") or {}).items():
            if not isinstance(record, dict):
                continue
            normalized = str(event_id).strip()
            if not authoritative_event_is_open(record):
                if normalized and normalized not in state["completed_event_ids"]:
                    state["completed_event_ids"].append(normalized)
                state["completed_events"].append(dict(record))
            else:
                state["open_actions"].append(dict(record))
        state["open_action"] = (
            str(state["open_actions"][0].get("event_id") or "")
            if state["open_actions"]
            else ""
        )
    if generation_state_view is not None:
        known_event_ids = {
            str(item.get("event_id") or "").strip()
            for item in [
                *state["completed_events"],
                *state["open_actions"],
            ]
            if isinstance(item, dict)
        }
        known_event_ids.update(
            str(item).strip()
            for item in state["completed_event_ids"]
            if str(item).strip()
        )
        for event_id in generation_state_view["selected_event_item_ids"]:
            _collection, _separator, normalized = str(event_id).partition("/")
            event = generation_state_view["required_events"].get(normalized)
            if (
                not normalized
                or normalized in known_event_ids
                or not isinstance(event, dict)
            ):
                continue
            event_record = dict(event)
            event_record.setdefault("event_id", normalized)
            if authoritative_event_is_open(event):
                state["open_actions"].append(event_record)
            else:
                state["completed_event_ids"].append(normalized)
                state["completed_events"].append(event_record)
            known_event_ids.add(normalized)
        state["open_action"] = (
            str(state["open_actions"][0].get("event_id") or "")
            if state["open_actions"]
            else ""
        )
    story_state = _input_pack_json_section(input_pack, "Story State") or {}
    _apply_scene_bridge(
        state,
        authority=authority if isinstance(authority, dict) else {},
        story_state=story_state,
    )
    for event_id in story_state.get("completed_event_ids") or []:
        normalized = str(event_id).strip()
        if normalized and normalized not in state["completed_event_ids"]:
            state["completed_event_ids"].append(normalized)
    return state



def _project_scene_bookkeeping_sections(
    text: str, generation_state_view: dict[str, Any]
) -> str:
    """Replace growing ledgers with working-set projections before compaction."""

    project_profile = _input_pack_json_section(text, "Project Profile")
    spatial_state = _input_pack_json_section(text, "Spatial State")
    if project_profile is None and spatial_state is None:
        return text
    projected = project_bookkeeping_for_generation(
        generation_state_view,
        project_profile=project_profile,
        spatial_state=spatial_state,
    )
    updated = text
    if project_profile is not None:
        updated = _replace_markdown_json_section(
            updated, "Project Profile", projected["project_profile"]
        )
    if spatial_state is not None:
        updated = _replace_markdown_json_section(
            updated, "Spatial State", projected["spatial_state"]
        )
    return updated


def _replace_markdown_json_section(
    text: str, section: str, payload: dict[str, Any]
) -> str:
    rendered = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )
    pattern = rf"(?ms)^# {re.escape(section)}[ \t]*\r?\n(.*?)(?=^# |\Z)"
    replaced, count = re.subn(
        pattern,
        f"# {section}\n{rendered}\n\n",
        str(text or ""),
        count=1,
    )
    if count != 1:
        raise ContextBudgetError(
            "story_project_context_reference_mismatch",
            f"{section} could not be replaced with a working-set projection",
        )
    return replaced


def _input_pack_json_section(input_pack: str, section: str) -> dict[str, Any] | None:
    match = re.search(
        rf"(?ms)^# {re.escape(section)}[ \t]*\r?\n(.*?)(?=^# |\Z)",
        str(input_pack or ""),
    )
    if not match:
        return None
    body = match.group(1).strip()
    start = body.find("{")
    end = body.rfind("}")
    if start < 0 or end <= start:
        return None
    try:
        value = json.loads(body[start : end + 1])
    except json.JSONDecodeError:
        return None
    return value if isinstance(value, dict) else None


def _apply_scene_bridge(
    state: dict[str, Any],
    *,
    authority: dict[str, Any],
    story_state: dict[str, Any],
) -> None:
    """Apply Story State only where the authoritative ledger has no answer."""

    story_location = str(
        story_state.get("last_scene_location") or ""
    ).strip()
    raw_story_characters = story_state.get("last_scene_characters")
    story_characters = (
        [
            normalized
            for character in raw_story_characters
            if (normalized := str(character).strip())
        ]
        if isinstance(raw_story_characters, list)
        else []
    )
    aliases = _authoritative_character_aliases(authority)
    resolved_story_characters = [
        aliases.get(character_id, character_id)
        for character_id in story_characters
    ]
    known_characters = _authoritative_character_ids(authority)
    locations = {
        str(entity_id): str(location_id).strip()
        for entity_id, location_id in (state.get("locations") or {}).items()
        if str(entity_id).strip() and str(location_id).strip()
    }
    authoritative_location = _authoritative_bridge_location(
        authority,
        locations=locations,
        known_characters=known_characters,
        story_location=story_location,
        story_characters=resolved_story_characters,
    )
    if authoritative_location:
        state["current_location"] = authoritative_location
        present = {
            character_id
            for character_id in known_characters
            if locations.get(character_id) == authoritative_location
        }
        if story_location == authoritative_location:
            present.update(
                character_id
                for character_id in resolved_story_characters
                if not locations.get(character_id)
                or locations.get(character_id) == authoritative_location
            )
        state["characters_present"] = sorted(present)
        return
    if not story_location:
        return
    state["current_location"] = story_location
    state["characters_present"] = story_characters
    for character_id in story_characters:
        state["locations"].setdefault(character_id, story_location)


def _authoritative_bridge_location(
    authority: dict[str, Any],
    *,
    locations: dict[str, str],
    known_characters: set[str],
    story_location: str,
    story_characters: list[str],
) -> str:
    if story_characters:
        story_authority_locations = {
            locations[character_id]
            for character_id in story_characters
            if locations.get(character_id)
        }
        if story_location in story_authority_locations:
            return story_location
        if len(story_authority_locations) == 1:
            return next(iter(story_authority_locations))
        protagonist_locations = _protagonist_locations(
            authority,
            locations=locations,
            allowed_characters=set(story_characters),
        )
        return (
            next(iter(protagonist_locations))
            if len(protagonist_locations) == 1
            else ""
        )
    protagonist_locations = _protagonist_locations(
        authority,
        locations=locations,
        allowed_characters=known_characters,
    )
    if len(protagonist_locations) == 1:
        return next(iter(protagonist_locations))
    known_locations = {
        locations[character_id]
        for character_id in known_characters
        if locations.get(character_id)
    }
    return next(iter(known_locations)) if len(known_locations) == 1 else ""


def _protagonist_locations(
    authority: dict[str, Any],
    *,
    locations: dict[str, str],
    allowed_characters: set[str],
) -> set[str]:
    result: set[str] = set()
    for record_id, record in (authority.get("characters") or {}).items():
        if not isinstance(record, dict):
            continue
        character_id = str(record.get("character_id") or record_id).strip()
        if character_id not in allowed_characters:
            continue
        role_values = {
            str(record.get(field) or "").strip().lower()
            for field in ("role", "identity")
        }
        if not any(
            value == "protagonist"
            or value == "lead"
            or "主角" in value
            for value in role_values
        ):
            continue
        location = locations.get(character_id)
        if location:
            result.add(location)
    return result


def _authoritative_character_aliases(
    authority: dict[str, Any],
) -> dict[str, str]:
    result: dict[str, str] = {}
    for record_id, record in (authority.get("characters") or {}).items():
        if not isinstance(record, dict):
            continue
        stable_id = str(record.get("character_id") or record_id).strip()
        if not stable_id:
            continue
        references = [
            record_id,
            record.get("character_id"),
            record.get("canonical_name"),
            *(record.get("aliases") or []),
        ]
        for reference in references:
            normalized = str(reference or "").strip()
            if normalized:
                result.setdefault(normalized, stable_id)
    return result


def _authoritative_character_ids(authority: dict[str, Any]) -> set[str]:
    result: set[str] = set()
    for record_id, record in (authority.get("characters") or {}).items():
        normalized_id = str(record_id).strip()
        if normalized_id:
            result.add(normalized_id)
        if isinstance(record, dict):
            character_id = str(record.get("character_id") or "").strip()
            if character_id:
                result.add(character_id)
    for record in (authority.get("relationships") or {}).values():
        if not isinstance(record, dict):
            continue
        for field in (
            "source_character_id",
            "target_character_id",
            "source_id",
            "target_id",
        ):
            character_id = str(record.get(field) or "").strip()
            if character_id:
                result.add(character_id)
    for record in (authority.get("roster") or {}).values():
        if not isinstance(record, dict):
            continue
        for character_id in record.get("character_ids") or []:
            normalized = str(character_id).strip()
            if normalized:
                result.add(normalized)
        for member in record.get("members") or []:
            if isinstance(member, str):
                normalized = member.strip()
            elif isinstance(member, dict):
                normalized = str(
                    member.get("character_id")
                    or member.get("member_id")
                    or ""
                ).strip()
            else:
                normalized = ""
            if normalized:
                result.add(normalized)
    return result


def _recovered_scene_result(
    recovered: dict[str, Any],
    *,
    scene: dict[str, Any],
) -> dict[str, Any]:
    if not _has_complete_structured_scene_payload(recovered):
        raise ValueError("recovered scene lacks a complete structured boundary")
    raw_events = recovered.get("events")
    assert isinstance(raw_events, list)
    events = [
        _normalize_scene_event(item)
        for item in raw_events
    ]
    raw_deltas = recovered.get("deltas")
    assert isinstance(raw_deltas, dict)
    return {
        "prose": validate_text_output(recovered.get("text"), CHAPTER_CONTRACT),
        "events": events,
        "deltas": {
            key: [
                dict(item)
                for item in raw_deltas[key]
            ]
            for key in (
                "characters",
                "relationships",
                "rosters",
                "locations",
                "inventory",
                "counters",
            )
        },
        "continuity_note": str(recovered.get("continuity_note") or "recovered scene"),
        **(
            {"source_attempt_id": str(recovered["source_attempt_id"])}
            if recovered.get("source_attempt_id")
            else {}
        ),
        **(
            {"source_provenance": dict(recovered["source_provenance"])}
            if isinstance(recovered.get("source_provenance"), dict)
            else {}
        ),
    }


def _has_complete_structured_scene_payload(value: dict[str, Any]) -> bool:
    raw_events = value.get("events")
    if not isinstance(raw_events, list) or any(
        not isinstance(item, dict) for item in raw_events
    ):
        return False
    raw_deltas = value.get("deltas")
    if not isinstance(raw_deltas, dict):
        return False
    for key in (
        "characters",
        "relationships",
        "rosters",
        "locations",
        "inventory",
        "counters",
    ):
        items = raw_deltas.get(key)
        if not isinstance(items, list) or any(
            not isinstance(item, dict) for item in items
        ):
            return False
    return True


def _dry_run_scene_result(
    plan: dict[str, Any],
    scene: dict[str, Any],
    *,
    chapter_blueprint: dict[str, Any] | None,
) -> dict[str, Any]:
    scene_index = int(scene.get("index") or 1)
    if chapter_blueprint is not None:
        beat_indexes = _scene_beat_indexes(scene)
        beat_texts = _beat_texts_for_indexes(chapter_blueprint, beat_indexes)
        text_parts = [
            (
                f"StoryProject beat {beat_index}: {beat_text}"
                if scene_index == 1 and position == 0
                else f"StoryProject beat {beat_index}: {_dry_run_unique_requirement(beat_text)}"
            )
            for position, (beat_index, beat_text) in enumerate(beat_texts)
        ]
        if scene_index == _last_scene_index(plan):
            ending_pressure = ending_requirement(chapter_blueprint)
            if ending_pressure:
                text_parts.append(
                    f"Ending pressure: {_dry_run_unique_requirement(ending_pressure)}"
                )
        prose = " ".join(text_parts) or str(scene.get("goal") or f"Scene {scene_index}")
    else:
        sentences = [
            sentence.strip() + "."
            for sentence in _DRY_RUN_CHAPTER.split(".")
            if sentence.strip()
        ]
        prose = sentences[min(scene_index - 1, len(sentences) - 1)]
    return {
        "prose": validate_text_output(prose, CHAPTER_CONTRACT),
        "events": [
            dict(item)
            for item in scene.get("planned_events") or []
            if isinstance(item, dict)
        ],
        "deltas": _empty_scene_deltas(),
        "continuity_note": "deterministic dry-run continuation",
    }


def _dry_run_unique_requirement(value: str) -> str:
    text = str(value or "").strip()
    for separator in ("：", ":"):
        if separator in text:
            suffix = text.rsplit(separator, 1)[-1].strip()
            if suffix:
                return suffix
    return text


def _empty_scene_deltas() -> dict[str, list[dict[str, Any]]]:
    return {
        "characters": [],
        "relationships": [],
        "rosters": [],
        "locations": [],
        "inventory": [],
        "counters": [],
    }


def _normalize_scene_event(value: dict[str, Any]) -> dict[str, Any]:
    event_id = str(value.get("event_id") or "").strip()
    event_type = str(value.get("type") or "").strip()
    if not event_id or not event_type:
        raise ValueError("scene response event requires event_id and type")
    return {
        "event_id": event_id,
        "type": event_type,
        "subjects": [
            str(item) for item in value.get("subjects") or [] if str(item)
        ],
        "objects": [
            str(item) for item in value.get("objects") or [] if str(item)
        ],
        "location": str(value.get("location") or ""),
        "status": str(value.get("status") or "completed"),
    }


def _normalize_planned_events(
    value: Any,
    *,
    chapter_index: int,
    scene_index: int,
    scene_type: str,
    required_beats: list[Any],
    required_beat_indexes: list[int],
) -> list[dict[str, Any]]:
    raw = [item for item in value or [] if isinstance(item, dict)] if isinstance(value, list) else []
    target_count = max(1, len(required_beats))
    events: list[dict[str, Any]] = []
    used_ids: set[str] = set()
    for offset in range(target_count):
        source = raw[offset] if offset < len(raw) else {}
        beat_index = (
            required_beat_indexes[offset]
            if offset < len(required_beat_indexes)
            else None
        )
        default_id = (
            f"chapter-{chapter_index:04d}-beat-{beat_index:03d}"
            if beat_index is not None
            else f"chapter-{chapter_index:04d}-scene-{scene_index:03d}-event-{offset + 1:03d}"
        )
        event_id = str(source.get("event_id") or default_id).strip()
        if event_id in used_ids:
            event_id = default_id
        used_ids.add(event_id)
        events.append(
            {
                "event_id": event_id,
                "type": str(
                    source.get("type")
                    or (
                        f"required_beat_{beat_index}_completed"
                        if beat_index is not None
                        else f"{scene_type}_advance_{scene_index}_{offset + 1}"
                    )
                ),
                "subjects": [
                    str(item)
                    for item in source.get("subjects") or []
                    if str(item)
                ],
                "objects": [
                    str(item)
                    for item in source.get("objects") or []
                    if str(item)
                ],
                "location": str(source.get("location") or ""),
                "status": str(source.get("status") or "completed"),
            }
        )
    return events


def merge_scenes(scene_drafts: list[dict[str, Any]]) -> str:
    merged, _scene_spans = _merge_scene_texts(scene_drafts)
    return validate_text_output(merged, CHAPTER_CONTRACT)


def _validate_plan(plan: dict[str, Any], *, chapter_index: int = 1, blueprint_plan: bool = False) -> dict[str, Any]:
    normalized = {
        "goal": str(plan.get("goal") or "Advance the chapter with clear conflict."),
        "scenes": [],
    }
    raw_scenes = plan.get("scenes")
    if not isinstance(raw_scenes, list) or not raw_scenes:
        raw_scenes = _dry_run_plan(1)["scenes"]
    prior_event_ids: list[str] = []
    for index, raw_scene in enumerate(raw_scenes, start=1):
        scene = raw_scene if isinstance(raw_scene, dict) else {}
        beats = scene.get("required_beats")
        if not isinstance(beats, list) or not beats:
            beats = [str(scene.get("goal") or "Move the scene forward.")]
        scene_type = str(scene.get("type") or "development")
        goal = str(scene.get("goal") or f"Scene {index}")
        story_project_beat_indexes = _scene_beat_indexes(scene)
        if index == 1 and not story_project_beat_indexes and not blueprint_plan:
            scene_type = "opening_bridge"
            goal = "Continue directly from last_chapter_ending"
            beats = [
                "repeat last known location",
                "show immediate consequence",
                "explain transition before new scene",
            ]
        planned_events = _normalize_planned_events(
            scene.get("planned_events"),
            chapter_index=chapter_index,
            scene_index=index,
            scene_type=scene_type,
            required_beats=beats,
            required_beat_indexes=story_project_beat_indexes,
        )
        required_event_ids = [str(item["event_id"]) for item in planned_events]
        forbidden_event_ids = list(dict.fromkeys([
            *prior_event_ids,
            *[
                str(item)
                for item in scene.get("forbidden_event_ids") or []
                if str(item)
            ],
        ]))
        normalized["scenes"].append(
            {
                "index": int(scene.get("index") or index),
                "type": scene_type,
                "goal": goal,
                "required_beats": [str(beat) for beat in beats if str(beat).strip()],
                **({"required_beat_indexes": story_project_beat_indexes} if story_project_beat_indexes else {}),
                "planned_events": planned_events,
                "required_event_ids": required_event_ids,
                "forbidden_event_ids": forbidden_event_ids,
            }
        )
        prior_event_ids.extend(required_event_ids)
    pipeline = validate_schema(
        {
            "chapter_index": 1,
            "plan": normalized,
            "scene_drafts": [{"index": 1, "goal": "placeholder", "text": "placeholder"}],
            "merged_chapter": "placeholder",
            "scene_spans": [{"index": 1, "start_char": 0, "end_char": 11, "chars": 11}],
            "stages": _pipeline_stages(),
        },
        "chapter_pipeline.schema.json",
    )
    return pipeline["plan"]


def _limit_plan_scenes(plan: dict[str, Any], scene_limit: int | None) -> dict[str, Any]:
    if scene_limit is None:
        return plan
    limit = max(1, int(scene_limit))
    scenes = plan.get("scenes")
    if not isinstance(scenes, list) or len(scenes) <= limit:
        return plan
    limited = dict(plan)
    limited["scenes"] = scenes[:limit]
    return _validate_plan(limited)


def _validate_scene_drafts(scene_drafts: list[dict[str, Any]]) -> list[dict[str, Any]]:
    pipeline = validate_schema(
        {
            "chapter_index": 1,
        "plan": {
            "goal": "placeholder",
            "scenes": [
                {
                    "index": 1,
                    "type": "opening_bridge",
                    "goal": "placeholder",
                    "required_beats": ["placeholder"],
                }
            ],
        },
        "scene_drafts": scene_drafts,
            "merged_chapter": "placeholder",
            "scene_spans": [{"index": 1, "start_char": 0, "end_char": 11, "chars": 11}],
            "stages": _pipeline_stages(),
        },
        "chapter_pipeline.schema.json",
    )
    return pipeline["scene_drafts"]


def _dry_run_plan(chapter_index: int) -> dict[str, Any]:
    return {
        "goal": f"Advance chapter {chapter_index} through alarm, blocked route, and serum conflict.",
        "scenes": [
            {
                "index": 1,
                "type": "opening_bridge",
                "goal": "Continue directly from last_chapter_ending",
                "required_beats": [
                    "repeat last known location",
                    "show immediate consequence",
                    "explain transition before new scene",
                ],
            },
            {
                "index": 2,
                "type": "development",
                "goal": "Reveal the sealed gate and new infection zone.",
                "required_beats": ["sealed gate", "safe route cut off", "infection zone"],
            },
            {
                "index": 3,
                "type": "development",
                "goal": "Force the protagonist into a serum-centered choice.",
                "required_beats": ["rescue teammate", "protect serum sample", "open conflict"],
            },
        ],
    }


def _dry_run_scene_drafts(
    plan: dict[str, Any],
    *,
    chapter_blueprint: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    return generate_scenes(
        "",
        plan,
        dry_run=True,
        chapter_blueprint=chapter_blueprint,
    )


def _scene_beat_indexes(scene: dict[str, Any]) -> list[int]:
    raw = scene.get("required_beat_indexes")
    if not isinstance(raw, list):
        return []
    indexes: list[int] = []
    for value in raw:
        if isinstance(value, int) and not isinstance(value, bool) and value >= 1 and value not in indexes:
            indexes.append(value)
    return indexes


def _last_scene_index(plan: dict[str, Any]) -> int:
    indexes = [
        int(scene.get("index"))
        for scene in plan.get("scenes", [])
        if isinstance(scene, dict) and isinstance(scene.get("index"), int)
    ]
    return max(indexes) if indexes else 1


def _beat_texts_for_indexes(chapter_blueprint: dict[str, Any], indexes: list[int]) -> list[tuple[int, str]]:
    by_index: dict[int, str] = {}
    for beat in chapter_blueprint.get("required_beats") or []:
        if not isinstance(beat, dict):
            continue
        index = beat.get("index")
        if isinstance(index, int) and not isinstance(index, bool):
            by_index[index] = str(beat.get("text") or "")
    return [(index, by_index.get(index, "")) for index in indexes]


def _merge_scene_texts(scene_drafts: list[dict[str, Any]]) -> tuple[str, list[dict[str, int]]]:
    parts: list[str] = []
    spans: list[dict[str, int]] = []
    cursor = 0
    for scene in scene_drafts:
        text = str(scene.get("text") or "").strip()
        if not text:
            continue
        if parts:
            cursor += 2
        start = cursor
        end = start + len(text)
        spans.append(
            {
                "index": int(scene.get("index") or len(spans) + 1),
                "start_char": start,
                "end_char": end,
                "chars": len(text),
            }
        )
        parts.append(text)
        cursor = end
    return "\n\n".join(parts), spans


def _pipeline_stages(overrides: dict[str, dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    overrides = overrides or {}
    stages: list[dict[str, Any]] = []
    for name in PIPELINE_STAGE_NAMES:
        override = overrides.get(name, {})
        stage: dict[str, Any] = {
            "name": name,
            "status": str(override.get("status") or "pending"),
        }
        artifact_key = override.get("artifact_key")
        if artifact_key:
            stage["artifact_key"] = str(artifact_key)
        summary = override.get("summary")
        if isinstance(summary, dict):
            stage["summary"] = summary
        stages.append(stage)
    return stages


__all__ = [
    "PIPELINE_STAGE_NAMES",
    "generate_scenes",
    "merge_scenes",
    "plan_chapter",
    "plan_scenes",
    "run_chapter_pipeline",
]
