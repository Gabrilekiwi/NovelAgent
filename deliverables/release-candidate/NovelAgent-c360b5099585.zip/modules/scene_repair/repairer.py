from __future__ import annotations

import copy
import json
from dataclasses import dataclass
from pathlib import Path
import re
from typing import Any, Callable

from api.contracts import REPAIR_CONTRACT, validate_text_output
from api.openai_client import chat_completion
from core.config import get_config
import core.context_budget as context_budget
from core.context_budget import (
    ContextBudgetError,
    conservative_calibrated_token_estimate,
    default_context_budget,
    preview_chinese_output_compatibility,
)
from core.model_call_runtime import current_model_call_runtime
from core.prompt_compiler import PROMPT_CONTEXT_SELECTION_KEYS, compile_prompt_contexts
from core.quality.repair_patch import coerce_repair_patch
from core.schema import validate_schema
from core.state.generation_state_view import generation_state_view_from_markdown
from core.state.authoritative_context import (
    AUTHORITATIVE_REPAIR_SECTION_MAX_CHARS,
    authoritative_state_from_markdown,
    compact_authoritative_state_in_markdown,
)
from core.state.story_state_context import STORY_STATE_CONTEXT_KEYS, STORY_STATE_SECTION_MAX_CHARS
from core.structured_context import (
    StructuredContextError,
    compact_markdown_context,
    select_json_items,
    sha256_text,
)
from modules.scene_repair.envelope import (
    build_repair_envelope,
    generation_state_view_sha256,
    project_repair_envelope_for_budget,
    repair_validation_sha256,
)
from modules.scene_repair.ledger import project_canonical_repair_ledger
from modules.scene_repair.plan import build_repair_plan


_PROMPT_PATH = Path("prompts/repair_prompt.md")
_REPAIR_INPUT_HEADROOM_TOKENS = 2_000
_LEGACY_REPAIR_CONTEXT_POLICIES = (
    {
        "authority_section_chars": 8_000,
        "context_chars": 14_000,
        "per_section_chars": 2_500,
    },
    {
        "authority_section_chars": 12_000,
        "context_chars": 18_000,
        "per_section_chars": 2_500,
    },
    {
        "authority_section_chars": 16_000,
        "context_chars": 22_000,
        "per_section_chars": 2_500,
    },
    {
        "authority_section_chars": 22_000,
        "context_chars": 28_000,
        "per_section_chars": 2_500,
    },
)
_EXPLICIT_REPAIR_PROMPT_SUFFIX = """

## Explicit RepairEnvelope V1

The user message is one verified `repair_envelope`. Treat its
`generation_state_projection` as the only model-facing state projection and
its `chapter_contract` as the narrative intent that the repair must preserve.
The complete authoritative ledger remains local to the runtime and is
intentionally absent.

Each item in `repair_plan.steps` references exactly one canonical item in
`problems` by `problem_id`. Read the problem message, repair hint, and evidence
from that canonical problem; do not expect them to be duplicated in the step.
Use the single top-level `recovery_context` for prior-attempt evidence.
""".rstrip()
_REPAIR_LEDGER_PROMPT_SUFFIX = """

## Projected Problem Ledger

When `problem_types` is present, each problem's `type_id` points at one shared
type. Read `code`, `message`, `validator`, `severity`, `blocking`, `category`,
`repair_hint`, `action`, and `strategy` from that type. If the type has
`shared_evidence` or `parameters`, combine them with the problem's own
`evidence` and any step-level `parameters`. Missing type-level fields on the
problem or step object are inherited from the type, not absent facts.
""".rstrip()
RepairStrategy = Callable[[str, dict[str, Any], list[dict[str, Any]]], str]


@dataclass(frozen=True)
class RepairContext:
    language: str = "en"
    allow_new_facts: bool = False
    known_conflict_hint: str | None = None


def repair_scene(
    chapter_text: str,
    validation: dict[str, Any],
    input_pack: str,
    *,
    dry_run: bool = False,
    repair_plan: dict[str, Any] | None = None,
    recovery_context: dict[str, Any] | None = None,
    language: str = "en",
    repair_context: RepairContext | None = None,
) -> str | dict[str, Any]:
    context = repair_context or RepairContext(language=language or "en")
    effective_plan = validate_schema(
        repair_plan if repair_plan is not None else build_repair_plan(validation, recovery_context=recovery_context),
        "repair_plan.schema.json",
    )
    if not dry_run:
        return _repair_with_model(chapter_text, validation, input_pack, effective_plan, recovery_context, context)
    return _repair_locally(chapter_text, validation, effective_plan, context)


def _repair_with_model(
    chapter_text: str,
    validation: dict[str, Any],
    input_pack: str,
    repair_plan: dict[str, Any],
    recovery_context: dict[str, Any] | None,
    repair_context: RepairContext,
) -> str | dict[str, Any]:
    messages = build_repair_messages(
        chapter_text,
        validation,
        input_pack,
        repair_plan,
        recovery_context,
        repair_context,
    )
    payload = messages[-1]["content"]
    protocol = messages[0]["content"]
    default_context_budget().require_input(
        payload,
        stage="repair",
        protocol_texts=(protocol,),
    )
    max_output_tokens = _repair_max_output_tokens(
        chapter_text,
        language=repair_context.language,
    )
    output = chat_completion(
        messages,
        temperature=0.2,
        stage="scene_repair",
        max_tokens=max_output_tokens,
    )
    stripped = str(output).strip()
    repaired_text: str | None = None
    if stripped.startswith("{") and stripped.endswith("}"):
        try:
            patch = coerce_repair_patch(
                chapter_text,
                stripped,
                problem_codes=[
                    str(item.get("code") or "")
                    for item in validation.get("problems") or []
                    if isinstance(item, dict)
                ],
            )
            from core.quality.repair_patch import apply_repair_patch

            repaired_text, _audit = apply_repair_patch(chapter_text, patch)
        except ValueError:
            repaired_text = None
    if repaired_text is None:
        repaired_text = validate_text_output(output, REPAIR_CONTRACT)
    return _finalize_last_scene_anchors(repaired_text, repair_plan, repair_context)


def build_repair_messages(
    chapter_text: str,
    validation: dict[str, Any],
    input_pack: str,
    repair_plan: dict[str, Any],
    recovery_context: dict[str, Any] | None,
    repair_context: RepairContext,
    *,
    expected_validation_sha256: str | None = None,
    expected_generation_state_view_sha256: str | None = None,
) -> list[dict[str, str]]:
    """Build the exact final repair messages without calling a provider."""

    generation_state_view = generation_state_view_from_markdown(input_pack)
    if generation_state_view is None:
        return _build_legacy_repair_messages(
            chapter_text,
            validation,
            input_pack,
            repair_plan,
            recovery_context,
            repair_context,
        )

    read_set = generation_state_view.get("chapter_context_read_set")
    chapter_index = (
        read_set.get("chapter_index")
        if isinstance(read_set, dict)
        else None
    )
    bound_validation_sha256 = (
        expected_validation_sha256
        if expected_validation_sha256 is not None
        else repair_validation_sha256(validation)
    )
    bound_view_sha256 = (
        expected_generation_state_view_sha256
        if expected_generation_state_view_sha256 is not None
        else generation_state_view_sha256(generation_state_view)
    )
    envelope = build_repair_envelope(
        chapter_text,
        validation,
        repair_plan,
        chapter_index=chapter_index,
        recovery_context=_explicit_recovery_context(recovery_context),
        generation_state_view=generation_state_view,
        chapter_contract=_repair_chapter_contract(
            input_pack,
            chapter_index=chapter_index,
        ),
        expected_validation_sha256=bound_validation_sha256,
        expected_generation_state_view_sha256=bound_view_sha256,
    )
    prompt = _explicit_repair_prompt(repair_context)
    messages = _repair_messages(
        prompt,
        json.dumps(
            envelope,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ),
    )
    if _repair_messages_fit_safe_target(messages):
        return messages
    projected = project_repair_envelope_for_budget(envelope)
    projected_prompt = _explicit_repair_prompt(
        repair_context,
        include_ledger_projection=True,
    )
    projected_messages = _repair_messages(
        projected_prompt,
        json.dumps(
            projected,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ),
    )
    if _repair_messages_fit_safe_target(projected_messages):
        return projected_messages
    _raise_repair_context_headroom_exceeded(projected_messages)


def _build_legacy_repair_messages(
    chapter_text: str,
    validation: dict[str, Any],
    input_pack: str,
    repair_plan: dict[str, Any],
    recovery_context: dict[str, Any] | None,
    repair_context: RepairContext,
) -> list[dict[str, str]]:
    repair_query = json.dumps(
        {
            "problem_codes": [str(item.get("code") or "") for item in validation.get("problems") or [] if isinstance(item, dict)],
            "repair_plan": repair_plan,
        },
        ensure_ascii=False,
        sort_keys=True,
    )
    compiled_context = compile_prompt_contexts(
        input_pack,
        query_hint=repair_query,
    ).repair.text
    authoritative_state_source = authoritative_state_from_markdown(input_pack)
    prompt = _load_prompt()
    budget = default_context_budget()
    safe_target = max(
        1,
        budget.hard_input_limit - _REPAIR_INPUT_HEADROOM_TOKENS,
    )
    last_context_error: StructuredContextError | None = None

    try:
        compact_context = _compact_repair_context(
            compiled_context,
            query=repair_query,
            authoritative_state_source=authoritative_state_source,
        )
        payload = _legacy_repair_payload(
            chapter_text,
            validation,
            repair_plan,
            recovery_context,
            repair_context,
            compact_context,
        )
        report = budget.measure(
            payload,
            stage="repair",
            protocol_texts=(prompt,),
        )
        if report["budgeted_input_tokens"] <= safe_target:
            return _repair_messages(prompt, payload)
    except StructuredContextError as exc:
        last_context_error = exc

    lean_validation = _legacy_validation_summary(validation)
    measured_candidates: list[tuple[int, str]] = []
    for policy in _LEGACY_REPAIR_CONTEXT_POLICIES:
        try:
            compact_context = _compact_repair_context(
                compiled_context,
                query=repair_query,
                authoritative_state_source=authoritative_state_source,
                authority_section_chars=policy["authority_section_chars"],
                context_chars=policy["context_chars"],
                per_section_chars=policy["per_section_chars"],
                authority_selection_mode="required_only",
                policy="repair_markdown_json_retrieval_required_only_v2",
            )
        except StructuredContextError as exc:
            last_context_error = exc
            continue
        payload = _legacy_repair_payload(
            chapter_text,
            validation,
            repair_plan,
            recovery_context,
            repair_context,
            compact_context,
            validation_projection=lean_validation,
            compact_json=True,
        )
        report = budget.measure(
            payload,
            stage="repair",
            protocol_texts=(prompt,),
        )
        measured_tokens = int(report["budgeted_input_tokens"])
        measured_candidates.append((measured_tokens, payload))
        if measured_tokens <= safe_target:
            return _repair_messages(prompt, payload)

    projected_messages = _legacy_projected_repair_messages(
        chapter_text,
        validation,
        repair_plan,
        recovery_context,
        repair_context,
        compiled_context,
        authoritative_state_source,
        repair_query,
        prompt,
        budget,
        safe_target,
        last_context_error,
    )
    if projected_messages is not None:
        return projected_messages
    if measured_candidates:
        required_tokens, _payload = min(measured_candidates, key=lambda item: item[0])
        raise ContextBudgetError(
            "story_project_repair_context_headroom_exceeded",
            f"repair input requires {required_tokens} tokens; safe target is "
            f"{safe_target}; hard limit is {budget.hard_input_limit}",
        )
    if last_context_error is not None:
        raise ContextBudgetError(
            "story_project_repair_authority_unfit",
            "repair context cannot preserve all required authoritative records "
            f"within the available prompt projection: {last_context_error}",
        ) from last_context_error
    raise ContextBudgetError(
        "story_project_repair_context_unavailable",
        "repair context could not be projected without dropping required facts",
    )


def _repair_messages_fit_safe_target(messages: list[dict[str, str]]) -> bool:
    budget = context_budget.default_context_budget()
    safe_target = max(1, budget.hard_input_limit - _REPAIR_INPUT_HEADROOM_TOKENS)
    report = budget.measure(
        messages[-1]["content"],
        stage="repair",
        protocol_texts=(messages[0]["content"],),
    )
    return int(report["budgeted_input_tokens"]) <= safe_target


def _raise_repair_context_headroom_exceeded(
    messages: list[dict[str, str]],
) -> None:
    budget = context_budget.default_context_budget()
    safe_target = max(1, budget.hard_input_limit - _REPAIR_INPUT_HEADROOM_TOKENS)
    report = budget.measure(
        messages[-1]["content"],
        stage="repair",
        protocol_texts=(messages[0]["content"],),
    )
    raise ContextBudgetError(
        "story_project_repair_context_headroom_exceeded",
        "repair input requires "
        f"{int(report['budgeted_input_tokens'])} tokens; safe target is "
        f"{safe_target}; hard limit is {budget.hard_input_limit}",
    )


def _legacy_projected_repair_messages(
    chapter_text: str,
    validation: dict[str, Any],
    repair_plan: dict[str, Any],
    recovery_context: dict[str, Any] | None,
    repair_context: RepairContext,
    compiled_context: str,
    authoritative_state_source: dict[str, Any] | None,
    repair_query: str,
    prompt: str,
    budget: Any,
    safe_target: int,
    last_context_error: StructuredContextError | None,
) -> list[dict[str, str]] | None:
    from modules.scene_repair.envelope import _canonical_problem_contract

    try:
        canonical_problems, compact_plan = _canonical_problem_contract(
            validation,
            repair_plan,
        )
        problem_types, problems, projected_plan = project_canonical_repair_ledger(
            canonical_problems,
            compact_plan,
        )
    except (TypeError, ValueError):
        return None

    prompt_with_ledger = (
        prompt + "\n\n" + _REPAIR_LEDGER_PROMPT_SUFFIX
        if _REPAIR_LEDGER_PROMPT_SUFFIX not in prompt
        else prompt
    )
    lean_validation = _legacy_validation_summary(validation)
    policies: list[dict[str, int] | None] = [None, *_LEGACY_REPAIR_CONTEXT_POLICIES]
    best_tokens: int | None = None
    best_messages: list[dict[str, str]] | None = None
    for policy in policies:
        try:
            if policy is None:
                compact_context = _compact_repair_context(
                    compiled_context,
                    query=repair_query,
                    authoritative_state_source=authoritative_state_source,
                )
            else:
                compact_context = _compact_repair_context(
                    compiled_context,
                    query=repair_query,
                    authoritative_state_source=authoritative_state_source,
                    authority_section_chars=policy["authority_section_chars"],
                    context_chars=policy["context_chars"],
                    per_section_chars=policy["per_section_chars"],
                    authority_selection_mode="required_only",
                    policy="repair_markdown_json_retrieval_required_only_v2",
                )
        except StructuredContextError:
            continue
        payload = _legacy_repair_payload(
            chapter_text,
            validation,
            projected_plan,
            recovery_context,
            repair_context,
            compact_context,
            validation_projection=lean_validation,
            compact_json=True,
            problem_types=problem_types,
            problems=problems,
        )
        report = budget.measure(
            payload,
            stage="repair",
            protocol_texts=(prompt_with_ledger,),
        )
        measured_tokens = int(report["budgeted_input_tokens"])
        messages = _repair_messages(prompt_with_ledger, payload)
        if measured_tokens <= safe_target:
            return messages
        if best_tokens is None or measured_tokens < best_tokens:
            best_tokens = measured_tokens
            best_messages = messages
    if best_messages is not None:
        _raise_repair_context_headroom_exceeded(best_messages)
    return None


def _repair_messages(prompt: str, payload: str) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": prompt},
        {"role": "user", "content": payload},
    ]


def _legacy_repair_payload(
    chapter_text: str,
    validation: dict[str, Any],
    repair_plan: dict[str, Any],
    recovery_context: dict[str, Any] | None,
    repair_context: RepairContext,
    compact_context: str,
    *,
    validation_projection: dict[str, Any] | None = None,
    compact_json: bool = False,
    problem_types: list[dict[str, Any]] | None = None,
    problems: list[dict[str, Any]] | None = None,
) -> str:
    payload = {
        "chapter": chapter_text,
        "base_chapter_sha256": sha256_text(chapter_text),
        "validation": (
            validation_projection
            if validation_projection is not None
            else _compact_validation(validation)
        ),
        "repair_plan": repair_plan,
        "recovery_context": recovery_context or {"available": False},
        "repair_context": {
            "language": _normalized_language(repair_context.language),
            "allow_new_facts": repair_context.allow_new_facts,
            "known_conflict_hint": repair_context.known_conflict_hint,
        },
        "context_digest_and_excerpts": compact_context,
        "response_contract": {
            "preferred": "RepairPatch JSON",
            "schema_version": "1.0",
            "operation": "replace",
            "model_required_hashes": [
                "base_chapter_sha256",
                "expected_text_sha256",
            ],
            "runtime_bound_hashes": [
                "output_chapter_sha256",
                "patch_sha256",
            ],
            "fallback": "complete replacement chapter prose",
        },
    }
    if problem_types is not None:
        payload["problem_types"] = problem_types
    if problems is not None:
        payload["problems"] = problems
    if compact_json:
        return json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
    return json.dumps(payload, ensure_ascii=False, indent=2)


def _legacy_validation_summary(validation: dict[str, Any]) -> dict[str, Any]:
    compact = _compact_validation(validation)
    return {
        key: value
        for key, value in compact.items()
        if key != "problems"
    } | {"problem_details_source": "repair_plan.steps"}


def _explicit_recovery_context(
    recovery_context: dict[str, Any] | None,
) -> dict[str, Any]:
    if not isinstance(recovery_context, dict):
        return {"available": False}
    compact = copy.deepcopy(recovery_context)
    previous_plan = compact.pop("repair_plan", None)
    if isinstance(previous_plan, dict):
        compact["previous_repair_summary"] = previous_plan
    return compact


def _repair_chapter_contract(
    input_pack: str,
    *,
    chapter_index: int,
) -> dict[str, Any]:
    contract: dict[str, Any] = {"chapter_index": int(chapter_index)}
    match = re.search(
        r"(?ms)^# StoryProject Chapter Blueprint[ \t]*\r?\n"
        r"(.*?)(?=^# |\Z)",
        str(input_pack or ""),
    )
    if match is None:
        return contract
    try:
        payload = json.loads(match.group(1).strip())
    except (TypeError, ValueError) as exc:
        raise ValueError(
            "StoryProject Chapter Blueprint must contain one JSON object"
        ) from exc
    if not isinstance(payload, dict):
        raise ValueError(
            "StoryProject Chapter Blueprint must contain one JSON object"
        )
    blueprint = payload.get("chapter_blueprint")
    if not isinstance(blueprint, dict):
        return contract
    for field in (
        "title",
        "chapter_goal",
        "core_event",
        "human_conflict",
        "required_beats",
        "ending_pressure",
    ):
        if field in blueprint:
            contract[field] = copy.deepcopy(blueprint[field])
    declared_chapter = blueprint.get("chapter_index")
    if declared_chapter is not None:
        contract["chapter_index"] = declared_chapter
    return contract


def _explicit_repair_prompt(
    repair_context: RepairContext,
    *,
    include_ledger_projection: bool = False,
) -> str:
    directives = {
        "language": _normalized_language(repair_context.language),
        "allow_new_facts": bool(repair_context.allow_new_facts),
        "known_conflict_hint": repair_context.known_conflict_hint,
    }
    suffix = _EXPLICIT_REPAIR_PROMPT_SUFFIX
    if include_ledger_projection:
        suffix += "\n\n" + _REPAIR_LEDGER_PROMPT_SUFFIX
    return (
        _load_prompt()
        + "\n\n"
        + suffix
        + "\n\nRepair directives:\n"
        + json.dumps(
            directives,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
    )


def _repair_max_output_tokens(
    chapter_text: str,
    *,
    language: str = "zh-CN",
) -> int:
    requested = max(1, int(get_config().openai_max_output_tokens))
    compatibility = (
        preview_chinese_output_compatibility(requested)
        if _normalized_language(language) == "zh-CN"
        else {"maximum_required_tokens": 0}
    )
    minimum_required = max(
        int(compatibility["maximum_required_tokens"]),
        conservative_calibrated_token_estimate(chapter_text) + 1_024,
    )
    if requested < minimum_required:
        raise ContextBudgetError(
            "scene_repair_output_cap_incompatible",
            "scene repair requires at least "
            f"{minimum_required} output tokens for a complete replacement chapter; "
            f"configured cap is {requested}",
        )

    runtime = current_model_call_runtime()
    remaining = runtime.remaining_output_tokens() if runtime is not None else None
    if remaining is None:
        return requested
    if remaining < minimum_required:
        raise ContextBudgetError(
            "scene_repair_output_budget_insufficient",
            "scene repair requires at least "
            f"{minimum_required} output tokens for a complete replacement chapter; "
            f"run budget has {remaining} remaining",
        )
    return min(requested, remaining)


def _compact_validation(validation: dict[str, Any]) -> dict[str, Any]:
    problems = validation.get("problems")
    if not isinstance(problems, list):
        problems = []
        for check in validation.get("checks") or []:
            if isinstance(check, dict) and isinstance(check.get("problems"), list):
                problems.extend(check["problems"])
    compact_problems: list[dict[str, Any]] = []
    for raw in problems:
        if not isinstance(raw, dict):
            continue
        evidence = raw.get("evidence") if isinstance(raw.get("evidence"), list) else []
        normalized_evidence = [
            {
                "kind": str(item.get("kind") or "evidence"),
                "value": str(item.get("value") or ""),
            }
            for item in evidence
            if isinstance(item, dict)
        ]
        evidence_selection = select_json_items(
            normalized_evidence,
            max_chars=2_400,
            query=f"{raw.get('code') or ''} {raw.get('message') or ''}",
            max_items=4,
            policy="repair_evidence_json_items_v1",
        )
        compact_problems.append(
            {
                key: raw.get(key)
                for key in ("code", "message", "validator", "severity", "blocking", "repair_action")
                if raw.get(key) is not None
            }
            | {
                "evidence": list(evidence_selection.items),
                "evidence_selection": dict(evidence_selection.manifest),
            }
        )
    required_problem_indexes = {
        index
        for index, problem in enumerate(compact_problems)
        if problem.get("blocking") is True
    }
    problem_selection = select_json_items(
        compact_problems,
        max_chars=16_000,
        query=" ".join(str(item.get("code") or "") for item in compact_problems),
        required_indexes=required_problem_indexes,
        prefer_recent=True,
        policy="repair_problem_json_items_v1",
    )
    selected_problems = list(problem_selection.items)
    serialized_validation = json.dumps(validation, ensure_ascii=False, sort_keys=True, default=str)
    return {
        "ok": bool(validation.get("ok")),
        "requested_focus": list(validation.get("requested_focus") or []),
        "executed_checks": list(validation.get("executed_checks") or []),
        "skipped_checks": list(validation.get("skipped_checks") or []),
        "problem_codes": [str(item.get("code") or "") for item in selected_problems],
        "problems": selected_problems,
        "selection": {
            **dict(problem_selection.manifest),
            "source_sha256": sha256_text(serialized_validation),
            "original_chars": len(serialized_validation),
        },
    }


def _compact_repair_context(
    text: str,
    *,
    max_section_chars: int = 4_000,
    query: str = "",
    authoritative_state_source: dict[str, Any] | None = None,
    authority_section_chars: int | None = None,
    context_chars: int | None = None,
    per_section_chars: int | None = None,
    authority_selection_mode: str = "ranked",
    policy: str = "repair_markdown_json_retrieval_v1",
) -> str:
    """Retrieve complete repair-relevant sections, paragraphs, and JSON items."""
    authority_section_limit = (
        max(1, int(authority_section_chars))
        if authority_section_chars is not None
        else min(
            AUTHORITATIVE_REPAIR_SECTION_MAX_CHARS,
            max(1, max_section_chars * 5),
        )
    )
    context_limit = (
        max(1, int(context_chars))
        if context_chars is not None
        else max_section_chars * 5
    )
    per_section_limit = (
        max(1, int(per_section_chars))
        if per_section_chars is not None
        else max_section_chars
    )
    projected_text = compact_authoritative_state_in_markdown(
        text,
        max_section_chars=authority_section_limit,
        query=query,
        authoritative_state_source=authoritative_state_source,
        selection_mode=authority_selection_mode,
    )
    selection = compact_markdown_context(
        projected_text,
        max_chars=context_limit,
        per_section_max_chars=per_section_limit,
        query=query,
        required_sections={
            "Context Digest",
            "Prompt Context Selection",
            "Project Profile",
            "Story State",
            "Spatial State",
            "Authoritative State",
            "StoryProject Chapter Blueprint",
            "Requirements",
            "灏忚鐢熸垚瑙勫垯濂戠害",
        },
        excluded_sections={"Memory Index", "Structured Context Manifest"},
        required_json_keys={
            "Prompt Context Selection": PROMPT_CONTEXT_SELECTION_KEYS,
            "Story State": STORY_STATE_CONTEXT_KEYS,
            "StoryProject Chapter Blueprint": {"chapter_blueprint", "read_set_context_digest"},
        },
        allowed_json_keys={
            "Prompt Context Selection": PROMPT_CONTEXT_SELECTION_KEYS,
            "Story State": STORY_STATE_CONTEXT_KEYS,
        },
        section_max_chars={
            "Story State": STORY_STATE_SECTION_MAX_CHARS,
            "Authoritative State": authority_section_limit,
        },
        prefer_recent=True,
        policy=policy,
    )
    return selection.text


def _load_prompt() -> str:
    return _PROMPT_PATH.read_text(encoding="utf-8")


def _repair_locally(
    chapter_text: str,
    validation: dict[str, Any],
    repair_plan: dict[str, Any],
    repair_context: RepairContext,
) -> str:
    repaired = chapter_text.strip()
    return apply_repair_plan(repaired, repair_plan, repair_context=repair_context)


def apply_repair_plan(
    chapter_text: str,
    repair_plan: dict[str, Any],
    *,
    language: str = "en",
    repair_context: RepairContext | None = None,
) -> str:
    context = repair_context or RepairContext(language=language or "en")
    strategies = REPAIR_STRATEGY_REGISTRY[_normalized_language(context.language)]
    repaired = chapter_text.strip()
    steps = [step for step in repair_plan.get("steps", []) if isinstance(step, dict)]
    steps.sort(key=lambda step: (int(step.get("priority") or 0), int(step.get("index") or 0)))
    for step in steps:
        action = str(step.get("action") or "")
        if (
            action == "add_conflict_signal"
            and _normalized_language(context.language) == "zh-CN"
            and context.known_conflict_hint
        ):
            step = dict(step)
            step["parameters"] = {
                **_parameters(step),
                "conflict_hint": context.known_conflict_hint,
            }
        strategy = strategies.get(action, _manual_review)
        repaired = strategy(repaired, step, steps).strip()
    return repaired


def _seed_conflict_scene(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    if text:
        return text
    return (
        "A local repair begins as the protagonist faces immediate danger, makes a costly choice, "
        "and pulls the team into open conflict."
    )


def _expand_scene(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    return (
        f"{text}\n\nThe decision carries a visible cost: retreat protects what the team carries, but rescue risks "
        "spreading the infection and splitting the team."
    )


def _add_conflict_signal(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    return f"{text}\n\nA new danger forces a clear choice, and the team conflict becomes impossible to avoid."


def _repair_forbidden_term(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    term = str(_parameters(step).get("term", "")).strip()
    return _remove_case_insensitive(text, term) if term else text


def _repair_required_term(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    term = str(_parameters(step).get("term", "")).strip()
    if not term:
        return text
    return f"{text}\n\nThe scene keeps focus on: {term}."


def _repair_known_location(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    location = str(_parameters(step).get("suggested_term", "")).strip()
    if not location:
        return text
    return f"{text}\n\nThe action remains anchored at {location}."


def _insert_opening_bridge(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    parameters = _parameters(step)
    bridge = str(parameters.get("bridge", "")).strip()
    location = str(parameters.get("location", "")).strip()
    bridge_text = _bridge_sentence(bridge, location)
    return _prepend_sentence(text, bridge_text)


def _rewrite_spatial_transition(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    expected = str(_parameters(step).get("expected", "")).strip()
    actual = str(_parameters(step).get("actual", "")).strip()
    if not expected or not actual:
        return text
    return _prepend_sentence(
        text,
        f"From {expected}, the movement into {actual} happens in view, with the last scene's pressure still driving every step.",
    )


def _anchor_last_scene_state(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    location, characters = _last_scene_anchor_targets(step, steps)
    if not location and not characters:
        return text
    opening = _opening_window(text)
    lowered = opening.lower()
    missing = [name for name in characters if name.lower() not in lowered]
    location_missing = bool(location) and location.lower() not in lowered
    if not missing and not location_missing:
        return text
    cast = ", ".join(characters) if characters else "the group"
    if location:
        return _prepend_sentence(
            text,
            f"At {location}, {cast} is still dealing with the last scene's immediate fallout",
        )
    return _prepend_sentence(text, f"{cast} is still dealing with the last scene's immediate fallout")


def _repair_character_position(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    parameters = _parameters(step)
    character = str(parameters.get("character", "The character")).strip()
    expected = str(parameters.get("expected", "")).strip()
    actual = str(parameters.get("actual", "")).strip()
    if not expected:
        return text
    suffix = f" before any move toward {actual}" if actual else ""
    return f"{text}\n\n{character} starts at {expected}{suffix}, so the next movement follows from a clear position."


def _add_transition_event(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    expected = str(_parameters(step).get("expected", "")).strip()
    actual = str(_parameters(step).get("actual", "")).strip()
    if not expected or not actual:
        return text
    return f"{text}\n\nThe route from {expected} to {actual} becomes explicit before the scene commits to the new space."


def _flag_unknown_location(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    character = str(_parameters(step).get("character", "The scene")).strip()
    return f"{text}\n\n{character} avoids relying on an unknown offstage location; the movement stays spatially explicit."


def _repair_character_location(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    character = str(_parameters(step).get("character", "the character")).strip()
    location = str(_parameters(step).get("location", "their current location")).strip()
    return f"{text}\n\n{character} remains at {location}, keeping the scene spatially consistent."


def _repair_inactive_character_action(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    character = str(_parameters(step).get("character", "")).strip()
    return _replace_character_action_sentence(text, character) if character else text


def _replace_character_action_sentence(text: str, character: str) -> str:
    pattern = re.compile(
        rf"[^.!?\n]*\b{re.escape(character)}\b[^.!?\n]*(?:[.!?]|$)",
        flags=re.IGNORECASE,
    )

    def replacement(match: re.Match[str]) -> str:
        original = match.group(0)
        if not _contains_action_marker(original):
            return original
        return (
            f"{character} remains unavailable in this scene; the team reacts to that absence "
            "as the danger and conflict intensify."
        )

    return pattern.sub(replacement, text, count=1)


def _contains_action_marker(text: str) -> bool:
    return bool(re.search(r"\b(said|walked|ran|smiled|looked|speaks|shouted)\b", text, flags=re.IGNORECASE))


def _repair_chapter_index(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    expected = str(_parameters(step).get("expected", "")).strip()
    return _replace_declared_chapter(text, expected) if expected else text


def _manual_review(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    return text


def _zh_no_safe_repair(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    return text


def _zh_add_known_conflict_signal(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    hint = str(_parameters(step).get("conflict_hint", "")).strip()
    return f"{text}\n\n冲突焦点仍是：{hint}。" if hint else text


def _zh_repair_forbidden_term(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    term = str(_parameters(step).get("term", "")).strip()
    return re.sub(re.escape(term), "该事项", text, flags=re.IGNORECASE) if term else text


def _zh_repair_required_term(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    term = str(_parameters(step).get("term", "")).strip()
    return f"{text}\n\n场景仍围绕“{term}”推进。" if term else text


def _zh_repair_known_location(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    location = str(_parameters(step).get("suggested_term", "")).strip()
    return f"{text}\n\n行动始终发生在{location}。" if location else text


def _zh_insert_opening_bridge(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    bridge = str(_parameters(step).get("bridge", "")).strip()
    return _prepend_sentence(text, bridge) if bridge else text


def _zh_rewrite_spatial_transition(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    parameters = _parameters(step)
    expected = str(parameters.get("expected", "")).strip()
    actual = str(parameters.get("actual", "")).strip()
    if not expected or not actual:
        return text
    return _prepend_sentence(text, f"从{expected}到{actual}的移动过程清晰发生在场景中")


def _zh_anchor_last_scene_state(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    location, characters = _last_scene_anchor_targets(step, steps)
    if not location and not characters:
        return text
    opening = _opening_window(text)
    lowered = opening.lower()
    missing = [name for name in characters if name.lower() not in lowered]
    location_missing = bool(location) and location.lower() not in lowered
    if not missing and not location_missing:
        return text
    cast = "、".join(characters)
    if location and cast:
        return _prepend_sentence(text, f"在{location}，{cast}仍在承受上一场景的直接后果")
    if location:
        return _prepend_sentence(text, f"在{location}，上一场景的直接后果仍在延续")
    return _prepend_sentence(text, f"{cast}仍在承受上一场景的直接后果")


def _zh_repair_character_position(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    parameters = _parameters(step)
    character = str(parameters.get("character", "")).strip()
    expected = str(parameters.get("expected", "")).strip()
    actual = str(parameters.get("actual", "")).strip()
    if not character or not expected:
        return text
    suffix = f"，随后才向{actual}移动" if actual else ""
    return f"{text}\n\n{character}起初位于{expected}{suffix}。"


def _zh_add_transition_event(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    parameters = _parameters(step)
    expected = str(parameters.get("expected", "")).strip()
    actual = str(parameters.get("actual", "")).strip()
    if not expected or not actual:
        return text
    return f"{text}\n\n场景明确呈现了从{expected}前往{actual}的过程。"


def _zh_repair_character_location(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    parameters = _parameters(step)
    character = str(parameters.get("character", "")).strip()
    location = str(parameters.get("location", "")).strip()
    return f"{text}\n\n{character}仍在{location}。" if character and location else text


def _zh_repair_inactive_character_action(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    character = str(_parameters(step).get("character", "")).strip()
    if not character:
        return text
    pattern = re.compile(rf"[^。！？!?\n]*{re.escape(character)}[^。！？!?\n]*(?:[。！？!?]|$)")

    def replacement(match: re.Match[str]) -> str:
        sentence = match.group(0)
        if not re.search(r"说|走|跑|笑|看|喊|冲|抓|推|打开|关闭|拿起|放下", sentence):
            return sentence
        return ""

    return pattern.sub(replacement, text, count=1).strip()


def _zh_repair_chapter_index(text: str, step: dict[str, Any], steps: list[dict[str, Any]]) -> str:
    expected = str(_parameters(step).get("expected", "")).strip()
    if not expected:
        return text
    rendered = _zh_integer(int(expected)) if expected.isdigit() else expected
    if re.search(r"第[零〇一二三四五六七八九十百千0-9]+章", text):
        return re.sub(r"第[零〇一二三四五六七八九十百千0-9]+章", f"第{rendered}章", text, count=1)
    if re.search(r"\bchapter\s+\d+\b", text, flags=re.IGNORECASE):
        return re.sub(r"\bchapter\s+\d+\b", f"第{rendered}章", text, count=1, flags=re.IGNORECASE)
    return f"第{rendered}章\n\n{text}"


def _zh_integer(value: int) -> str:
    if value == 0:
        return "零"
    if value < 0 or value > 9999:
        return str(value)
    digits = "零一二三四五六七八九"
    units = ("", "十", "百", "千")
    result: list[str] = []
    zero_pending = False
    text = str(value)
    for index, raw in enumerate(text):
        digit = int(raw)
        position = len(text) - index - 1
        if digit == 0:
            zero_pending = bool(result) and any(char != "0" for char in text[index + 1 :])
            continue
        if zero_pending:
            result.append("零")
            zero_pending = False
        if not (digit == 1 and position == 1 and not result):
            result.append(digits[digit])
        result.append(units[position])
    return "".join(result)


def _prepend_sentence(text: str, sentence: str) -> str:
    sentence = sentence.strip()
    if not sentence:
        return text
    if sentence[-1] not in ".!?。！？":
        sentence = f"{sentence}。" if re.search(r"[\u4e00-\u9fff]", sentence) else f"{sentence}."
    return f"{sentence}\n\n{text}" if text else sentence


def _bridge_sentence(bridge: str, location: str) -> str:
    if bridge:
        cleaned = bridge.strip()
        if ":" in cleaned:
            prefix, detail = cleaned.split(":", 1)
            detail = detail.strip()
            if detail:
                return f"From {location or prefix.strip()}, {detail[0].lower()}{detail[1:]}"
        return cleaned
    return f"From {location}, the next moment carries the last scene's consequence forward" if location else ""



def _split_character_names(raw: str) -> list[str]:
    text = str(raw or "").strip()
    if not text:
        return []
    parts = re.split(r"[,，、;；|/]+", text)
    names: list[str] = []
    seen: set[str] = set()
    for part in parts:
        name = part.strip()
        if not name:
            continue
        key = name.lower()
        if key in seen:
            continue
        seen.add(key)
        names.append(name)
    return names


def _last_scene_anchor_targets(
    step: dict[str, Any],
    steps: list[dict[str, Any]],
) -> tuple[str, list[str]]:
    location = str(_parameters(step).get("location", "")).strip()
    characters = _split_character_names(str(_parameters(step).get("character", "") or ""))
    for candidate in steps:
        if candidate is step:
            continue
        if str(candidate.get("action") or "") != "anchor_last_scene_state":
            continue
        parameters = _parameters(candidate)
        if not location:
            location = str(parameters.get("location", "")).strip()
        characters.extend(_split_character_names(str(parameters.get("character", "") or "")))
    deduped: list[str] = []
    seen: set[str] = set()
    for name in characters:
        key = name.lower()
        if key in seen:
            continue
        seen.add(key)
        deduped.append(name)
    return location, deduped


def _opening_window(text: str, limit: int = 700) -> str:
    compact = re.sub(r"\s+", " ", str(text or "").strip())
    return compact[:limit]


def _finalize_last_scene_anchors(
    text: str,
    repair_plan: dict[str, Any],
    repair_context: RepairContext,
) -> str:
    """Re-apply idempotent last-scene anchors after model repair.

    Surgical model patches that add the reported missing names can drop other
    required last-scene cast members from the opening window. A deterministic
    finalize pass restores the full cast without rewriting formal prose body.
    """
    steps = [
        step
        for step in repair_plan.get("steps", [])
        if isinstance(step, dict) and str(step.get("action") or "") == "anchor_last_scene_state"
    ]
    if not steps:
        return text
    return apply_repair_plan(
        text,
        {"steps": steps},
        language=repair_context.language,
        repair_context=repair_context,
    )


def _parameters(step: dict[str, Any]) -> dict[str, Any]:
    parameters = step.get("parameters")
    return parameters if isinstance(parameters, dict) else {}


def _remove_case_insensitive(text: str, term: str) -> str:
    replacement = re.sub(r"\bresolved\b", "remains unresolved", term, count=1, flags=re.IGNORECASE)
    if replacement == term:
        replacement = "the unresolved issue"
    return re.sub(re.escape(term), replacement, text, flags=re.IGNORECASE)


def _replace_declared_chapter(text: str, expected: str) -> str:
    if re.search(r"\bchapter\s+\d+\b", text, flags=re.IGNORECASE):
        return re.sub(r"\bchapter\s+\d+\b", f"Chapter {expected}", text, count=1, flags=re.IGNORECASE)
    return f"Chapter {expected}: {text}"


REPAIR_STRATEGIES: dict[str, RepairStrategy] = {
    "seed_conflict_scene": _seed_conflict_scene,
    "expand_scene": _expand_scene,
    "add_conflict_signal": _add_conflict_signal,
    "remove_forbidden_term": _repair_forbidden_term,
    "add_required_term": _repair_required_term,
    "anchor_known_location": _repair_known_location,
    "insert_opening_bridge": _insert_opening_bridge,
    "rewrite_spatial_transition": _rewrite_spatial_transition,
    "anchor_last_scene_state": _anchor_last_scene_state,
    "repair_character_position": _repair_character_position,
    "add_transition_event": _add_transition_event,
    "flag_unknown_location": _flag_unknown_location,
    "add_character_location": _repair_character_location,
    "rewrite_inactive_character_action": _repair_inactive_character_action,
    "correct_chapter_index": _repair_chapter_index,
    "manual_review": _manual_review,
}

ZH_CN_REPAIR_STRATEGIES: dict[str, RepairStrategy] = {
    "seed_conflict_scene": _zh_no_safe_repair,
    "expand_scene": _zh_no_safe_repair,
    "add_conflict_signal": _zh_add_known_conflict_signal,
    "remove_forbidden_term": _zh_repair_forbidden_term,
    "add_required_term": _zh_repair_required_term,
    "anchor_known_location": _zh_repair_known_location,
    "insert_opening_bridge": _zh_insert_opening_bridge,
    "rewrite_spatial_transition": _zh_rewrite_spatial_transition,
    "anchor_last_scene_state": _zh_anchor_last_scene_state,
    "repair_character_position": _zh_repair_character_position,
    "add_transition_event": _zh_add_transition_event,
    "flag_unknown_location": _zh_no_safe_repair,
    "add_character_location": _zh_repair_character_location,
    "rewrite_inactive_character_action": _zh_repair_inactive_character_action,
    "correct_chapter_index": _zh_repair_chapter_index,
    "manual_review": _manual_review,
}

REPAIR_STRATEGY_REGISTRY: dict[str, dict[str, RepairStrategy]] = {
    "en": REPAIR_STRATEGIES,
    "zh-CN": ZH_CN_REPAIR_STRATEGIES,
}


def _normalized_language(value: str) -> str:
    normalized = str(value or "en").strip().lower().replace("_", "-")
    if normalized in {"zh", "zh-cn", "zh-hans", "chinese"}:
        return "zh-CN"
    if normalized in {"", "en", "en-us", "en-gb", "english"}:
        return "en"
    raise ValueError(f"unsupported local repair language: {value}")
