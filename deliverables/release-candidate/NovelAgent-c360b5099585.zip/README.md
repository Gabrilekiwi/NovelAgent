# NovelAgent

Version: 2.0.1 stabilization release

NovelAgent 2.0.1 stabilizes the 2.0 feature set without expanding the novel-creation surface. It hardens final-artifact integrity, sequential scene evidence, authoritative character/relationship/roster/numeric state, chapter-scoped recovery, context working sets, and byte-for-byte StoryProject writeback while retaining the v1.5-compatible agent loop and opt-in reliable semantic production path.

This release proves the deterministic program-level gates and local regression suite; it is not a claim that unattended long-form production or external model availability is guaranteed. Provider partial responses, latency, and paid first-ten-chapter literary evaluation remain operational concerns outside the local release proof. See the [v2.0.1 stabilization results](docs/v2.0.1-stabilization-results.json) and the [v2.0 baseline and stabilization charter](docs/v2.0-baseline.md).

Reliability/autonomy claims are tracked by four separate levels—code exists, main-path integration, default enablement, and real verification—in the [Reliability and autonomy capability status](docs/reliability-autonomy-capability-status.md). Synthetic evidence is listed separately and is never treated as real-provider evidence. A complete 50-chapter deterministic simulation passed against code commit `bfa3d04` in 1298.864 seconds; the [retained evidence report](docs/reliability-autonomy-50-chapter-evidence.json) closes only the synthetic long-run gate and does not enable autonomy by default. The same clean commit passed 1317 unit tests (7 platform skips) and v1 smoke with 21/21 preflight checks. The billable real single-chapter, four-chapter, ten-chapter, and 20-or-more-chapter checks are retained as [operator-run post-goal validation](docs/real-autonomy-e2e.md), not as current Codex goal work or completion conditions. The operator will run them manually after the goal and give Codex only the redacted reports for analysis. The first single-chapter attempt on 2026-07-15 failed before chapter completion; no successful real report exists, so real verification remains absent and autonomy remains opt-in. No Notion call was made in this upgrade run.

Token admission now binds the configured OpenAI model and endpoint instead of `runtime-default`. Recognized models on the official endpoint use a hash-verified, already-local `tiktoken` asset when available and report `model_tokenizer`, never `provider_exact`; cache misses fall back immediately without downloading. Compatible endpoints, unknown models, and providers without a trusted local tokenizer use a split fallback: the ASCII portion retains a one-token-per-byte floor, while non-ASCII UTF-8 bytes use the `7/18` calibration with the declared 15% margin, followed by 64 framing tokens. The floor therefore still protects JSON syntax, escapes, punctuation, and high-entropy ASCII, but no longer charges every Chinese UTF-8 byte as a token. This is locally tested behavior, not real-provider accuracy evidence.

Legacy-book event-authority migration is paused and outside the current Codex goal as of 2026-07-16. Its existing implementation, schemas, tests, documentation, and read-only preview history are retained; no migration decisions, `MigrationApproval`, execution, or activation will be performed. The active legacy book remains unmigrated. Resuming later requires an explicit operator decision and a fresh read-only preview against the then-current files.

Project movement is conditional, not a default capability. After an operator performs a same-volume directory rename, the explicit `--remap-roots` CLI can verify the preserved StoryProject and logical-root directory identities and forward-rebind every recognized embedded registry, with the main registry last. It requires UUID plus revision/digest CAS, pre-armed locks, an absent old path, and no pending/recovery transaction or active session/lease. The command never moves or copies data and refuses cross-volume or copy-delete moves, case-only rebinding, replaced roots, unknown registries, and external mutable EA transaction roots. This is locally tested fail-closed behavior, not real target-project verification or default portability; immutable historical manifests may still retain absolute-path snapshots.

Current v1.5 flow:

```text
Notion / Memory + StoryProject shadow/strict semantic state
  -> Snapshot Builder
  -> Director
  -> Execution Engine
  -> Chapter Pipeline (plan -> scenes -> merge)
  -> Claude Polish
  -> Language / Meta-output / Mojibake Contracts
  -> Rule Validator
  -> optional LLM Validator
  -> Scene Repair
  -> Snapshot / Run Artifacts
  -> transactional StoryProject + Memory V2 persistence
  -> durable delivery queue
```

## Quick Start

The reproducible development baseline uses CPython 3.12 and a project virtual environment.

Install dependencies:

```powershell
py -3.12 scripts/setup_environment.py
.venv\Scripts\python.exe -B scripts/check_environment.py --dev
```

On Linux, use `python3.12 scripts/setup_environment.py` and `.venv/bin/python` for subsequent commands. The setup installs exact runtime and transitive versions from `requirements.lock` plus test dependencies from `requirements-dev.lock`. Use `--runtime-only` to omit test tools. See [development environment and continuation](docs/development/environment.md) for validation, lock updates, and recovery of interrupted work. `requirements*.txt` declare dependency ranges for deliberate upgrades; the lock files define the tested installation.

## Windows 本地创作工作台

完成上述项目环境安装后，双击仓库根目录的 `启动创作工作台.bat`。启动器使用并检查本项目`.venv`，缺失或版本不符时提示修复命令。工作台会自动打开浏览器；关闭启动窗口即可停止服务。作者日常使用不需要进入运行目录、查看 JSON 或输入恢复命令。

试用当前开发改动（包括受控一次续试）请先关闭旧工作台，再双击 [`试用当前工作台.bat`](试用当前工作台.bat)。此入口明确使用当前目录版本，避免默认启动器打开已提交的旧界面；使用原本的工作台数据目录。已有实例运行时仍会打开原实例，因此切换版本前需要先关闭旧窗口。这是当前版本试用入口，不代表稳定版发布。续试和草稿保存的验证范围见[工作台日常操作验证](docs/development/workbench-continuation-20261117.md)。

重复启动会验证并打开已有工作台，不再启动第二个任务执行器。若原窗口异常退出，但执行子进程仍在运行，新启动会提示等待或检查原进程，并保留任务现场。默认端口被其他程序占用时自动选择可用端口；以启动窗口显示的地址为准。创建作品时，“保存父目录”需要选择已存在的文件夹，路径错误可直接修改后重试，已填写内容会保留。

隔离开发验证可使用 `.venv\Scripts\python.exe run_workbench.py --data-dir .tmp\workbench-test --workspace .tmp\workbench-books --no-active-import --no-browser --port 0`，先创建该 workspace 文件夹。工作台实例资格与本机作品写资格分别核对；恢复副本需经过受控交接后才能写入，直接复制目录不会获得写资格。完整恢复及Windows发布验收仍在进行，安装、升级保全和回退说明见[环境与维护文档](docs/development/environment.md)。

工作台固定为五个主区域：

- **概览**：查看作品进度、当前任务、待处理数量与项目健康状态。
- **章节**：对照章纲和正文，查看审核、状态与不可变版本历史，并发起安全润色。
- **生产**：确认已批准章纲后启动连续生成，可选择“本章完成后暂停”或紧急停止。
- **待处理**：处理异常恢复、草稿修订、重验证和作者确认提交；不确定的 Provider 调用不会自动重试。
- **历史**：追溯生成、警告、恢复、提交、Receipt/readback 和成本摘要。

第 20 章隔离异常恢复以及第 23–42 章真实生产验收的作者操作清单见 [产品验证与自用上线标准](docs/product-validation.md)。第 21、22 章是既有 Shadow 预热历史，不计入两个正式十章 Cohort。完整测试门负责保护代码和数据，真实模型连续写作与人工阅读负责证明小说是否可用；两者都必须通过。

工作台只监听 `127.0.0.1`，并校验 Host、Origin 和启动令牌。Provider 凭据继续由本机环境变量或 `.env` 管理；网页和工作台 SQLite 只显示脱敏就绪状态，不接收、不回显也不保存 API Key。

Run preflight without model calls:

```bash
python main.py --init-runtime
python main.py --check --dry-run --memory data/notion_memory.example.json
```

`--check` prints a concise summary by default. Add `--check-json` for the full preflight JSON diagnostics.

Run one local dry-run step:

```bash
python main.py --init-runtime
python main.py --dry-run --memory data/notion_memory.example.json
```

Generation commands print a concise summary by default. Add `--output-json` for the full result or `--output-run-json` for only the run record. If Claude polish fails after base chapter generation, the run continues with the unpolished generated chapter and records the polish error in the run trace.
The execution runtime remains `legacy` by default. Add `--runtime-mode shadow` or set `NOVELAGENT_RUNTIME_MODE=shadow` to record internal node contracts, trace-derived attempts, non-resumable checkpoints, context digests/token estimates, and ModelCall-receipt usage without changing the authoritative executor. This execution-level Shadow is separate from StoryProject semantic shadow; `node` execution cutover is intentionally unavailable. See [Runtime Commands](docs/runtime.md).
If local proxy environment variables interfere with provider API calls, run with `--no-proxy` or set `NOVELAGENT_NO_PROXY=1` in `.env` to clear `HTTP_PROXY`, `HTTPS_PROXY`, and `ALL_PROXY` for the NovelAgent process.
High-confidence mojibake output is rejected before it can be committed as chapter prose. If OpenAI returns an invalid chapter-plan JSON payload, the pipeline makes one schema-focused JSON repair request before failing the generation step.

Select the memory source explicitly when needed:

```bash
python main.py --check --dry-run --memory-source file --memory data/notion_memory.example.json
python main.py --check --dry-run --memory-source notion
python main.py --check --dry-run --notion-memory
```

Use `--notion-sync` when a real run should read live Notion memory, write committed memory updates back to Notion, and verify them with readback:

```bash
python main.py --notion-sync --no-proxy
```

Run multiple local dry-run steps:

```bash
python main.py --dry-run --steps 2 --memory data/notion_memory.example.json
```

These steps advance a loop-local Snapshot only. Each accepted result has `status="preview"`, while the on-disk Snapshot, Memory, and run directory remain unchanged.

Run multiple StoryProject chapters with real transactional writeback:

```bash
python main.py --story-project auto --chapter 2 --steps 2 --story-project-writeback
```

StoryProject multi-step mode requires real writeback. Context, previous prose, settings, and tracking files are reloaded for every step, and the chapter cursor advances only after a complete commit. Model-call, token, elastic, and elapsed-time budgets reset for every chapter; the loop session only coordinates and summarizes those chapter runs. The default per-chapter input budget is 256,000 tokens so a complex multi-scene draft still has normal capacity for its mandatory initial validation and one repair/revalidation cycle; later repair-only expansion remains subject to convergence evidence.

StoryProject remains in non-authoritative shadow mode unless a target-book calibration report passes every strict gate and is explicitly activated. See [Story State Calibration and Strict Activation](docs/story-state-activation.md). Persistent strict runs require `--story-project-writeback`; parser/schema/layout drift fails closed. The opt-in, billable two-chapter real OpenAI gate is documented in [Real StoryProject Two-Chapter E2E](docs/real-storyproject-e2e.md).

Multi-step runs print progress lines to stderr by default, including step start/end, commit status, run id, and duration. Add `--no-progress` to suppress those lines, or use `--output-json` for a clean machine-readable loop result. Local supervisors can also pass `--progress-jsonl C:\absolute\existing\parent\events.jsonl` to receive a flushed, append-only NDJSON event stream without changing stdout or stderr.

Run tests:

```bash
python -B -m pytest -q
```

Run the local v1 smoke gate:

```bash
python -B scripts/smoke_v1.py
```

This runs tests, preflight, one persisted dry-run, file memory writeback, run reporting, and the provider-smoke missing-config diagnostic path inside `.tmp/smoke_v1/...`.

Recover the latest failed or rejected pre-polish draft without advancing the snapshot:

```bash
python main.py --recover-latest --run-dir .tmp/runtime/runs --chapter-dir .tmp/runtime/chapters
```

If a StoryProject chapter is locked by an interrupted provider call, classify and unlock it without making another model call:

```bash
python main.py --story-project "books/your-book" --recover-locked-chapter

# Discard known-bad, uncommitted output for the locked chapter and restart it.
python main.py --story-project "books/your-book" --recover-locked-chapter --locked-chapter-reset
```

The command preserves a complete draft for validation/repair, preserves a contiguous scene prefix so the next normal generation starts at the first missing scene, or resets the uncommitted chapter when no output is trustworthy. It also promotes a newer complete failed draft (for example, a terminal local budget rejection with no unresolved provider call) over an older partial recovery checkpoint, so a repaired chapter is not regenerated merely because the final validation did not run. When a hash-verified Claude polish response already has a successful durable receipt, recovery prefers that response and the next run skips duplicate polishing before validation. It never changes committed prose or advances the snapshot. After it reports `READY`, rerun the original generation command.

Inspect and normalize a snapshot with explicit UTF-8 JSON handling:

```bash
python -B scripts/snapshot_utf8.py --snapshot .tmp/runtime/snapshot.json --write-normalized
```

The optional LLM Validator is off by default, including dry-run and CI. Enable it explicitly with `--llm-validator`; preflight will then require OpenAI configuration and schema-check the LLM validation output before any problems are merged into `validation.problems[]`.

Real provider smoke checks are available separately after local gates pass:

```bash
python -B scripts/provider_smoke.py --providers openai claude
python -B scripts/provider_smoke.py --providers notion --notion-write
```

These write diagnostics under `.tmp/runtime/provider_smoke/...` and use isolated runtime state.
Use `--openai-model`, `--openai-base-url` or `--no-openai-base-url`, `--max-input-chars`, `--max-output-tokens`, `--openai-max-retries`, `--openai-scene-limit`, `--claude-model`, `--claude-base-url`, `--claude-user-agent`, `--claude-max-tokens`, `--request-timeout`, `--retries`, and `--retry-delay-seconds` to keep live provider diagnostics bounded. Claude uses the Anthropic Messages-compatible path through the Anthropic SDK; for MicuAPI-style Claude external compatibility, set `CLAUDE_BASE_URL` or `ANTHROPIC_BASE_URL` to the Anthropic-compatible root URL, not an OpenAI `/v1` endpoint. The Claude key can be `ANTHROPIC_API_KEY` or the Micu-style `ANTHROPIC_AUTH_TOKEN`, and the model can be `CLAUDE_MODEL` or `ANTHROPIC_MODEL`. OpenAI chapter-generation smoke uses one compact scene-generation probe so it proves the real chapter-generation API path without spending a full chapter budget; the full plan/scene/merge pipeline remains covered by local smoke and normal runs. OpenAI SDK retries default to 0 in smoke so `--retries` remains the visible retry budget. Retries apply to non-writing subchecks only; Notion writeback is not retried. Add `--no-proxy` when local `HTTP_PROXY` / `HTTPS_PROXY` variables point at a proxy you do not want provider smoke to use. Add `--require-all-checks` for Phase 4 acceptance, and add `--ignore-dotenv --allow-missing` when checking the missing-credential path on a machine that has local keys.
The JSON report includes `request`, `required_checks[]`, `required_checks_ok`, and a compact `diagnostics` block with missing config names plus failed, skipped, and unrequested subchecks. Provider failures include `failure_category` and `retryable` when they can be classified. Runtime OpenAI and Claude calls default to streamed responses and timeout defaults are tuned for longer chapter-generation and polish calls, so long prose generations can begin returning content before the full response is complete. Snapshots can include `project_profile.language`, `project_profile.known_characters`, and `project_profile.known_locations`; language-aware contracts then prevent configured Chinese projects from committing English model output, and the analyzer uses profile terms to avoid inventing characters or locations. Missing provider config is aggregated per provider so one run reports all required variables it can prove are absent; `diagnostics.missing_config_groups[]` preserves alternatives such as `NOTION_DATABASE_ID` or `NOVELAGENT_NOTION_DATABASE_ID`.
The OpenAI check reports Director and chapter-generation subchecks separately.
Claude reports a `polish` subcheck, and Notion reports `read`, `writeback`, and `readback` subchecks once real credentials are available.
The report also includes `config_status` with redacted set/missing flags, selected models, timeout/token/retry limits, SDK/default endpoint status, and redacted proxy endpoint metadata; no secrets are written.
`required_checks[]` and `required_checks_ok` form the flat Phase 4 completion checklist.

Inspect recent persisted run records:

```bash
python main.py --report-runs
```

## Main Directories

- `core/director`: decision layer with schema-checked decisions and run audit records.
- `core/engine`: execution loop, schema-checked workflow plans and trace events, model-call stage diagnostics, run records, artifacts, preflight, and run reports.
- `core/cli`: argument parsing metadata, runtime/config resolution, command routers, and output formatters re-exported by `main.py`.
- `core/state`: snapshot, input pack plus metadata, memory, Notion export normalization, and schema-checked state builder audit.
- `core/story_project`: project identity, semantic parser/authority, activation, managed projection merge, read sets, and StoryProject writeback.
- `core/memory_v2`: immutable event batches, replay/checkpoint verification, canonical projection, and Snapshot adaptation.
- `core/validator`: continuity, spatial, and logic validation with explicit requested/executed/skipped coverage metadata.
- `modules`: feature modules for chapter planning/scene generation/merge, polish, schema-checked conflict analysis, and schema-checked repair planning.
- `api`: provider adapters for OpenAI, Claude, and Notion.
- `prompts`: prompt assets.
- `schemas`: JSON schema contracts.
- `docs`: runtime and memory documentation.

## Runtime Artifacts

Persistent runs write schema-checked run result envelopes:

- `data/snapshot.example.json`: committed sample snapshot state.
- `data/notion_memory.example.json`: committed sample Notion memory export.
- `.tmp/runtime/snapshot.json`: default mutable runtime snapshot.
- `.tmp/runtime/notion_memory.json`: optional initialized runtime memory copied from the sample.
- `.tmp/runtime/runs/*.json`: structured run records with Director audit, workflow plan, state update audit, trace, model output failure diagnostics, validation, analysis summaries, and schema-checked `chapter.pipeline.stages`.
- `.tmp/runtime/runs/loop_sessions/*.json`: schema-checked multi-step loop session records with per-step timing.
- `.tmp/runtime/runs/snapshot_packs/*.md`: Snapshot Builder input packs.
- `.tmp/runtime/runs/input_packs/*.md`: full input packs; run records include input pack metadata.
- `.tmp/runtime/runs/chapter_pipeline/*`: chapter plan, scene drafts with merged-chapter spans, merged chapter, validation report, and repair delta artifacts for the pipeline stages.
- `.tmp/runtime/chapters/*.md`: chapter body artifacts.
- `<StoryProject>/.novelagent/runtime/memory/v2/`: project-local canonical Memory V2.1 projection, immutable event batches, and checkpoints.

Run records, run reports, and loop session summaries expose compact validation, repair evidence, and per-step timing, so common Validator/Repair/provider stalls can be diagnosed without opening the full run-result envelope. Both directories are ignored by git by default.

Local `.env` is ignored. Use `.env.example` for variable names and recommended default model names only; real configuration is still checked by preflight before live provider calls.

Legacy imports under `core.*` remain available as compatibility wrappers. `core.orchestrator` delegates to the v1.5 executor and supports custom snapshot, memory, run, chapter, preflight, loop, and report paths. Compatibility package exports point at the v1.5 implementations for input pack metadata, snapshot builder audit, state update audit, dynamic flow plans, feature modules, and API adapters. The root `core` package lazily exposes the v1.5 executor and orchestrator entrypoints.

The v1.5 project contract keeps the established directory layout and legacy wrapper boundaries covered by `tests/test_repo_hygiene.py`, so structural drift is caught alongside runtime tests.

## More Docs

- [Architecture](docs/architecture.md)
- [Runtime Commands](docs/runtime.md)
- [Memory Input](docs/memory.md)
- [Story State Calibration and Strict Activation](docs/story-state-activation.md)
- [Real StoryProject Two-Chapter E2E](docs/real-storyproject-e2e.md)
- [Reliability and autonomy capability status](docs/reliability-autonomy-capability-status.md)
- [Operator-run real autonomy validation](docs/real-autonomy-e2e.md)
- [产品验证与自用上线标准](docs/product-validation.md)
